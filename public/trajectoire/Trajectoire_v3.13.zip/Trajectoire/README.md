# Trajectoire — appli locale de correction par compétences et suivi de classe

Appli locale (Streamlit) pour corriger par compétences (A/B/C/D ou
points directs), suivre les résultats d'une ou plusieurs classes dans
le temps, et générer des rapports PDF personnalisés avec remédiations.
Toutes les données restent sur ton ordinateur (fichier
`trajectoire.db`, dans ton dossier `Documents/Trajectoire`) — rien n'est
envoyé sur internet, aucune connexion ni compte nécessaire.

## Installation et lancement — méthode simple (recommandée)

1. Installe Python si ce n'est pas déjà fait : https://www.python.org/downloads/
   (sous Windows, coche bien **"Add python.exe to PATH"** pendant l'installation).
2. Place tous les fichiers de ce dossier ensemble (`app.py`, `db.py`,
   `pdf_report.py`, `requirements.txt`, et le script de lancement).
3. **Windows** : double-clique sur `lancer_windows.bat`.
   **Mac** : double-clique sur `lancer_mac.command` (la première fois,
   il faut peut-être faire un clic droit → Ouvrir, ou lancer
   `chmod +x lancer_mac.command` une fois dans le Terminal si macOS le
   bloque).
4. La première fois, ça prend 1 à 3 minutes (installation automatique).
   Les fois suivantes, ça démarre en quelques secondes. Un onglet de
   navigateur s'ouvre automatiquement sur l'appli.
5. Pour arrêter : ferme la fenêtre du terminal qui s'est ouverte, ou
   fais Ctrl+C dedans.

## Où sont tes données, et comment les protéger (depuis la v3.12)

- Tes données sont dans **`Documents/Trajectoire/trajectoire.db`**, **pas** dans
  le dossier de l'appli. Pour mettre l'appli à jour, remplace simplement son
  dossier par le nouveau : tes données ne bougent pas et sont retrouvées toutes
  seules. Le dossier de données contient aussi `sauvegardes/` (copies de
  sécurité automatiques).
- **Première ouverture après une mise à jour depuis une version ≤ 3.11** :
  l'appli cherche ton ancien `copie_helper.db` (à côté de l'appli, dans
  Téléchargements, Bureau, Documents) et le **copie** dans le nouveau dossier.
  S'il y en a plusieurs différents, elle te laisse choisir. L'ancien fichier
  n'est jamais modifié ni supprimé.
- La barre de gauche rappelle en permanence où sont les données et l'heure du
  dernier enregistrement.
- **Copies automatiques** : dès que tu as modifié quelque chose et que la copie
  précédente date de plus d'une heure (donc aussi pendant que l'appli reste
  ouverte). On garde les 14 plus récentes + la dernière de chacun des 30
  derniers jours.
- **Copie miroir** (Réglages) : une copie de plus dans un autre dossier de ton
  choix (clé USB, dossier OneDrive…).
- Si la base est **vide** alors qu'une sauvegarde contient des données (par
  exemple parce que l'appli a été lancée depuis un autre endroit), l'appli
  l'écrit en rouge et propose de restaurer en un clic.
- Une **restauration** copie d'abord l'état actuel dans
  `sauvegardes/avant_restauration_…` : elle n'est jamais irréversible.
- Garde **un seul** onglet ouvert : l'appli prévient si elle est ouverte deux fois.
- Si ton dossier Documents est synchronisé (OneDrive, iCloud), ferme l'appli
  avant de changer d'ordinateur, pour que la dernière version du fichier soit
  bien synchronisée.
- Pour changer d'ordinateur : télécharge une copie dans Réglages, puis
  restaure-la sur l'autre ordinateur (ou copie `trajectoire.db` dans
  `Documents/Trajectoire` avant le premier lancement).

## Installation manuelle (si le script ne fonctionne pas)

```bash
python3 -m venv venv
source venv/bin/activate        # sous Windows : venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Utilisation

0. **Classes** : gère tes classes dans l'onglet Élèves (créer, renommer,
   déplacer un élève d'une classe à l'autre). Chaque devoir est rattaché
   à une classe.
1. **Élèves** : importe ta liste via un export CSV Pronote, ou ajoute-les
   à la main, dans la classe active.
2. **Devoirs** : crée un DS (mode de notation lettres A/B/C/D ou points
   directs, note finale sur 10/20/autre, arrondi configurable, date
   réelle du devoir), saisis les questions avec compétence et barème
   (le bouton "Générer les lignes" pré-remplit Q1 à Qn d'un coup).
3. **Corriger** : choisis le devoir, navigue élève par élève, note
   chaque question. Sauvegarde automatique à chaque clic. Un
   ajustement (bonus/malus ponctuel) et un commentaire général sont
   disponibles par élève.
4. **Résultats** : classement de toute la classe sur un devoir avec
   histogramme de dispersion des notes, et suivi dans le temps (un
   élève ou toute la classe) avec détection automatique des tendances
   à la baisse ou des progrès notables.
5. **Remédiation** : un texte par compétence × niveau, réutilisé sur
   tous les rapports du devoir — génère le prompt IA fourni pour
   produire ce texte à partir de l'énoncé et du corrigé, ou remplis
   le CSV vierge à la main.
6. **Rapports** : génère le PDF d'un élève, ou le zip de toute la classe.

## Nouveautés de la v3.13 (sécurité des saisies et des calculs)

- **Rien ne se perd quand on change de page** : un commentaire tapé puis un clic
  direct sur une autre page, un autre élève ou un autre devoir est enregistré.
  La note finale d'un TP est aussi enregistrée automatiquement.
- **Avertissement avant d'effacer des notes** : retirer une question, « Générer les
  lignes » ou « Charger cette grille » demande confirmation si des notes déjà
  saisies disparaîtraient. Renommer ou réordonner une question ne fait rien perdre.
- **Arrondis corrects** : 10,5 devient 11 (et non 10) avec un arrondi à l'unité ;
  la note ne dépasse jamais le maximum ni ne passe sous 0.
- **PDF** : les textes contenant « < » ou « & » ne font plus planter la génération.
  Les PDF ne sont plus écrits sur le disque (ils sont créés en mémoire). Les élèves
  sans aucune note sont ignorés dans le zip de classe (la liste est indiquée).
- **Élèves** : un nom ne peut exister qu'une fois dans l'appli. À l'import d'une
  liste, les élèves déjà présents dans une autre classe peuvent être déplacés (avec
  leur historique). Pour deux vrais homonymes, ajoute un repère : « DUPONT Léa (2) ».
- **Dossier Documents** : sous Windows, le vrai dossier Documents est retrouvé même
  s'il est redirigé (OneDrive).

## Limites connues (volontaires pour l'instant)

- Pas d'extraction automatique des questions/compétences/barème depuis
  un énoncé PDF — saisie manuelle dans l'onglet Devoirs.
- Pas d'assistance à la correction depuis des copies scannées.
- Usage mono-poste, pas de compte ni de connexion : chaque personne qui
  installe cette appli a sa propre base de données locale, indépendante
  des autres. Pas de partage ou de synchronisation entre postes.

## Fichiers

- `app.py` — interface (pages : Élèves / Devoirs / Corriger / Résultats / Remédiation / Rapports)
- `db.py` — base SQLite + logique de calcul (note, niveau par compétence)
- `pdf_report.py` — génération du PDF par élève
- `lancer_windows.bat` / `lancer_mac.command` — scripts de lancement automatique
- `Documents/Trajectoire/trajectoire.db` (hors de ce dossier) — apparaît au premier
  lancement, contient toutes tes données (élèves, classes, devoirs, notes) — c'est
  le seul fichier à sauvegarder/copier si tu changes d'ordinateur
