"""
Génère les PDF de rapport : un par élève, ou un unique PDF pour toute la classe.
Deux trames : devoir écrit (question par question) et TP (compétence par compétence).
"""
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import cm
from io import BytesIO
import re
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Spacer, PageBreak, CondPageBreak, HRFlowable, Flowable
)
from reportlab.platypus import Paragraph as _ParagraphReportlab
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle

from db import (POIDS_NIVEAU, COMPETENCE_UNIQUE_SANS_LISTE, parse_liens, charger_catalogue,
                resoudre_lien, PHRASE_CODES)
from xml.sax.saxutils import escape as _esc


def Paragraph(texte, style, *args, **kwargs):
    """Paragraph de reportlab, avec un filet de sécurité : si un texte saisi par l'utilisateur
    contient des caractères comme « < » ou « & » qui cassent l'analyse du balisage, on affiche le
    texte tel quel plutôt que de faire échouer tout le PDF (ou tout le zip de la classe)."""
    try:
        return _ParagraphReportlab(texte, style, *args, **kwargs)
    except Exception:
        brut = re.sub(r"</?(b|i|u|font|br|para|strong|em)\b[^>]*/?>", " ", str(texte))
        return _ParagraphReportlab(_esc(brut), style, *args, **kwargs)

styles = getSampleStyleSheet()
cell_style = ParagraphStyle("cell", parent=styles["Normal"], fontSize=9, leading=12)
petit_gris_style = ParagraphStyle("petit_gris", parent=styles["Normal"], fontSize=7,
                                   textColor=colors.grey, leading=9)
title_style = ParagraphStyle("title", parent=styles["Title"], fontSize=14, leading=17, spaceAfter=0)
date_style = ParagraphStyle("date", parent=styles["Normal"], fontSize=9, textColor=colors.grey)
nom_note_style = ParagraphStyle("nom_note", parent=styles["Normal"], fontName="Helvetica-Bold",
                                 fontSize=12, spaceAfter=6)
sous_titre_style = ParagraphStyle("sous_titre", parent=styles["Normal"], fontName="Helvetica-Bold",
                                   fontSize=10, spaceAfter=4)
COULEUR_ACCENT = colors.HexColor("#2563EB")

MARGE = 1.3 * cm
LARGEUR_UTILE = A4[0] - 2 * MARGE   # largeur imprimable (les tableaux l'occupent en entier)


def _appliquer_taille(taille):
    """Taille de base du texte du rapport (points). 9 = ancienne mise en page ; 8 ou 7 pour faire tenir
    tout le rapport d'un élève sur une feuille recto-verso. Modifie les styles partagés en place."""
    t = float(taille or 9)
    cell_style.fontSize = t
    cell_style.leading = round(t * 1.2, 1)
    petit_gris_style.fontSize = max(round(t - 2, 1), 5.5)
    petit_gris_style.leading = petit_gris_style.fontSize + 2
COULEUR_ENTETE = colors.HexColor("#DCE6F1")


def _liens_affichables(brut):
    """Liens d'une case de remédiation prêts à imprimer : le code est la seule donnée de l'IA
    qu'on garde ; titre et chemin sont relus dans le catalogue (source de vérité) quand il est
    chargé. Les entrées sans code valide ne sont jamais imprimées."""
    catalogue = charger_catalogue()
    sortie = []
    for l in parse_liens(brut):
        if not l["code"]:
            continue
        r = resoudre_lien(l["code"], catalogue) if catalogue else None
        sortie.append(r or {"code": l["code"], "titre": l["titre"], "chemin": l["chemin"], "chapitre": ""})
    return sortie


def _bloc_liens(liens):
    """Pour chaque ressource : le CODE en gros caractères gras (la seule chose que l'élève tape),
    puis le titre, puis le chemin d'accès. Fiche imprimée : ni QR code ni adresse."""
    t = cell_style.fontSize
    code_style = ParagraphStyle("lien_code", parent=cell_style, fontName="Helvetica-Bold",
                                fontSize=t + 3, leading=t + 5)
    petit = ParagraphStyle("lien_petit", parent=cell_style, fontSize=max(t - 1, 6), leading=max(t - 1, 6) + 2)
    flowables = []
    for l in liens:
        flowables.append(Paragraph(
            f"{_esc(l['code'])} <font name='Helvetica' size='{t:g}'>— {_esc(l['titre'])}</font>", code_style))
        if l["chemin"]:
            flowables.append(Paragraph(f"<font color='#555555'>Où : {_esc(l['chemin'])}</font>", petit))
        flowables.append(Spacer(1, 2))
    return flowables


def _fmt(x):
    """Arrondit à 2 décimales et retire les zéros inutiles (1.50 -> 1.5, 0.666667 -> 0.67)."""
    return f"{round(x, 2):g}"


def _fmt_date(date_ds):
    if not date_ds:
        return None
    try:
        return datetime.strptime(date_ds, "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return date_ds


COULEUR_PROGRES = "#2563EB"   # bleu
COULEUR_RECUL = "#DC2626"     # rouge


class _Fleche(Flowable):
    """Petit triangle plein dessiné en vectoriel (aucune police nécessaire, rendu identique dans
    tous les lecteurs PDF, y compris sur téléphone) : bleu vers le haut = progrès, rouge vers
    le bas = recul."""

    def __init__(self, direction, taille=7):
        super().__init__()
        self.direction = direction
        self.taille = taille
        self.width = taille
        self.height = taille

    def draw(self):
        t = self.taille
        if self.direction == "up":
            self.canv.setFillColor(colors.HexColor(COULEUR_PROGRES))
            points = [(0, 0), (t, 0), (t / 2, t)]
        else:
            self.canv.setFillColor(colors.HexColor(COULEUR_RECUL))
            points = [(0, t), (t, t), (t / 2, 0)]
        chemin = self.canv.beginPath()
        chemin.moveTo(*points[0])
        for p in points[1:]:
            chemin.lineTo(*p)
        chemin.close()
        self.canv.drawPath(chemin, fill=1, stroke=0)


_STYLE_SANS_MARGE = [
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ("TOPPADDING", (0, 0), (-1, -1), 0), ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
]


def _cell_niveau(niveau, direction, suite=None, style=None, largeur_texte=0.5 * cm, align="LEFT"):
    """Contenu de cellule « niveau + flèche d'évolution ». Sans flèche : un simple Paragraph
    (avec, le cas échéant, une seconde ligne `suite`)."""
    style = style or cell_style
    if direction not in ("up", "down"):
        return Paragraph(f"{niveau}<br/>{suite}" if suite else niveau, style)
    rangee = Table([[Paragraph(niveau, style), _Fleche(direction)]],
                   colWidths=[largeur_texte, 0.35 * cm], hAlign=align)
    rangee.setStyle(TableStyle(_STYLE_SANS_MARGE))
    return [rangee, Paragraph(suite, style)] if suite else rangee


def _legende_evolution(texte_reference):
    t = Table([[_Fleche("up", 6), Paragraph("progrès /", petit_gris_style),
                _Fleche("down", 6), Paragraph(f"recul {texte_reference}", petit_gris_style)]],
              colWidths=[0.3 * cm, 1.3 * cm, 0.3 * cm, 14 * cm], hAlign="LEFT")
    t.setStyle(TableStyle(_STYLE_SANS_MARGE))
    return t


def _a_des_fleches(evolution):
    return any(v in ("up", "down") for v in (evolution or {}).values())


def _entete(story, ds_titre, date_ds):
    """En-tête commun aux deux trames : titre, filet de couleur, date."""
    story.append(Paragraph(_esc(ds_titre or ""), title_style))
    story.append(Spacer(1, 2))
    story.append(HRFlowable(width="100%", thickness=1.5, color=COULEUR_ACCENT, spaceAfter=3))
    date_fmt = _fmt_date(date_ds)
    if date_fmt:
        story.append(Paragraph(f"Le {date_fmt}", date_style))
    story.append(Spacer(1, 4))


def _build_student_story(ds_titre, nom_prenom, note, note_sur, commentaire,
                          niveaux_competence, remediation_grid, questions, grades,
                          mode_notation="lettres", date_ds=None, ajustement=0, options=None,
                          grade_comments=None, evolution=None):
    options = options or {}
    _appliquer_taille(options.get("taille", 9))
    evolution = evolution or {}
    inclure_evolution = options.get("evolution", False)
    inclure_remediation = options.get("remediation", True)
    inclure_detail = options.get("detail_questions", True)
    inclure_commentaire = options.get("commentaire", True)
    inclure_ajustement = options.get("ajustement", True)
    inclure_commentaire_question = options.get("commentaire_question", False)
    grade_comments = grade_comments or {}

    # Si toutes les questions partagent la même compétence "Général" (mode « sans compétence »),
    # la colonne compétence n'apporte rien : on l'enlève plutôt que d'afficher une valeur répétitive.
    sans_competence = bool(questions) and all(
        q["competence"] == COMPETENCE_UNIQUE_SANS_LISTE for q in questions)

    story = []
    _entete(story, ds_titre, date_ds)
    story.append(Paragraph(
        f"NOM et prénom : {_esc(nom_prenom)} &nbsp;&nbsp;&nbsp;&nbsp; "
        f"Note : {_fmt(note)}/{_fmt(note_sur)}",
        nom_note_style,
    ))
    if inclure_ajustement and ajustement:
        story.append(Paragraph(f"<font color='grey'>Ajustement appliqué : {ajustement:+g} point(s)</font>",
                                cell_style))
    if inclure_commentaire and commentaire:
        story.append(Paragraph(f"Commentaire : {_esc(commentaire)}", cell_style))
    story.append(Spacer(1, 6))

    if inclure_remediation and not sans_competence:
        # Tableau compétence / niveau / remédiation, avec le rappel des questions concernées
        data = [[Paragraph("Compétence", cell_style), Paragraph("Niveau", cell_style),
                 Paragraph("Remédiation proposée", cell_style)]]
        a_des_liens = False
        for comp, (niveau, taux) in niveaux_competence.items():
            texte = remediation_grid.get(comp, {}).get(niveau, "") if niveau in POIDS_NIVEAU else \
                "Compétence non mobilisée sur ce devoir."
            labels_questions = [q["label"] for q in questions if q["competence"] == comp]
            cellule_competence = f"<b>{_esc(comp)}</b>"
            if labels_questions:
                cellule_competence += f"<br/><font size=7 color='grey'>{_esc(', '.join(labels_questions))}</font>"
            cellule_texte = Paragraph(_esc(texte or ""), cell_style)
            if niveau in POIDS_NIVEAU:
                blocs = [("liens_ds", "Pour consolider le chapitre du devoir"),
                         ("liens_suivant", "Pour préparer le chapitre suivant"),
                         ("liens", "Pour s'entraîner (tous chapitres)")]
                suite = []
                for col, titre_bloc in blocs:
                    liens = _liens_affichables(remediation_grid.get(comp, {}).get(f"{col}_{niveau}", ""))
                    if not liens:
                        continue
                    a_des_liens = True
                    chapitres = {l["chapitre"] for l in liens if l.get("chapitre")}
                    if col != "liens" and len(chapitres) == 1:
                        titre_bloc += f" ({next(iter(chapitres))})"
                    suite += [Spacer(1, 3), Paragraph(f"<b>{_esc(titre_bloc)} :</b>", petit_gris_style)]
                    suite += _bloc_liens(liens)
                if suite:
                    cellule_texte = [cellule_texte] + suite
            data.append([
                Paragraph(cellule_competence, cell_style),
                _cell_niveau(niveau, evolution.get(comp) if inclure_evolution else None),
                cellule_texte,
            ])
        if a_des_liens:  # une seule fois par fiche, en tête de la section de remédiation
            story.append(Paragraph(f"<i>{_esc(PHRASE_CODES)}</i>", cell_style))
            story.append(Spacer(1, 3))
        t = Table(data, colWidths=[2.8 * cm, 1.6 * cm, LARGEUR_UTILE - 4.4 * cm])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTSIZE", (0, 0), (-1, -1), cell_style.fontSize),
        ]))
        story.append(t)
        if inclure_evolution and _a_des_fleches(evolution):
            story.append(Spacer(1, 3))
            story.append(_legende_evolution("par rapport à l'évaluation précédente de cette compétence."))
        story.append(Spacer(1, 8))

    if inclure_detail:
        if inclure_remediation and not sans_competence:
            # le détail par question passe au verso seulement s'il ne tient pas à la suite
            # (tableau compact : environ 0,55 cm par ligne + titre et en-tête)
            story.append(CondPageBreak((len(questions) + 2) * 0.55 * cm + 1.5 * cm))
        # Tableau question / [compétence] / niveau / points / [commentaire]
        story.append(Paragraph("Niveau atteint par question et barème associé :", sous_titre_style))
        entetes = ["Question"]
        if not sans_competence:
            entetes.append("Compétence évaluée")
        entetes.append("Niveau atteint")
        entetes.append("Points et barème")
        if inclure_commentaire_question:
            entetes.append("Commentaire")
        data2 = [entetes]
        for q in questions:
            g = grades.get(q["id"], {}) or {}
            if mode_notation == "points":
                pts = g.get("points")
                pts = pts if pts is not None else 0.0
                niveau_affiche = f"{_fmt(pts)} pts" if g.get("points") is not None else "-"
            else:
                niveau = g.get("niveau") or ""
                pts = q["bareme"] * POIDS_NIVEAU.get(niveau, 0)
                niveau_affiche = niveau or "-"
            ligne = [q["label"]]
            if not sans_competence:
                ligne.append(q["competence"])
            ligne.append(niveau_affiche)
            ligne.append(f"{_fmt(pts)} /{_fmt(q['bareme'])}")
            if inclure_commentaire_question:
                ligne.append(Paragraph(_esc(grade_comments.get(q["id"], "") or ""), cell_style))
            data2.append(ligne)

        if sans_competence and inclure_commentaire_question:
            largeurs = [2.5 * cm, 2.5 * cm, 3.5 * cm, 5.5 * cm]
        elif sans_competence:
            largeurs = [4 * cm, 4 * cm, 6 * cm]
        elif inclure_commentaire_question:
            largeurs = [2.5 * cm, 3.5 * cm, 2.5 * cm, 3 * cm, 4.5 * cm]
        else:
            largeurs = [3 * cm, 4 * cm, 3 * cm, 4 * cm]

        t2 = Table(data2, colWidths=largeurs)
        t2.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTSIZE", (0, 0), (-1, -1), cell_style.fontSize),
        ]))
        story.append(t2)
    return story


def _build_tp_story(ds_titre, nom_prenom, note, note_sur, note_basse, note_haute,
                     questions, grades, grade_comments, date_ds=None, options=None,
                     commentaire_global=None, evolution=None):
    options = options or {}
    _appliquer_taille(options.get("taille", 9))
    evolution = evolution or {}
    inclure_evolution = options.get("evolution", False)
    inclure_capacite = options.get("capacite", True)
    inclure_commentaire = options.get("commentaire_tp", True)
    inclure_commentaire_global = options.get("commentaire_global", False)

    story = []
    _entete(story, ds_titre, date_ds)
    story.append(Paragraph(f"NOM et prénom : {_esc(nom_prenom)}", styles["Normal"]))
    story.append(Paragraph(f"Note : <b>{_fmt(note)}/{_fmt(note_sur)}</b>", nom_note_style))
    if inclure_commentaire_global and commentaire_global:
        story.append(Paragraph(f"Commentaire : {_esc(commentaire_global)}", cell_style))
    story.append(Spacer(1, 10))

    entetes = [Paragraph("Compétence", cell_style)]
    largeurs = [3.5 * cm]
    if inclure_capacite:
        entetes.append(Paragraph("Capacité associée", cell_style))
        largeurs.append(5 * cm)
    if inclure_commentaire:
        entetes.append(Paragraph("Commentaire personnel", cell_style))
        largeurs.append(6.5 * cm if inclure_capacite else 11.5 * cm)
    entetes.append(Paragraph("Niveau", cell_style))
    largeurs.append(2 * cm)
    data = [entetes]
    for q in questions:
        g = grades.get(q["id"], {}) or {}
        niveau = g.get("niveau") or "-"
        ligne = [Paragraph(f"<b>{_esc(q['label'])}</b><br/>{_esc(q['competence'])}", cell_style)]
        if inclure_capacite:
            ligne.append(Paragraph(_esc(q.get("detail") or ""), cell_style))
        if inclure_commentaire:
            ligne.append(Paragraph(_esc(grade_comments.get(q["id"], "") or ""), cell_style))
        ligne.append(_cell_niveau(
            niveau, evolution.get(q["competence"]) if inclure_evolution else None,
            suite=f"(poids : {_fmt(q['bareme'])})"))
        data.append(ligne)
    t = Table(data, colWidths=largeurs)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("FONTSIZE", (0, 0), (-1, -1), cell_style.fontSize),
    ]))
    story.append(t)
    if inclure_evolution and _a_des_fleches(evolution):
        story.append(Spacer(1, 3))
        story.append(_legende_evolution("par rapport à l'évaluation précédente de cette compétence."))
    if inclure_capacite:
        story.append(Spacer(1, 4))
        story.append(Paragraph(
            "Capacité associée : capacité(s) du référentiel visée(s), ou observables et critères "
            "de réussite attendus pour ce TP, selon le choix de l'enseignant.",
            petit_gris_style,
        ))
    return story


def build_student_pdf(path, ds_titre, nom_prenom, note, note_sur, commentaire,
                       niveaux_competence, remediation_grid, questions, grades,
                       mode_notation="lettres", type_eval="devoir",
                       note_basse=None, note_haute=None, grade_comments=None, date_ds=None,
                       ajustement=0, options=None, evolution=None):
    doc = SimpleDocTemplate(path, pagesize=A4,
                             topMargin=MARGE, bottomMargin=MARGE,
                             leftMargin=MARGE, rightMargin=MARGE)

    def _faire(opts):
        if type_eval == "tp":
            return _build_tp_story(ds_titre, nom_prenom, note,  note_sur,
                                    note_basse if note_basse is not None else note,
                                    note_haute if note_haute is not None else note,
                                    questions, grades, grade_comments or {}, date_ds, opts,
                                    commentaire_global=commentaire, evolution=evolution)
        return _build_student_story(ds_titre, nom_prenom, note, note_sur, commentaire,
                                     niveaux_competence, remediation_grid, questions, grades,
                                     mode_notation, date_ds, ajustement, opts,
                                     grade_comments=grade_comments, evolution=evolution)

    options = dict(options or {})
    if options.get("taille") == "auto":
        options["taille"] = _taille_auto([lambda t: _faire({**options, "taille": t})])
    story = _faire(options)
    doc.build(story)


TAILLES_AUTO = [9, 8.5, 8, 7.5, 7, 6.5]   # du plus lisible au plus compact


def _taille_auto(fabriques, pages_max=2):
    """Plus grande taille de texte pour laquelle TOUS les rapports tiennent en `pages_max` pages
    (une feuille recto-verso). `fabriques` : fonctions taille -> story. Si rien ne tient, la plus petite."""
    for t in TAILLES_AUTO:
        if all(_compter_pages(f(t)) <= pages_max for f in fabriques):
            return t
    return TAILLES_AUTO[-1]


def _story_eleve(s, ds_titre, type_eval, date_ds, options):
    if type_eval == "tp":
        return _build_tp_story(
            ds_titre, s["nom_prenom"], s["note"], s["note_sur"],
            s.get("note_basse", s["note"]), s.get("note_haute", s["note"]),
            s["questions"], s["grades"], s.get("grade_comments") or {}, date_ds, options,
            commentaire_global=s.get("commentaire"), evolution=s.get("evolution"),
        )
    return _build_student_story(
        ds_titre, s["nom_prenom"], s["note"], s["note_sur"], s["commentaire"],
        s["niveaux_competence"], s["remediation_grid"], s["questions"], s["grades"],
        s.get("mode_notation", "lettres"), date_ds, s.get("ajustement", 0), options,
        grade_comments=s.get("grade_comments"), evolution=s.get("evolution"),
    )


def _compter_pages(story):
    """Nombre de pages qu'occupera ce rapport (mise en page d'essai, rien n'est enregistré)."""
    d = SimpleDocTemplate(BytesIO(), pagesize=A4, topMargin=MARGE, bottomMargin=MARGE,
                          leftMargin=MARGE, rightMargin=MARGE)
    d.build(story)
    return d.page


def build_combined_pdf(path, ds_titre, students_data, type_eval="devoir", date_ds=None, options=None):
    """students_data : liste de dicts avec les mêmes clés que build_student_pdf
    (nom_prenom, note, note_sur, commentaire, niveaux_competence, remediation_grid,
    questions, grades, mode_notation, ajustement, et pour le TP : note_basse, note_haute,
    grade_comments) — un élève par entrée, séparés par un saut de page.
    options["recto_verso"] : chaque élève occupe un nombre PAIR de pages (une page blanche est ajoutée
    si son rapport en compte un nombre impair) : imprimé en recto-verso, chaque élève a sa feuille."""
    doc = SimpleDocTemplate(path, pagesize=A4,
                             topMargin=MARGE, bottomMargin=MARGE,
                             leftMargin=MARGE, rightMargin=MARGE)
    options = dict(options or {})
    recto_verso = bool(options.get("recto_verso"))
    if options.get("taille") == "auto":
        options["taille"] = _taille_auto(
            [(lambda t, s=s: _story_eleve(s, ds_titre, type_eval, date_ds, {**options, "taille": t}))
             for s in students_data])
    story = []
    for i, s in enumerate(students_data):
        story.extend(_story_eleve(s, ds_titre, type_eval, date_ds, options))
        if i < len(students_data) - 1:
            if recto_verso and _compter_pages(_story_eleve(s, ds_titre, type_eval, date_ds, options)) % 2 == 1:
                story.extend([PageBreak(), Spacer(1, 1)])  # verso laissé blanc
            story.append(PageBreak())
    doc.build(story)


def build_bilan_periode_pdf(path, classe_nom, debut_str, fin_str, competences, rows, devoirs_inclus):
    """Bilan de compétences agrégé sur une période (conseil de classe, bulletin).
    rows : liste de dicts {"Élève": nom, compétence1: niveau, compétence2: niveau, ...}
    devoirs_inclus : liste des titres de devoirs pris en compte, pour la légende."""
    _appliquer_taille(9)  # ces documents gardent la taille de texte d'origine
    doc = SimpleDocTemplate(path, pagesize=A4,
                             topMargin=1.5 * cm, bottomMargin=1.5 * cm,
                             leftMargin=1.5 * cm, rightMargin=1.5 * cm)
    story = []
    story.append(Paragraph(f"Bilan de compétences — {_esc(classe_nom)}", title_style))
    story.append(Spacer(1, 4))
    story.append(HRFlowable(width="100%", thickness=1.5, color=COULEUR_ACCENT, spaceAfter=4))
    story.append(Paragraph(f"Période du {_esc(str(debut_str))} au {_esc(str(fin_str))}", date_style))
    story.append(Spacer(1, 8))

    if devoirs_inclus:
        story.append(Paragraph("Devoirs pris en compte : " + _esc(", ".join(devoirs_inclus)), petit_gris_style))
        story.append(Spacer(1, 10))

    data = [["Élève"] + competences]
    for row in rows:
        data.append([row["Élève"]] + [row.get(c, "—") for c in competences])

    largeur_utile = 18 * cm
    largeur_eleve = min(5 * cm, largeur_utile * 0.35)
    largeur_comp = (largeur_utile - largeur_eleve) / max(len(competences), 1)
    col_widths = [largeur_eleve] + [largeur_comp] * len(competences)

    t = Table(data, colWidths=col_widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (-1, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))
    story.append(Paragraph(
        "A = très satisfaisant · B = satisfaisant · C = fragile · D = insuffisant · "
        "— = non évalué sur cette période.",
        petit_gris_style,
    ))
    doc.build(story)


# ---------- Rapport « bilan » sur plusieurs évaluations ----------

cell_centre_style = ParagraphStyle("cell_centre", parent=cell_style, alignment=TA_CENTER)
en_tete_eval_style = ParagraphStyle("en_tete_eval", parent=cell_style, fontSize=7.5, leading=9,
                                    alignment=TA_CENTER)


def _fmt_date_iso(iso):
    try:
        return datetime.strptime(iso, "%Y-%m-%d").strftime("%d/%m/%Y") if iso else ""
    except ValueError:
        return iso or ""


def _build_bilan_story(classe_nom, debut, fin, nom_prenom, data, options, largeur_utile):
    options = options or {}
    inclure_notes = options.get("notes", True)
    inclure_tendance = options.get("tendance", True)
    devoirs = data["devoirs"]
    competences = data["competences"]
    bilan = data["bilan"]
    tendance = data["tendance"] if inclure_tendance else {}

    story = []
    story.append(Paragraph("Bilan de compétences", title_style))
    story.append(Spacer(1, 4))
    story.append(HRFlowable(width="100%", thickness=1.5, color=COULEUR_ACCENT, spaceAfter=4))
    periode = f"du {debut} au {fin}" if debut and fin and debut != fin else (debut or "")
    story.append(Paragraph(f"{_esc(classe_nom)} — {_esc(periode)} — {len(devoirs)} évaluation(s)", date_style))
    story.append(Spacer(1, 6))
    story.append(Paragraph(f"NOM et prénom : {_esc(nom_prenom)}", nom_note_style))
    story.append(Spacer(1, 10))

    # En-tête : une colonne par évaluation (titre + date), puis la colonne « Bilan »
    entetes = [Paragraph("<b>Compétence</b>", cell_style)]
    for d in devoirs:
        titre = d["titre"] if len(d["titre"]) <= 42 else d["titre"][:40] + "..."
        suffixe = " — formatif" if d["nature"] == "formative" else ""
        entetes.append(Paragraph(
            f"<b>{_esc(titre)}</b><br/><font size=6 color='grey'>{_fmt_date_iso(d['date_ds'])}{suffixe}</font>",
            en_tete_eval_style))
    entetes.append(Paragraph("<b>Bilan</b>", cell_centre_style))
    data_table = [entetes]

    for comp in competences:
        ligne = [Paragraph(f"<b>{_esc(comp)}</b>", cell_style)]
        for d in devoirs:
            ligne.append(Paragraph(d["niveaux"].get(comp, "<font color='grey'>—</font>"), cell_centre_style))
        if comp in bilan:
            ligne.append(_cell_niveau(f"<b>{bilan[comp]}</b>", tendance.get(comp),
                                      style=cell_centre_style, align="CENTER"))
        else:
            ligne.append(Paragraph("<font color='grey'>—</font>", cell_centre_style))
        data_table.append(ligne)

    if inclure_notes:
        ligne_notes = [Paragraph("<b>Note</b>", cell_style)]
        for d in devoirs:
            if d["note"] is None:
                ligne_notes.append(Paragraph("<font color='grey'>—</font>", cell_centre_style))
            else:
                ligne_notes.append(Paragraph(f"{_fmt(d['note'])}/{_fmt(d['note_sur'])}", cell_centre_style))
        ligne_notes.append(Paragraph("", cell_centre_style))
        data_table.append(ligne_notes)

    largeur_comp, largeur_bilan = 3.6 * cm, 2.2 * cm
    largeur_eval = min(3.2 * cm, (largeur_utile - largeur_comp - largeur_bilan) / max(len(devoirs), 1))
    t = Table(data_table, colWidths=[largeur_comp] + [largeur_eval] * len(devoirs) + [largeur_bilan],
              repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
    ]
    if inclure_notes:
        style.append(("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#F3F4F6")))
    t.setStyle(TableStyle(style))
    story.append(t)
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "A = très satisfaisant · B = satisfaisant · C = fragile · D = insuffisant · "
        "— = non évalué. Bilan = niveau sur l'ensemble des évaluations retenues (points cumulés "
        "par compétence).", petit_gris_style))
    if inclure_tendance and tendance and _a_des_fleches(tendance):
        story.append(Spacer(1, 3))
        story.append(_legende_evolution("entre les deux dernières évaluations de la compétence."))
    return story


def build_bilan_pdf(path, classe_nom, debut, fin, students, options=None):
    """Rapport « bilan » : un élève par page (ou plus si besoin), à partir de plusieurs évaluations.
    students : liste de {"nom_prenom": ..., "data": db.bilan_eleve(...)}. Le PDF passe en format
    paysage dès que le nombre d'évaluations dépasse 6 pour garder les colonnes lisibles."""
    _appliquer_taille(9)  # ces documents gardent la taille de texte d'origine
    nb_evals = max((len(s["data"]["devoirs"]) for s in students), default=0)
    page = landscape(A4) if nb_evals > 6 else A4
    doc = SimpleDocTemplate(path, pagesize=page,
                             topMargin=1.5 * cm, bottomMargin=1.5 * cm,
                             leftMargin=1.5 * cm, rightMargin=1.5 * cm)
    largeur_utile = page[0] - 3 * cm
    story = []
    for i, s in enumerate(students):
        story.extend(_build_bilan_story(classe_nom, debut, fin, s["nom_prenom"], s["data"],
                                        options, largeur_utile))
        if i < len(students) - 1:
            story.append(PageBreak())
    doc.build(story)


def build_fiche_tp_pdf(titre, classe_nom, date_ds, questions, eleves=None):
    """Fiche d'évaluation d'un TP À IMPRIMER pour l'évaluateur : compétence, capacité associée,
    observables/critères de réussite, cases A/B/C/D à cocher et zone de remarques.
    eleves = None -> une seule fiche vierge ; sinon liste de (nom_prenom, besoins) -> une page
    par élève, avec ses besoins particuliers (PAP, tiers-temps...) bien visibles en haut."""
    _appliquer_taille(9)  # ces documents gardent la taille de texte d'origine
    import io
    from xml.sax.saxutils import escape
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=1.2 * cm, rightMargin=1.2 * cm,
                            topMargin=1.0 * cm, bottomMargin=1.0 * cm,
                            title=f"Fiche d'évaluation — {titre}")
    petit = ParagraphStyle("fiche_cell", parent=cell_style, fontSize=8, leading=10)
    entete = ParagraphStyle("fiche_head", parent=cell_style, fontName="Helvetica-Bold", fontSize=8.5,
                            alignment=TA_CENTER)
    alerte = ParagraphStyle("fiche_alerte", parent=cell_style, fontName="Helvetica-Bold",
                            fontSize=10, textColor=colors.HexColor("#B91C1C"))
    cases = [(nom, bes) for nom, bes in (eleves or [(None, None)])]
    story = []
    largeurs = [3.4 * cm, 5.2 * cm, 8.4 * cm, 0.9 * cm, 0.9 * cm, 0.9 * cm, 0.9 * cm, 5.8 * cm]
    for k, (nom, besoins) in enumerate(cases):
        if k:
            story.append(PageBreak())
        story.append(Paragraph(f"Fiche d'évaluation — {escape(titre)}", title_style))
        sous = [escape(classe_nom)]
        if _fmt_date(date_ds):
            sous.append(_fmt_date(date_ds))
        story.append(Paragraph(" · ".join(sous), date_style))
        story.append(Spacer(1, 6))
        story.append(Paragraph(
            f"Nom, prénom : <b>{escape(nom)}</b>" if nom else
            "Nom, prénom : ................................................................", nom_note_style))
        if besoins:
            story.append(Paragraph(f"⚠ Besoins particuliers : {escape(besoins)}".replace("⚠", "(!)"),
                                   alerte))
            story.append(Spacer(1, 4))
        data = [[Paragraph("Compétence", entete), Paragraph("Capacité associée", entete),
                 Paragraph("Observables / critères de réussite", entete),
                 Paragraph("A", entete), Paragraph("B", entete), Paragraph("C", entete),
                 Paragraph("D", entete), Paragraph("Remarques", entete)]]
        for q in questions:
            crit = (q.get("criteres") or "").strip()
            lignes = [l.strip(" -•\t") for l in crit.splitlines() if l.strip(" -•\t")]
            crit_html = "<br/>".join("• " + escape(l) for l in lignes)
            data.append([
                Paragraph(f"<b>{escape(q['label'])}</b><br/>{escape(q['competence'])}", petit),
                Paragraph(escape(q.get("detail") or "").replace("\n", "<br/>"), petit),
                Paragraph(crit_html, petit), "", "", "", "", ""])
        t = Table(data, colWidths=largeurs, repeatRows=1)
        t.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("BACKGROUND", (0, 0), (-1, 0), COULEUR_ENTETE),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 1), (-1, -1), 4), ("BOTTOMPADDING", (0, 1), (-1, -1), 12),
        ]))
        story.append(t)
        story.append(Spacer(1, 8))
        story.append(Paragraph("Appréciation générale : "
                               "....................................................................."
                               "....................................................................."
                               "...............", cell_style))
    doc.build(story)
    return buf.getvalue()
