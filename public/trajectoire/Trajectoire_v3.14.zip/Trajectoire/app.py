import io
import os
import re
import sqlite3
import tempfile
import zipfile
from datetime import date, datetime
import altair as alt
import numpy as np
import pandas as pd
import streamlit as st

import db
from pdf_report import build_student_pdf, build_combined_pdf, build_bilan_periode_pdf, build_bilan_pdf, build_fiche_tp_pdf

st.set_page_config(page_title="Trajectoire", layout="wide")


def _chemin_court(chemin):
    """Chemin lisible : le dossier personnel est remplacé par « ~ »."""
    c = str(chemin)
    home = str(os.path.expanduser("~"))
    return "~" + c[len(home):] if c.startswith(home) else c


def _date_lisible(d):
    return d.strftime("%d/%m/%Y à %H:%M")


# --- Premier lancement avec le nouveau dossier de données : reprise d'une ancienne base (copie_helper.db)
if not os.path.exists(db.DB_PATH):
    _cands = db.candidats_anciennes_bases()
    _pool = [c for c in _cands if not c["demo"]] or _cands
    if len(_pool) == 1:
        db.reprendre_base(_pool[0]["chemin"])
        st.session_state["_reprise_message"] = (
            f"Tes données ont été reprises automatiquement depuis « {_chemin_court(_pool[0]['chemin'])} » "
            f"({_pool[0]['classes']} classe(s), {_pool[0]['eleves']} élève(s), {_pool[0]['devoirs']} devoir(s)). "
            f"Elles sont désormais dans « {_chemin_court(db.DOSSIER_DONNEES)} » ; l'ancien fichier n'a pas été modifié.")
    elif len(_pool) > 1:
        st.title("🎓 Trajectoire — reprise de tes données")
        st.info("Plusieurs anciennes bases de données ont été trouvées sur cet ordinateur. Choisis celle à "
                "reprendre (en général la plus récente, avec le plus de devoirs). Aucun fichier n'est "
                "modifié ni supprimé : ils restent tous où ils sont.")
        _libs = [f"{_date_lisible(c['modif'])} — {c['classes']} classe(s), {c['eleves']} élève(s), "
                 f"{c['devoirs']} devoir(s)" + (" (base de démonstration)" if c["demo"] else "")
                 + f" — {_chemin_court(c['chemin'])}" for c in _pool]
        _choix = st.radio("Base à reprendre", list(range(len(_pool))), format_func=lambda i: _libs[i])
        _b1, _b2 = st.columns(2)
        if _b1.button("✅ Reprendre cette base", type="primary"):
            db.reprendre_base(_pool[_choix]["chemin"])
            st.session_state["_reprise_message"] = (
                f"Tes données ont été reprises depuis « {_chemin_court(_pool[_choix]['chemin'])} ». "
                f"Elles sont désormais dans « {_chemin_court(db.DOSSIER_DONNEES)} ».")
            st.rerun()
        if _b2.button("Commencer sans données"):
            db.init_db()
            st.rerun()
        st.stop()

db.init_db()
try:
    db.sauvegarde_auto()      # copie de sécurité (s'il y a eu des modifications, au plus 1 par heure)
    db.sauvegarde_miroir()    # copie dans le second dossier, si l'utilisateur en a choisi un
except Exception:
    pass  # une sauvegarde ratée ne doit jamais empêcher d'utiliser l'appli

APP_VERSION = "3.14"

COMPETENCES_OPTIONS = ["S'APP", "ANA", "REA", "VAL", "COM", "Complexe"]


def _options_listes_competences():
    """dict libellé affiché -> valeur stockée en base (sentinelle ou nom de liste personnalisée)."""
    opts = {
        "Par défaut (S'APP / ANA / REA / VAL / COM / Complexe)": db.LISTE_COMPETENCES_DEFAUT,
        "Sans compétence (une seule catégorie « Général »)": db.LISTE_COMPETENCES_AUCUNE,
    }
    for liste in db.list_competence_lists():
        opts[f"{liste['nom']} (liste personnalisée)"] = liste["nom"]
    return opts


def _nom_fichier(texte):
    """Nettoie un texte libre (nom de classe, titre de devoir...) pour en faire un nom de
    fichier valide sur tous les systèmes, en remplaçant les caractères interdits (le cas le
    plus courant étant un « / » dans une année scolaire, ex. « 25/26 »)."""
    interdits = '/\\:*?"<>|'
    nettoye = "".join("-" if c in interdits else c for c in str(texte))
    return nettoye.strip()


def _a_des_notes(grades):
    return any((g.get("niveau") or g.get("points") is not None) for g in grades.values())


def _pdf_en_memoire(construire, *args, **kwargs):
    """Construit un PDF directement en mémoire (rien n'est écrit sur le disque : les fiches portent
    des noms d'élèves) et renvoie ses octets."""
    tampon = io.BytesIO()
    construire(tampon, *args, **kwargs)
    return tampon.getvalue()


def _a_une_correction(res):
    """True si l'élève a au moins une note saisie (ou une note finale manuelle) sur ce devoir."""
    return _a_des_notes(res["grades"]) or res.get("note_manuelle") is not None


def _paliers_points(bareme):
    """Boutons de points d'une question : NC, puis tous les quarts de point jusqu'au barème, et le
    barème lui-même s'il n'est pas un multiple de 0,25 (sinon on ne pourrait pas donner tous les
    points : barème de 1,3 → ..., 1, 1,25, 1,3)."""
    paliers = [round(x * 0.25, 2) for x in range(int(bareme / 0.25 + 1e-9) + 1)]
    if bareme > 0 and abs(paliers[-1] - bareme) > 1e-9:
        paliers.append(round(bareme, 2))
    return ["NC"] + paliers


def _appliquer_ou_confirmer_questions(ds_id, qs, message_ok):
    """Enregistre la liste de questions ; mais si cela fait disparaître des notes déjà saisies
    (question retirée, ou remplacée par « Générer » / « Charger une grille »), met l'opération en
    attente et demande confirmation d'abord (voir _bloc_confirmation_questions). Retourne True si
    la liste a été enregistrée tout de suite."""
    perdues = db.notes_qui_seraient_effacees(ds_id, qs)
    if perdues > 0:
        st.session_state[f"qs_attente_{ds_id}"] = (qs, message_ok, perdues)
        return False
    db.set_questions(ds_id, qs)
    return True


def _interface_ponderations(liste_ds, prefixe):
    """Un champ « poids » par évaluation (enregistré aussitôt en base, valable pour tous les bilans).
    Retourne la liste des évaluations rechargées avec leurs poids à jour."""
    st.caption("Poids de chaque évaluation dans le bilan : une évaluation de poids 2 compte deux fois plus "
               "qu'une de poids 1, quel que soit son barème (un TP sur 4 et un DS sur 20 pèsent pareil à "
               "poids égal). Mets 0 pour l'écarter du calcul.")
    for d in liste_ds:
        courant = d.get("ponderation")
        courant = 1.0 if courant is None else float(courant)
        nouveau = st.number_input(f"{d['titre']}", min_value=0.0, max_value=100.0, value=courant, step=0.5,
                                  key=f"pond_{prefixe}_{d['id']}")
        if abs(nouveau - courant) > 1e-9:
            db.set_ds_ponderation(d["id"], nouveau)
    return [db.get_ds(d["id"]) for d in liste_ds]


def _bloc_confirmation_questions(ds_id):
    flash = st.session_state.pop(f"qs_flash_{ds_id}", None)
    if flash:
        st.success(flash)
    attente = st.session_state.get(f"qs_attente_{ds_id}")
    if not attente:
        return
    qs, message_ok, perdues = attente
    st.warning(f"⚠️ Cet enregistrement efface **{perdues} note(s) déjà saisie(s)** (question(s) retirée(s) "
               f"de la liste). Les notes des questions conservées, même renommées, ne bougent pas. "
               f"La suppression est définitive.")
    c1, c2 = st.columns(2)
    if c1.button("Oui, effacer ces notes et enregistrer", type="primary", key=f"qs_oui_{ds_id}"):
        db.set_questions(ds_id, qs)
        st.session_state.pop(f"qs_attente_{ds_id}", None)
        st.session_state[f"qs_flash_{ds_id}"] = message_ok
        st.rerun()
    if c2.button("Annuler", key=f"qs_non_{ds_id}"):
        st.session_state.pop(f"qs_attente_{ds_id}", None)
        st.rerun()


def _enregistrer_saisies_en_attente():
    """Enregistre en base tout texte / nombre déjà validé dans le navigateur mais pas encore écrit :
    commentaires, ajustement, note finale de TP. Appelée à CHAQUE affichage, avant d'afficher la page :
    si on tape un commentaire puis qu'on clique directement sur une autre page du menu, le champ
    n'existe plus à l'affichage suivant et sa valeur serait perdue — c'est ici qu'on la récupère."""
    ss = st.session_state
    for cle in list(ss.keys()):
        if not isinstance(cle, str):
            continue
        try:
            valeur = ss[cle]
            m = re.fullmatch(r"(commentaire_general|commentaire_global)_(\d+)_(\d+)", cle)
            if m and isinstance(valeur, str):
                ds_i, sid_i = int(m.group(2)), int(m.group(3))
                if valeur != db.get_comment(ds_i, sid_i):
                    db.set_comment(ds_i, sid_i, valeur)
                continue
            m = re.fullmatch(r"ajust_(\d+)_(\d+)", cle)
            if m and isinstance(valeur, (int, float)):
                ds_i, sid_i = int(m.group(1)), int(m.group(2))
                if abs(valeur - db.get_ajustement(ds_i, sid_i)) > 1e-9:
                    db.set_ajustement(ds_i, sid_i, float(valeur))
                continue
            m = re.fullmatch(r"(qc|gc)_(\d+)_(\d+)_(\d+)", cle)
            if m and isinstance(valeur, str):
                ds_i, sid_i, q_i = int(m.group(2)), int(m.group(3)), int(m.group(4))
                if valeur != db.get_grade_comments(ds_i, sid_i).get(q_i, ""):
                    db.set_grade_comment(ds_i, sid_i, q_i, valeur)
                continue
            m = re.fullmatch(r"notefinale_(\d+)_(\d+)", cle)
            if m and isinstance(valeur, (int, float)):
                ds_i, sid_i = int(m.group(1)), int(m.group(2))
                if db.get_ds(ds_i) is None:
                    continue
                res_i = db.compute_student_result(ds_i, sid_i)
                actuelle = res_i["note_manuelle"] if res_i["note_manuelle"] is not None else res_i["note_calculee"]
                if abs(float(valeur) - actuelle) > 1e-9 and 0 <= valeur <= res_i["note_sur"]:
                    db.set_note_manuelle(ds_i, sid_i, float(valeur))
        except Exception:
            continue  # une saisie qu'on ne sait pas enregistrer ne doit jamais bloquer l'affichage


def _note_sur_20(res):
    return res["note"] * 20 / res["note_sur"] if res["note_sur"] else res["note"]


def _appliquer_pending_comment():
    """À appeler une fois en tout début de script, avant tout widget : applique la valeur d'un
    bouton de la banque de commentaires cliqué au tour précédent, avant que le text_area visé
    ne soit instancié."""
    pending_key = st.session_state.pop("_pending_comment_key", None)
    pending_val = st.session_state.pop("_pending_comment_value", None)
    if pending_key is not None:
        st.session_state[pending_key] = pending_val


def _enregistrer_saisies_eleve(ds_id, sid, questions):
    """Enregistre en base ce qui est saisi (mais pas encore sauvegardé) pour CET élève : commentaire
    général, ajustement, commentaires par question. À appeler AVANT de changer d'élève : si on
    clique sur Suivant/Précédent juste après avoir tapé, le champ n'existe plus au tour suivant et
    sa valeur serait perdue. Les valeurs sont lues dans l'état de la session (valeurs validées par
    le navigateur au moment du clic)."""
    ss = st.session_state
    for cle in (f"commentaire_general_{ds_id}_{sid}", f"commentaire_global_{ds_id}_{sid}"):
        if cle in ss and isinstance(ss[cle], str) and ss[cle] != db.get_comment(ds_id, sid):
            db.set_comment(ds_id, sid, ss[cle])
    cle_aj = f"ajust_{ds_id}_{sid}"
    if cle_aj in ss and isinstance(ss[cle_aj], (int, float)) \
            and abs(ss[cle_aj] - db.get_ajustement(ds_id, sid)) > 1e-9:
        db.set_ajustement(ds_id, sid, ss[cle_aj])
    deja = None
    for q in questions:
        for prefixe in ("qc", "gc"):
            cle = f"{prefixe}_{ds_id}_{sid}_{q['id']}"
            if cle in ss and isinstance(ss[cle], str):
                if deja is None:
                    deja = db.get_grade_comments(ds_id, sid)
                if ss[cle] != deja.get(q["id"], ""):
                    db.set_grade_comment(ds_id, sid, q["id"], ss[cle])


def _boutons_palier(paliers, valeur_actuelle, key_prefix, max_par_ligne=8):
    """Paliers de points en boutons cliquables (1 clic, comme les niveaux A/B/C/D) plutôt qu'un
    menu déroulant (2 clics) : "NC" (non corrigé) + chaque valeur du barème, répartis sur
    plusieurs lignes si le barème en donne beaucoup. Retourne la valeur cliquée ce tour-ci,
    ou None si aucun clic (la sélection en cours reste visible via le bouton mis en avant)."""
    clique = None
    for depart in range(0, len(paliers), max_par_ligne):
        lot = paliers[depart:depart + max_par_ligne]
        cols = st.columns(len(lot))
        for i, p in enumerate(lot):
            libelle = "NC" if p == "NC" else f"{p:g}"
            type_bouton = "primary" if p == valeur_actuelle else "secondary"
            if cols[i].button(libelle, key=f"{key_prefix}_{p}", type=type_bouton,
                               width="stretch"):
                clique = p
    return clique


def _champ_commentaire_avec_banque(label, key, value, placeholder="", height=None,
                                    label_visibility="visible", commentaires_recents=None,
                                    inclure_banque_globale=True):
    """text_area avec, juste en dessous, les boutons de la banque de commentaires réutilisables
    (globale, sur tous les devoirs — pertinente pour un retour ciblé par question, pas pour une
    appréciation globale, d'où inclure_banque_globale) et, si fournis, les commentaires déjà
    utilisés sur CE devoir précis — cliquer sur un bouton préremplit le champ (nécessite un
    st.rerun, déjà géré ici)."""
    texte = st.text_area(label, value=value, key=key, placeholder=placeholder, height=height,
                          label_visibility=label_visibility)
    suggestions = st.session_state.get("_suggestions_actives", False)
    if inclure_banque_globale and suggestions:
        banque = db.list_comment_bank()
        if banque:
            cols = st.columns(min(len(banque), 4))
            for i, c in enumerate(banque):
                if cols[i % len(cols)].button(c["texte"], key=f"banque_{key}_{c['id']}"):
                    st.session_state["_pending_comment_key"] = key
                    st.session_state["_pending_comment_value"] = c["texte"]
                    st.rerun()
    if commentaires_recents and suggestions:
        st.caption("Déjà utilisé pour ce devoir :")
        cols2 = st.columns(min(len(commentaires_recents), 4))
        for i, txt in enumerate(commentaires_recents):
            libelle = txt if len(txt) <= 30 else txt[:27] + "..."
            if cols2[i % len(cols2)].button(libelle, key=f"recent_{key}_{i}", help=txt):
                st.session_state["_pending_comment_key"] = key
                st.session_state["_pending_comment_value"] = txt
                st.rerun()
    return texte


def _label_pour_valeur_liste(valeur, options_listes):
    for label, v in options_listes.items():
        if v == valeur:
            return label
    return list(options_listes.keys())[0]

TYPE_EVAL_LABELS = {
    "devoir": "📝 Évaluation avec questions notées une par une, de manière chiffrée ou par compétences",
    "tp": "🧪 Évaluation globale par compétence (type CCF en BTS MDC ou ECE en Terminale STL ou Générale)",
}


def _graphique_ligne_points(df, x_col, y_col):
    """Ligne + points bien visibles (st.line_chart seul ne sait pas afficher les points)."""
    base = alt.Chart(df).encode(
        x=alt.X(f"{x_col}:N", title=x_col, sort=None),
        y=alt.Y(f"{y_col}:Q", title=y_col),
    )
    ligne = base.mark_line(color="#2563EB")
    points = base.mark_point(size=70, filled=True, color="#2563EB")
    return (ligne + points).properties(height=320)


def _valider_sauvegarde(chemin):
    """Vérifie qu'un fichier .db est une sauvegarde exploitable avant de l'utiliser pour restaurer."""
    try:
        conn = sqlite3.connect(chemin)
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"classes", "ds", "students"}.issubset(tables):
            conn.close()
            return False, "tables attendues manquantes — ce n'est probablement pas une sauvegarde de cette appli"
        n_classes = conn.execute("SELECT COUNT(*) FROM classes").fetchone()[0]
        n_eleves = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        n_ds = conn.execute("SELECT COUNT(*) FROM ds").fetchone()[0]
        conn.close()
        return True, f"{n_classes} classe(s), {n_eleves} élève(s), {n_ds} devoir(s)"
    except Exception as e:
        return False, str(e)

PROMPT_LIENS_BLOC = """
=====================================================
AJOUT — RESSOURCES DU SITE « PAILLASSE VIRTUELLE » (CODES)
=====================================================
En plus du texte, tu dois proposer pour chaque compétence × niveau des
EXERCICES du site « Paillasse virtuelle » (jamais de simulation), choisis UNIQUEMENT
dans le catalogue du site. Le CSV a donc 6 colonnes (et non 3) :
competence;niveau;texte;liens_ds;liens_suivant;liens
- liens_ds : exercices du CHAPITRE DU DEVOIR (pour consolider) ;
- liens_suivant : exercices du CHAPITRE SUIVANT (pour préparer le prochain devoir) ;
- liens : exercices SANS notion de chapitre (uniquement pour REA, voir règle 2).

La fiche de l'élève est imprimée sur papier : l'élève retrouve chaque ressource
en tapant son CODE (ex. ANA118) sur le site. Ne produis donc ni adresse web ni
lien : uniquement des codes.

Le catalogue est le fichier catalogue.csv (séparateur « ; », UTF-8) joint à
cette conversation. À défaut, il est lisible à l'adresse
https://paillasse-virtuelle.fr/catalogue.csv
Si tu n'as accès ni au fichier joint ni à cette adresse, ARRÊTE-TOI et dis-le :
ne produis aucun code de mémoire. Lis les colonnes par leur NOM d'en-tête, pas
par leur position.

Colonnes du catalogue : type (simulation ou exercice), id, lien, niveau, chapitre,
competence (S'approprier, Analyser, Réaliser, Valider ; VIDE pour les simulations),
difficulte (1 facile à 3 difficile), theme, titre, description, simulations_liees, code,
taches (tâches travaillées par l'exercice, ex. « tableau bilan », « instruction Arduino »).
- Les simulations n'ont pas de compétence associée : elles ne peuvent pas servir à
  remédier à une compétence précise et ne sont JAMAIS proposées. Seules les lignes
  de type = exercice sont utilisables.
- code : SAPP+numéro, ANA+numéro, REA+numéro, VAL+numéro pour les exercices
  (ex. ANA118). Les codes sont définitifs.
  Le code est TOUJOURS recopié depuis la colonne « code », jamais déduit ni
  inventé. Si une ressource éligible n'a pas de code (cas anormal), ne la
  propose pas.
- L'id d'un exercice est de la forme « 34:paroi.0 » : le nombre avant « : » est la
  simulation « par compétence » dont il dépend (ici sim34).

Contexte de ce devoir :
- Niveau de la classe : {niveau_classe}
- Chapitre du devoir : {chapitre_ds}
- Chapitre suivant : {chapitre_suivant}

Règles de choix des ressources (à respecter strictement) :
1. Correspondance des compétences : S'APP = « S'approprier », ANA = « Analyser »,
   REA = « Réaliser », VAL = « Valider ». Pour toute autre compétence de la liste du
   devoir (COM, Complexe, Général, etc.) : AUCUNE ressource (les trois colonnes de liens
   vides) ; une telle compétence n'est traitée que si elle figure dans la liste.
2. Seuls les exercices (type = exercice) dont la colonne niveau est « {niveau_classe} »
   (ou contient ce niveau) sont éligibles. Pour S'APP, ANA et VAL : liens_ds ne contient
   QUE des exercices dont le chapitre est exactement « {chapitre_ds} », liens_suivant
   QUE des exercices dont le chapitre est exactement « {chapitre_suivant} » ; la colonne
   liens reste vide. EXCEPTION pour REA : mets dans la colonne liens 1 SEUL exercice
   de compétence « Réaliser », soit de niveau « tous », soit de niveau {niveau_classe}
   (tu peux donc retenir un exercice REA du chapitre du devoir) ; liens_ds et
   liens_suivant restent vides pour REA.
3. Les colonnes liens_ds et liens_suivant ne contiennent que des exercices (type
   exercice), jamais de simulation. L'exercice choisi doit avoir la compétence évaluée
   dans la colonne competence du catalogue.
4. Pour S'APP, ANA et VAL, chaque cellule contient au moins 1 exercice dans liens_ds ET
   au moins 1 dans liens_suivant, et jamais moins dans liens_suivant que dans liens_ds
   (le chapitre suivant est prioritaire).
5. Nombre d'exercices : niveau A = 1 dans liens_ds + 1 dans liens_suivant ; niveau B =
   1 dans liens_ds + 2 dans liens_suivant ; niveaux C et D = 2 dans liens_ds + 2 dans
   liens_suivant.
6. Difficulté (colonne difficulte, quand elle existe) : A → 3 ou 2 ; B → 2 ; C → 1 ou 2 ;
   D → 1.
7. Choix dans liens_ds (chapitre du devoir) : utilise la colonne taches du catalogue pour
   retenir en priorité les exercices dont les tâches correspondent aux questions du
   devoir (ex. « tableau bilan », « instruction Arduino », « conformité cahier des
   charges »). Si taches ne permet pas de départager, base-toi sur le titre et la
   description.
8. Aucun exercice ne se répète pour une même compétence, d'un niveau à l'autre.
9. Si le catalogue ne contient pas assez d'exercices éligibles, propose-en moins ;
   n'invente JAMAIS un code, un titre ou un chapitre, ne répète pas un exercice pour
   compléter, et ne complète jamais avec un autre niveau ou un autre chapitre.
10. Dans le texte de remédiation (colonne texte) : ni code ni adresse. Tu peux dire
   « voir les ressources ci-dessous ».
11. Aucune donnée sur un élève n'entre dans ce travail : tu n'utilises que le devoir
   et le catalogue.

Format des colonnes de ressources : une ou plusieurs entrées séparées par ## ,
chaque entrée = CODE | titre | chemin
- CODE : la colonne code du catalogue, recopiée exactement ;
- titre : le titre EXACT de la colonne titre du catalogue ;
- chemin (imprimé sur la fiche, construit UNIQUEMENT à partir du catalogue) :
    Exercices › <titre de la simulation « par compétence » dont l'exercice
    dépend (type = simulation, id = « sim » + nombre avant « : »)>
  Le chemin « Simulations › TSTL › … » n'est plus utilisé.
Exemple d'entrée :
  ANA118 | Prévoir sans calculer — Deux fois plus d'eau avant refroidissement | Exercices › ANA : analyser un problème
Chaque champ de ressources est entouré de guillemets doubles. Pas de retour à la ligne
dans une cellule.

Avant de répondre, vérifie chaque ressource : son code doit exister dans la colonne
code du catalogue, avec exactement ce titre, ce niveau, ce chapitre et cette compétence,
être de type exercice, et se trouver dans la bonne colonne (chapitre du devoir /
chapitre suivant). Supprime toute ressource que tu
ne peux pas vérifier. Si une ressource éligible n'avait pas de code, signale-le par UNE
seule ligne après le CSV, commençant par « ATTENTION : » (seule exception à la règle
« uniquement le CSV »).
"""

PROMPT_REMEDIATION_TEMPLATE = """PROMPT — Génération de remédiations par compétence
=====================================================
(À copier-coller intégralement dans une IA — Claude, ChatGPT, etc. —
en complétant les 2 sections [À COMPLÉTER] avec ton énoncé et ton
corrigé. Colle ensuite le résultat tel quel dans un fichier .csv et
importe-le dans l'appli, onglet Remédiation.)


Tu es un(e) enseignant(e) qui corrige un devoir par compétences. Le
système utilisé note chaque question selon 4 échelons :
- A = très satisfaisant
- B = satisfaisant
- C = fragile
- D = insuffisant

Chaque question est rattachée à UNE compétence. Les compétences de CE
devoir sont uniquement celles de la liste « Compétences effectivement
utilisées dans ce devoir » plus bas (ne tiens compte d'aucune autre
compétence, même si tu en connais d'autres). Le niveau global atteint
sur une compétence donnée dépend du taux de réussite sur toutes les
questions de cette compétence (A si >75%, B si >50%, C si >25%, D
sinon).

Ta tâche : à partir de l'énoncé et du corrigé ci-dessous, rédige une
remédiation pour CHAQUE compétence de cette liste, et pour CHACUN des 4
niveaux (A/B/C/D) — donc une ligne par combinaison compétence×niveau :
{n_lignes} lignes de contenu en tout, ni plus ni moins. N'écris AUCUNE
ligne pour une compétence qui n'est pas dans la liste.

Consignes de fond pour chaque texte de remédiation. IMPORTANT : ce texte
est le même pour tous les élèves qui atteignent ce niveau ; il ne doit
donc JAMAIS deviner ou supposer ce que l'élève a fait ou compris
(interdit : « tu as probablement confondu… », « tu as sans doute
oublié… », « tu fais sûrement l'erreur de… »). Il s'agit d'aider
l'élève à comprendre ce qui se cache derrière la compétence, puis de lui
donner un conseil adapté à son niveau.

Chaque texte contient donc deux parties :
1. Ce qui était attendu. Une phrase qui explique, à partir de l'énoncé
   et du corrigé, ce que la compétence demandait dans ce devoir, avec le
   numéro des questions concernées. Forme type : « Ici, il s'agissait
   d'identifier la grandeur à mesurer (questions 2 et 5). » ou « Ici,
   il fallait justifier le choix de la méthode à partir des données du
   document 1 (question 7). » Cette partie décrit la tâche, pas l'élève.
   Elle peut être reformulée d'un niveau à l'autre, mais doit rester
   fidèle au même contenu.
2. Un conseil en fonction du niveau atteint, formulé à partir du
   résultat obtenu et non de suppositions sur les causes :
   - A : constater que la compétence est maîtrisée sur ce devoir et
     inviter à la mobiliser dans des situations plus complexes ;
   - B : constater une bonne maîtrise avec quelques points à consolider
     et indiquer comment les consolider (type d'exercice, section du
     cours à relire) ;
   - C : constater une maîtrise encore fragile et proposer une piste de
     travail concrète (reprendre telle partie du cours, refaire tel type
     d'exercice) ;
   - D : dire clairement que la compétence est à retravailler car des
     difficultés sont apparues sur ce devoir (ex. « Tu dois retravailler
     cela car tu as rencontré des difficultés sur ce devoir. »), puis
     donner une démarche pour repartir sur de bonnes bases.
   Varie les formulations d'une compétence à l'autre et d'un niveau à
   l'autre : pas de phrase recopiée à l'identique.
- Tutoiement, ton bienveillant mais honnête et exigeant — pas de
  flatterie gratuite, pas de sévérité inutile.
- Contextualisé au devoir réel : références aux numéros de question et
  aux notions précises de l'énoncé/corrigé (pas de généralités
  passe-partout).
- 2 à 3 phrases par texte, pas plus.

Format de sortie — IMPÉRATIF, à respecter strictement :
- Un fichier CSV, séparateur point-virgule ( ; ), encodage UTF-8.
- Exactement 3 colonnes, avec cet en-tête en première ligne :
  competence;niveau;texte
- Une ligne par compétence × niveau listée ci-dessous.
- La colonne "niveau" contient uniquement A, B, C ou D.
- La colonne "competence" reprend exactement le code fourni ci-dessous
  — ne pas inventer d'autres libellés.
- Le texte de remédiation est entre guillemets doubles s'il contient
  une virgule, un point-virgule ou un retour à la ligne.
- Ne renvoie QUE le CSV, sans phrase d'introduction, sans commentaire
  avant ou après, sans balises de code — juste le contenu du fichier,
  prêt à être collé tel quel dans un .csv.

Compétences effectivement utilisées dans ce devoir :
{competences_list}

Énoncé du devoir :
[À COMPLÉTER — colle le texte de l'énoncé, ou joins le PDF directement
à l'IA]

Corrigé du devoir :
[À COMPLÉTER — colle le corrigé/barème détaillé, ou joins le PDF
directement à l'IA]
"""

PAGES_INFO = [
    ("Accueil", "🏠", "Accueil", "Vue d'ensemble de toutes tes classes"),
    ("Élèves", "👤", "Liste des classes et élèves", "Créer une classe, importer ou gérer sa liste d'élèves"),
    ("Devoirs", "📝", "Paramétrisation d'une évaluation",
     "Créer un devoir écrit ou une évaluation par compétences : questions, barème, mode de notation"),
    ("Corriger", "✅", "Corriger", "Noter chaque élève, question par question ou compétence par compétence"),
    ("Résultats", "📊", "Visualisation des résultats",
     "Classement de la classe, dispersion des notes, suivi dans le temps"),
    ("Remédiation", "💬", "Remédiation", "Textes de remédiation par compétence, à partir de l'énoncé et du corrigé"),
    ("Rapports", "📄", "Édition de rapports", "Générer les PDF à distribuer aux élèves"),
    ("Réglages", "⚙️", "Réglages", "Sauvegarder ou restaurer toutes tes données"),
]
PAGES = [nom for nom, _, _, _ in PAGES_INFO]

NOM_A_LABEL = {nom: f"{icone}  {libelle}" for nom, icone, libelle, _ in PAGES_INFO}
LABEL_A_NOM = {v: k for k, v in NOM_A_LABEL.items()}


def aller_a(nom_page, classe_id=None):
    """Permet à un bouton (ex. sur le tableau de bord) de basculer d'onglet programmatiquement.
    On ne peut pas modifier directement la valeur du widget radio une fois qu'il est déjà créé
    dans ce run : on passe par une clé intermédiaire, appliquée juste avant sa création
    au tout début du prochain run."""
    st.session_state["_pending_nav_label"] = NOM_A_LABEL[nom_page]
    if classe_id is not None:
        st.session_state["classe_active"] = classe_id


if "_pending_nav_label" in st.session_state:
    st.session_state["nav_page_label"] = st.session_state.pop("_pending_nav_label")
_appliquer_pending_comment()
_enregistrer_saisies_en_attente()


# Habillage commun (v3.7) : tout est purement visuel ; si un sélecteur n'est plus reconnu par une
# future version de Streamlit, l'appli reste utilisable, seule la mise en forme change.
st.markdown("""
<style>
/* Menu de gauche : trois temps (Préparer / Corriger / Restituer) */
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(2)::before { content: "1 · PRÉPARER"; }
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(4)::before { content: "2 · CORRIGER"; }
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(5)::before { content: "3 · RESTITUER"; }
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(8)::before { content: "RÉGLAGES"; }
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(2)::before,
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(4)::before,
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(5)::before,
[data-testid="stSidebar"] [role="radiogroup"] > div:nth-child(8)::before {
    display: block; margin: 14px 0 4px; font-size: 0.7rem; font-weight: 700;
    letter-spacing: .07em; color: #6b7280; }
/* Boutons de notation A / B / C / D : plus gros, plus faciles à viser */
.st-key-notation button, .st-key-barre_eleve button { min-height: 2.9rem; }
.st-key-notation [data-testid="stHorizontalBlock"] { align-items: center; }
.st-key-notation button p { font-size: 1.15rem; font-weight: 700; }
/* Barre élève fixe en haut de l'écran Corriger */
div:has(> .st-key-barre_eleve), div:has(> .st-key-barre_question) {
    position: sticky; top: 2.9rem; z-index: 50; background: #ffffff; }
.st-key-barre_eleve, .st-key-barre_question { padding: 0.5rem 0.25rem 0.25rem; border-bottom: 1px solid #e5e7eb; }
/* Aspect général : titres plus sobres, cartes arrondies, boutons arrondis */
h1 { font-size: 2rem !important; }
[data-testid="stMain"] [data-testid="stVerticalBlockBorderWrapper"] { border-radius: 14px; }
[data-testid="stMain"] button { border-radius: 10px; }
</style>
""", unsafe_allow_html=True)

st.sidebar.markdown(f"## 🎓 Trajectoire <span style='font-size: 0.6em; color: grey;'>v{APP_VERSION}</span>",
                     unsafe_allow_html=True)
st.sidebar.caption("Application en test pour la correction d'évaluations — développée par "
                    "Nils Aronssohn (nils.aronssohn@ac-grenoble.fr) avec l'aide de l'IA (Claude).")
_dern = db.dernier_enregistrement()
if _dern is None:
    _txt_dern = "aucun pour l'instant"
elif _dern.date() == date.today():
    _txt_dern = f"aujourd'hui à {_dern:%H:%M}"
else:
    _txt_dern = f"le {_dern:%d/%m/%Y à %H:%M}"
st.sidebar.caption(f"💾 Données dans « {_chemin_court(db.DOSSIER_DONNEES)} » — dernier enregistrement "
                   f"{_txt_dern}.")
st.sidebar.divider()
label_choisi = st.sidebar.radio("Navigation", list(LABEL_A_NOM.keys()),
                                 label_visibility="collapsed", key="nav_page_label")
page = LABEL_A_NOM[label_choisi]
if page != st.session_state.get("_derniere_page"):
    if page == "Devoirs":
        st.session_state.pop("devoirs_mode_confirmed", None)
    if page == "Résultats":
        st.session_state.pop("resultats_vue_confirmed", None)
    st.session_state["_derniere_page"] = page
description_page = next(desc for nom, _, _, desc in PAGES_INFO if nom == page)
st.sidebar.caption(description_page)

_illustration_path = os.path.join(os.path.dirname(__file__), "assets", "sidebar_illustration.png")
if os.path.exists(_illustration_path):
    st.sidebar.image(_illustration_path)

# ---------------------------------------------------------------- ALERTES (toutes pages)
if st.session_state.get("_reprise_message"):
    st.success(st.session_state["_reprise_message"])
    if st.button("OK, compris", key="reprise_ok"):
        st.session_state.pop("_reprise_message", None)
        st.rerun()

if db.nombre_sessions_ouvertes() > 1 or db.autre_instance_active():
    st.warning("⚠️ Trajectoire semble ouverte dans plusieurs onglets ou fenêtres. Garde-en **une seule** : "
               "sinon ce que tu saisis dans l'une peut écraser ce qui a été saisi dans l'autre. "
               "(Si tu viens de relancer l'appli, ce message disparaît tout seul au bout de 30 secondes.)")

if db.base_vide():
    _sauvs = [(p, db.resume_base(p)) for p in db.lister_toutes_sauvegardes()[:15]]
    _sauvs = [(p, r) for p, r in _sauvs if r and r[1] > 0]
    if _sauvs:
        _p, _r = _sauvs[0]
        _d = datetime.fromtimestamp(os.path.getmtime(_p))
        st.error(f"⚠️ Ta base de données est **vide**, alors qu'une sauvegarde du {_date_lisible(_d)} "
                 f"contient {_r[0]} classe(s), {_r[1]} élève(s) et {_r[2]} devoir(s). "
                 "Si ce n'est pas voulu, restaure-la. (Si tu repars volontairement de zéro, ignore ce "
                 "message : il disparaît dès que tu ajoutes une classe.)")
        if st.button("♻️ Restaurer cette sauvegarde", type="primary", key="restaurer_banniere"):
            with open(_p, "rb") as _f:
                db.restaurer_depuis_octets(_f.read())
            st.session_state["_reprise_message"] = f"Sauvegarde du {_date_lisible(_d)} restaurée."
            st.rerun()

# ---------------------------------------------------------------- ACCUEIL
if page == "Accueil":
    st.title("🏠 Tableau de bord")

    classes = db.list_classes()

    with st.expander("🚀 Premiers pas — comment utiliser l'appli", expanded=(len(classes) == 0)):
        st.markdown("""
1. **👤 Liste des classes et élèves** — crée une classe (ex. "TSTL", "BTS MDC1"), puis
   importe tes élèves via un export CSV Pronote, ou ajoute-les à la main.
2. **📝 Paramétrisation d'une évaluation** — crée un devoir. Deux types possibles :
   *devoir écrit* (questions notées une par une, comme un DS classique) ou
   *évaluation globale par compétence* (comme un CCF/TP de BTS ou une ECE). Renseigne les
   questions ou compétences, leur barème/poids, et le mode de notation.
3. **✅ Corriger** — sélectionne le devoir, navigue élève par élève, note en cliquant sur
   A/B/C/D (ou en saisissant des points). Tout s'enregistre automatiquement.
4. **📊 Visualisation des résultats** — classement de la classe, dispersion des notes,
   suivi de chaque élève ou de la classe dans le temps.
5. **💬 Remédiation** — rédige (ou génère avec une IA à partir du prompt fourni) un texte
   de remédiation par compétence et par niveau, réutilisé automatiquement dans les rapports.
6. **📄 Édition de rapports** — génère le PDF de chaque élève (séparés ou en un seul
   fichier), avec les blocs de ton choix.

*Astuce : reviens sur ce guide à tout moment en rouvrant ce bandeau.*
        """)

    if not classes:
        st.info("Crée ta première classe dans l'onglet « Liste des classes et élèves » pour commencer.")
        st.stop()

    total_eleves = sum(len(db.list_students(classe_id=c["id"])) for c in classes)
    total_ds = sum(len(db.list_ds(classe_id=c["id"])) for c in classes)
    c1, c2, c3 = st.columns(3)
    c1.metric("Classes", len(classes))
    c2.metric("Élèves au total", total_eleves)
    c3.metric("Devoirs au total", total_ds)
    st.divider()

    # --- Ce qui reste à faire : devoirs à corriger / à restituer (les plus récents d'abord)
    def _complet_ds(g_eleve, qs):
        return all((g_eleve.get(q["id"], {}).get("niveau")
                    or g_eleve.get(q["id"], {}).get("points") is not None) for q in qs)

    a_corriger, a_restituer = [], []
    for c in classes:
        noms_c = db.list_students(classe_id=c["id"])
        if not noms_c:
            continue
        ids_c = [db.get_student_id(n) for n in noms_c]
        for d in reversed(db.list_ds_chronological(classe_id=c["id"])):
            qs_d = db.get_questions(d["id"])
            if not qs_d:
                continue
            grades_d = db.get_all_grades_for_ds(d["id"])
            n_fait = sum(1 for i in ids_c if _complet_ds(grades_d.get(i, {}), qs_d))
            if n_fait < len(ids_c):
                a_corriger.append((c, d, n_fait, len(ids_c)))
            else:
                comps_d = sorted({q["competence"] for q in qs_d})
                grille_d = db.get_remediation_grid(d["id"], comps_d)
                remed_ok = any(grille_d[k][n] for k in comps_d for n in db.NIVEAUX)
                a_restituer.append((c, d, remed_ok))

    st.subheader("À faire")
    fa1, fa2 = st.columns(2)
    with fa1:
        with st.container(border=True):
            st.markdown("**À corriger**")
            if not a_corriger:
                st.caption("Rien en attente : toutes les copies sont corrigées.")
            for c, d, n_fait, n_tot in a_corriger[:5]:
                st.markdown(f"{d['titre']}  \n<span style='color:#6b7280;font-size:0.85em'>{c['nom']} — "
                            f"{n_fait}/{n_tot} copies</span>", unsafe_allow_html=True)
                st.progress(n_fait / n_tot)
                if st.button("Reprendre la correction", key=f"af_corr_{d['id']}"):
                    aller_a("Corriger", classe_id=c["id"])
                    st.rerun()
    with fa2:
        with st.container(border=True):
            st.markdown("**À restituer**")
            if not a_restituer:
                st.caption("Aucun devoir entièrement corrigé en attente.")
            for c, d, remed_ok in a_restituer[:5]:
                st.markdown(f"{d['titre']}  \n<span style='color:#6b7280;font-size:0.85em'>{c['nom']} — "
                            + ("remédiation renseignée" if remed_ok else "remédiation à compléter")
                            + "</span>", unsafe_allow_html=True)
                b1, b2 = st.columns(2)
                if b1.button("Remédiation", key=f"af_rem_{d['id']}"):
                    aller_a("Remédiation", classe_id=c["id"])
                    st.rerun()
                if b2.button("Rapports", key=f"af_rap_{d['id']}"):
                    aller_a("Rapports", classe_id=c["id"])
                    st.rerun()
    st.divider()

    for c in classes:
        eleves = db.list_students(classe_id=c["id"])
        ds_chrono = db.list_ds_chronological(classe_id=c["id"])
        dernier = ds_chrono[-1] if ds_chrono else None

        with st.container(border=True):
            hc1, hc2 = st.columns([3, 1])
            hc1.subheader(c["nom"])
            hc1.caption(f"{len(eleves)} élève(s) · {len(ds_chrono)} devoir(s)")

            if dernier:
                notes20 = []
                for nom in eleves:
                    sid = db.get_student_id(nom)
                    grades = db.get_grades_for_student(dernier["id"], sid)
                    if _a_des_notes(grades):
                        r = db.compute_student_result(dernier["id"], sid)
                        notes20.append(_note_sur_20(r))
                n_corriges = len(notes20)
                mc1, mc2 = st.columns(2)
                mc1.metric("Dernier devoir", dernier["titre"][:28] + ("…" if len(dernier["titre"]) > 28 else ""))
                if notes20:
                    mc2.metric("Moyenne /20", f"{sum(notes20) / len(notes20):.2f}")
                else:
                    mc2.metric("Moyenne /20", "—")
                st.progress(n_corriges / len(eleves) if eleves else 0)
                st.caption(f"{n_corriges}/{len(eleves)} élève(s) corrigé(s) sur ce devoir")
            else:
                st.caption("Aucun devoir créé pour cette classe pour l'instant.")

            bc1, bc2 = st.columns(2)
            if bc1.button("✅ Corriger", key=f"accueil_corriger_{c['id']}", use_container_width=True):
                aller_a("Corriger", classe_id=c["id"])
                st.rerun()
            if bc2.button("📊 Résultats", key=f"accueil_resultats_{c['id']}", use_container_width=True):
                aller_a("Résultats", classe_id=c["id"])
                st.rerun()

# ---------------------------------------------------------------- ÉLÈVES
elif page == "Élèves":
    st.title("Élèves")

    classes = db.list_classes()
    with st.expander("➕ Créer une nouvelle classe"):
        nouvelle_classe = st.text_input("Nom de la classe", placeholder="ex. TSTL, BTS MDC1...", width=280)
        if st.button("Créer la classe") and nouvelle_classe.strip():
            new_cid = db.create_classe(nouvelle_classe)
            st.session_state["classe_active"] = new_cid
            st.rerun()

    if not classes:
        st.info("Crée d'abord une classe ci-dessus.")
        st.stop()

    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id))
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    rc1, rc2 = st.columns([3, 1])
    nouveau_nom_classe = rc1.text_input("Renommer cette classe", value=nom_choisi, key=f"rename_{classe_id}", width=280)
    if rc2.button("Renommer") and nouveau_nom_classe.strip() and nouveau_nom_classe != nom_choisi:
        db.rename_classe(classe_id, nouveau_nom_classe)
        st.rerun()

    st.divider()

    eleves_classe = db.list_students(classe_id=classe_id)
    st.subheader(f"Élèves de « {nom_choisi} » ({len(eleves_classe)})")
    if not eleves_classe:
        st.info("Aucun élève pour l'instant — ouvre « ➕ Ajouter des élèves » ci-dessous pour commencer.")
    else:
        recherche = st.text_input("🔍 Rechercher un élève", placeholder="Tape un nom pour filtrer la liste...",
                                   width=350)
        terme = recherche.strip().lower()
        eleves_affiches = [n for n in eleves_classe if terme in n.lower()] if terme else eleves_classe
        if terme and not eleves_affiches:
            st.caption(f"Aucun élève ne correspond à « {recherche} ».")
        elif terme:
            st.caption(f"{len(eleves_affiches)}/{len(eleves_classe)} élève(s) affiché(s).")
        besoins_map = db.get_besoins_map(classe_id)
        st.caption("Colonne « Besoins particuliers » : PAP, PAI, tiers-temps, orthographe non prise "
                   "en compte… Ce texte s'affichera comme avertissement quand tu corrigeras l'élève "
                   "et sur sa fiche d'évaluation de TP imprimée.")
        for n in eleves_affiches:
            c1, cb, c2, c3 = st.columns([3, 3, 2, 1])
            c1.write(("⚠️ " if n in besoins_map else "") + n)
            nouveau_bes = cb.text_input("Besoins particuliers", value=besoins_map.get(n, ""),
                                         key=f"bes_{n}_{classe_id}", label_visibility="collapsed",
                                         placeholder="Besoins particuliers (PAP, PAI…)")
            if nouveau_bes.strip() != besoins_map.get(n, ""):
                db.set_besoins(n, nouveau_bes)
                st.rerun()
            autres_classes = {c["nom"]: c["id"] for c in classes if c["id"] != classe_id}
            if autres_classes:
                dest = c2.selectbox("Déplacer vers", ["—"] + list(autres_classes.keys()),
                                     key=f"move_{n}", label_visibility="collapsed")
                if dest != "—":
                    db.set_student_classe(n, autres_classes[dest])
                    st.rerun()
            confirm_key = f"confirm_del_{n}"
            if not st.session_state.get(confirm_key):
                if c3.button("Suppr.", key=f"del_{n}"):
                    st.session_state[confirm_key] = True
                    st.rerun()
            else:
                st.warning(f"Supprimer {n} effacera aussi **toutes ses notes sur tous les devoirs**, "
                           f"de façon définitive.")
                cc1, cc2 = st.columns(2)
                if cc1.button("Oui, supprimer définitivement", key=f"del_confirm_{n}", type="primary"):
                    db.remove_student(n)
                    st.session_state.pop(confirm_key, None)
                    st.rerun()
                if cc2.button("Annuler", key=f"del_cancel_{n}"):
                    st.session_state.pop(confirm_key, None)
                    st.rerun()

    st.divider()
    with st.expander("➕ Ajouter des élèves (import CSV ou saisie manuelle)"):
        st.subheader("Import CSV Pronote")
        up = st.file_uploader("Fichier CSV", type=["csv"],
                               help="Exporte ta liste d'élèves depuis Pronote (ou tout tableur) au format "
                                    "CSV, puis dépose le fichier ici. Tu choisiras ensuite la colonne à "
                                    "importer.")
        if up is not None:
            raw = None
            erreurs_lecture = []
            # Pronote exporte souvent en Windows-1252 (accents), pas toujours en UTF-8 —
            # on essaie plusieurs combinaisons encodage/séparateur avant d'abandonner.
            for encodage in ["utf-8-sig", "utf-8", "cp1252", "latin-1"]:
                for sep in [None, ";", ","]:
                    try:
                        up.seek(0)
                        raw = pd.read_csv(up, sep=sep, engine="python", encoding=encodage)
                        if raw.shape[1] >= 1:
                            break
                    except Exception as e:
                        erreurs_lecture.append(f"{encodage}/{sep}: {e}")
                        raw = None
                if raw is not None:
                    break

            if raw is None:
                st.error("Impossible de lire ce fichier CSV (encodage ou format non reconnu). "
                         "Envoie-le-moi si besoin, je regarderai le problème précisément.")
                with st.expander("Détail technique (pour diagnostic)"):
                    for e in erreurs_lecture:
                        st.caption(e)
            else:
                st.caption(f"{len(raw)} ligne(s) lue(s) dans le fichier.")
                st.dataframe(raw, use_container_width=True, height=200)
                col = st.selectbox("Colonne contenant le nom (ou nom+prénom déjà concaténés)",
                                    raw.columns, width=400)
                noms_bruts = raw[col].astype(str).tolist()
                noms_valides = [n.strip() for n in noms_bruts
                                if n and n.strip() and n.strip().lower() != "nan"]
                # élèves déjà présents dans une autre classe (cas typique : passage de BTS1 à BTS2)
                autres = db.eleves_dans_autre_classe(noms_valides, classe_id)
                deplacer = False
                if autres:
                    deplacer = st.checkbox(
                        f"Déplacer vers « {nom_choisi} » les {len(autres)} élève(s) déjà enregistré(s) dans "
                        f"une autre classe (ils gardent leurs notes et leur historique)", value=True,
                        help="Un même nom ne peut exister qu'une fois dans l'appli. Décoché, ces élèves "
                             "restent dans leur classe actuelle et ne sont pas ajoutés ici. Concerné(s) : "
                             + ", ".join(autres))
                if st.button(f"Importer cette colonne dans « {nom_choisi} »"):
                    avant = set(db.list_students())
                    db.import_students(noms_valides, classe_id=classe_id)
                    apres = set(db.list_students())
                    n_ajoutes = len(apres - avant)
                    n_deplaces = 0
                    if deplacer:
                        for n in autres:
                            db.set_student_classe(n, classe_id)
                            n_deplaces += 1
                    n_ignores = len(noms_valides) - n_ajoutes - n_deplaces
                    st.session_state["_msg_import"] = (
                        f"{len(raw)} ligne(s) lue(s) → {len(noms_valides)} nom(s) non vide(s) → "
                        f"{n_ajoutes} élève(s) ajouté(s) dans « {nom_choisi} »"
                        + (f", {n_deplaces} déplacé(s) depuis une autre classe" if n_deplaces else "") + ".",
                        (f"{n_ignores} nom(s) n'ont pas été ajoutés — le plus souvent parce qu'un élève "
                         f"portant exactement ce nom existe déjà." if n_ignores > 0 else None))
                    st.rerun()
        if st.session_state.get("_msg_import"):
            _ok, _avert = st.session_state.pop("_msg_import")
            st.success(_ok)
            if _avert:
                st.warning(_avert)

        st.subheader("Ajout manuel")
        with st.form("add_student", clear_on_submit=True):
            nom = st.text_input("NOM Prénom", width=280)
            if st.form_submit_button("Ajouter") and nom.strip():
                deja = db.classe_nom_de_eleve(nom)
                if deja is not None:
                    st.warning(f"« {nom.strip()} » existe déjà dans la classe « {deja} » : un même nom ne "
                               f"peut exister qu'une fois. Pour le changer de classe, utilise « Déplacer "
                               f"vers » dans la liste de sa classe actuelle. Si c'est un homonyme, ajoute "
                               f"un repère (ex. « DUPONT Léa (2) »).")
                else:
                    db.add_student(nom, classe_id=classe_id)
                    st.rerun()

# ---------------------------------------------------------------- DEVOIRS
elif page == "Devoirs":
    st.title("📝 Paramétrisation d'une évaluation")

    classes = db.list_classes()
    if not classes:
        st.info("Crée d'abord une classe dans l'onglet « Liste des classes et élèves ».")
        st.stop()
    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id),
                               key="classe_devoirs")
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    if not st.session_state.get("devoirs_mode_confirmed"):
        st.subheader("Que veux-tu faire ?")
        bc1, bc2 = st.columns(2)
        if bc1.button("➕ Créer un nouveau devoir", width="stretch", type="primary"):
            st.session_state["devoirs_mode"] = "➕ Créer un nouveau devoir"
            st.session_state["devoirs_mode_confirmed"] = True
            st.rerun()
        if bc2.button("✏️ Modifier un devoir existant", width="stretch"):
            st.session_state["devoirs_mode"] = "✏️ Modifier un devoir existant"
            st.session_state["devoirs_mode_confirmed"] = True
            st.rerun()
        st.stop()

    mode_page = st.session_state["devoirs_mode"]
    if st.button("⬅️ Changer (créer / modifier)"):
        st.session_state.pop("devoirs_mode_confirmed", None)
        st.rerun()
    st.divider()

    # ================================================================ CRÉATION
    if mode_page == "➕ Créer un nouveau devoir":
        type_new = st.radio(
            "Type d'évaluation", ["devoir", "tp"],
            format_func=lambda t: TYPE_EVAL_LABELS[t],
            help="Ce choix est définitif une fois le devoir créé. En cas de doute : un devoir écrit "
                 "classique (DS, interro) = « questions notées une par une » ; un CCF, TP ou ECE noté "
                 "directement compétence par compétence = « évaluation globale par compétence ».",
        )
        titre = st.text_input("Titre du devoir", width=350,
                               help="Le titre apparaît sur le rapport remis à l'élève et dans tous les "
                                    "menus de l'appli — choisis quelque chose de reconnaissable "
                                    "(ex. « DS Chapitre 5 » ou « TP Dermocuivre »).")
        date_new = st.date_input("Date du devoir", value=date.today(), width=200,
                                  help="Sert à trier les devoirs chronologiquement dans les résultats "
                                       "et le suivi dans le temps — pas forcément la date du jour.")
        c1, c2 = st.columns(2)
        note_sur_choix = c1.selectbox("Note finale sur", [20, 10, "Autre"], key="note_sur_new", width=180,
                                help="Échelle finale affichée pour chaque élève (ex. /20), quel que soit "
                                     "le barème total des questions ou compétences.")
        note_sur = c1.number_input("Valeur", value=15.0, step=0.5, key="note_sur_autre_new", width=180) \
            if note_sur_choix == "Autre" else float(note_sur_choix)
        arrondi_labels = {"Aucun (valeur exacte)": 0, "0,1": 0.1, "0,5": 0.5, "1": 1}
        arrondi_choix = c2.selectbox("Arrondi de la note", list(arrondi_labels.keys()), index=2, key="arrondi_new",
                              width=180, help="La note calculée est arrondie au multiple le plus proche "
                                             "de cette valeur (ex. 0,5 -> 12.3 devient 12.5).")
        arrondi = arrondi_labels[arrondi_choix]
        if type_new == "devoir":
            mode_new = st.radio(
                "Mode de notation des questions", ["lettres", "points"],
                format_func=lambda m: "Lettres A/B/C/D" if m == "lettres" else "Points directs (par pas de 0,25)",
                horizontal=True,
                help="Lettres : tu évalues chaque question par un niveau A/B/C/D (rapide, qualitatif). "
                     "Points : tu attribues directement un nombre de points précis par question "
                     "(plus fin, utile pour un barème très détaillé).",
            )
            options_listes_new = _options_listes_competences()
            liste_label_new = st.selectbox(
                "Liste de compétences", list(options_listes_new.keys()),
                help="Détermine les choix proposés dans le menu déroulant « Compétence » lors de la "
                     "saisie des questions. Modifiable à tout moment après création. Pour créer ta "
                     "propre liste, vois la section « Gérer mes listes de compétences » ci-dessous.",
            )
            competence_list_new = options_listes_new[liste_label_new]
            commentaires_question_new = st.checkbox(
                "Activer un commentaire par question", value=False,
                help="Ajoute un champ de commentaire libre sous chaque question, en plus du niveau/des "
                     "points, pendant la correction. Ces commentaires peuvent ensuite apparaître dans "
                     "le rapport remis à l'élève.",
            )
        else:
            mode_new = "lettres"
            competence_list_new = db.LISTE_COMPETENCES_DEFAUT
            commentaires_question_new = False
            st.caption("Un TP se note en lettres A/B/C/D par compétence (le mode points ne s'applique pas ici).")
        nature_new = st.radio(
            "Nature de l'évaluation", ["sommative", "formative"],
            format_func=lambda n: "Sommative (compte pleinement dans les bilans)" if n == "sommative"
            else "Formative (entraînement — exclue des bilans par défaut)",
            horizontal=True,
            help="Modifiable à tout moment après création, contrairement au type d'évaluation.",
        )
        if st.button(f"Créer le devoir pour « {nom_choisi} »", type="primary") and titre.strip():
            ds_id = db.create_ds(titre, note_sur, arrondi, mode_new, date_ds=date_new.isoformat(),
                                  classe_id=classe_id, type_eval=type_new, nature=nature_new,
                                  competence_list=competence_list_new,
                                  commentaires_question=commentaires_question_new)
            st.session_state["ds_id_edit"] = ds_id
            st.session_state["devoirs_mode"] = "✏️ Modifier un devoir existant"
            st.session_state["devoirs_mode_confirmed"] = True
            st.rerun()

        if type_new == "devoir":
            with st.expander("🗂️ Gérer mes listes de compétences personnalisées"):
                st.caption("Crée ici tes propres listes (par exemple pour une matière avec un référentiel "
                           "de compétences différent) — elles apparaîtront ensuite dans le sélecteur "
                           "ci-dessus, pour ce devoir comme pour tous les prochains.")
                nouveau_nom_liste = st.text_input("Nom de la nouvelle liste", placeholder="ex. SVT, Français...")
                nouvelles_competences = st.text_area(
                    "Compétences (une par ligne)",
                    placeholder="Recueillir\nInterpréter\nCommuniquer\nArgumenter", height=120,
                )
                if st.button("Créer cette liste") and nouveau_nom_liste.strip():
                    codes = [c.strip() for c in nouvelles_competences.split("\n") if c.strip()]
                    if codes:
                        db.create_competence_list(nouveau_nom_liste, codes)
                        st.success(f"Liste « {nouveau_nom_liste} » créée avec {len(codes)} compétence(s).")
                        st.rerun()
                    else:
                        st.warning("Ajoute au moins une compétence (une par ligne).")

                listes_existantes = db.list_competence_lists()
                if listes_existantes:
                    st.divider()
                    for liste in listes_existantes:
                        lc1, lc2 = st.columns([4, 1])
                        lc1.write(f"**{liste['nom']}** — {', '.join(liste['competences'])}")
                        if lc2.button("Supprimer", key=f"suppr_liste_{liste['id']}"):
                            db.delete_competence_list(liste["id"])
                            st.rerun()

        with st.expander("💬 Gérer ma banque de commentaires réutilisables"):
            st.caption("Ces commentaires apparaissent sous forme de boutons cliquables sous chaque champ "
                       "de commentaire pendant la correction (question par question, ou par compétence "
                       "en TP) — cliquer préremplit le champ, à ajuster ensuite si besoin.")
            nouveau_commentaire = st.text_input("Nouveau commentaire", placeholder="ex. Attention aux unités",
                                                 key="nouveau_commentaire_banque")
            if st.button("Ajouter à la banque") and nouveau_commentaire.strip():
                db.add_comment_bank(nouveau_commentaire)
                st.rerun()
            banque_actuelle = db.list_comment_bank()
            if banque_actuelle:
                st.divider()
                for c in banque_actuelle:
                    bc1, bc2 = st.columns([4, 1])
                    bc1.write(c["texte"])
                    if bc2.button("Supprimer", key=f"suppr_banque_{c['id']}"):
                        db.delete_comment_bank(c["id"])
                        st.rerun()

    # ================================================================ ÉDITION
    else:
        tous = db.list_ds(classe_id=classe_id)
        if not tous:
            st.info(f"Aucun devoir créé pour « {nom_choisi} » pour l'instant — "
                    f"commence par « ➕ Créer un nouveau devoir » ci-dessus.")
            st.stop()

        options = {f"{d['titre']} (id {d['id']})": d["id"] for d in tous}
        label = st.selectbox("Devoir à modifier", list(options.keys()), width=280,
                              index=0 if "ds_id_edit" not in st.session_state else
                              list(options.values()).index(st.session_state["ds_id_edit"])
                              if st.session_state.get("ds_id_edit") in options.values() else 0)
        ds_id = options[label]
        ds_courant = db.get_ds(ds_id)
        type_eval = ds_courant.get("type_eval") or "devoir"
        st.caption("Type d'évaluation : " + TYPE_EVAL_LABELS[type_eval] + " — non modifiable après création.")

        # ---------- Tableau principal (questions ou compétences) ----------
        if type_eval == "tp":
            st.subheader("Compétences évaluées : code / intitulé / capacité associée / critères / poids")
            grilles_perso = db.list_tp_grilles()
            grilles_disponibles = dict(db.GRILLES_TP_PRESETS)
            for g in grilles_perso:
                grilles_disponibles[f"{g['nom']} (perso)"] = g["questions"]

            gpc1, gpc2 = st.columns([2, 1])
            grille_choisie = gpc1.selectbox("Grille préremplie", list(grilles_disponibles.keys()),
                                             key=f"grille_choix_{ds_id}")
            if gpc2.button("📥 Charger cette grille", key=f"grille_load_{ds_id}"):
                if _appliquer_ou_confirmer_questions(
                        ds_id, grilles_disponibles[grille_choisie],
                        f"Grille « {grille_choisie} » chargée."):
                    st.rerun()
            st.caption("Remplace les lignes actuelles par la grille sélectionnée. "
                       "Modifie ensuite librement (poids, intitulés, capacités) dans le tableau.")
            st.info("💡 **« Capacité associée »** : la ou les capacités officielles du référentiel "
                    "(apparaît dans le rapport remis à l'élève). **« Observables / critères de "
                    "réussite »** : ce que tu regardes concrètement pendant ce TP — réservé à "
                    "l'évaluateur, il s'affiche pendant la correction et sur la fiche d'évaluation à "
                    "imprimer (onglet Édition de rapports). Pour plusieurs critères dans une même "
                    "cellule : un retour à la ligne (Maj+Entrée) entre chacun.")
            existing = db.get_questions(ds_id)
            if grille_choisie in db.CAPACITES_REFERENCE_PAR_GRILLE:
                with st.expander(f"📖 Rappel : capacités associées officielles — {grille_choisie}"):
                    for code, texte in db.CAPACITES_REFERENCE_PAR_GRILLE[grille_choisie].items():
                        st.markdown(f"**{code}** — {texte}")
            default_df = pd.DataFrame(
                [{"id": q["id"], "label": q["label"], "competence": q["competence"],
                  "detail": q.get("detail") or "", "criteres": q.get("criteres") or "",
                  "bareme": q["bareme"]} for q in existing]
            ) if existing else pd.DataFrame(
                [{"id": None, "label": "C1", "competence": "RECHERCHER ET ANALYSER", "detail": "", "criteres": "",
                  "bareme": 1.0}]
            )
            edited = st.data_editor(
                default_df, num_rows="dynamic", use_container_width=True,
                column_config={
                    "id": None,  # identifiant interne, caché : c'est lui qui fait suivre les notes si on renomme
                    "label": st.column_config.TextColumn(
                        "Code", help="Un code court pour identifier la compétence (ex. C1, S'APP)."),
                    "competence": st.column_config.TextColumn(
                        "Intitulé de la compétence", help="Le nom complet de la compétence (ex. RECHERCHER "
                                                           "ET ANALYSER, Analyser...)."),
                    "detail": st.column_config.TextColumn(
                        "Capacité associée",
                        help="Capacité(s) du référentiel, ou observables et critères de réussite — au choix.",
                    ),
                    "criteres": st.column_config.TextColumn(
                        "Observables / critères de réussite", width="large",
                        help="Pour l'évaluateur uniquement (non imprimé sur le rapport élève). "
                             "Un critère par ligne (Maj+Entrée pour passer à la ligne).",
                    ),
                    "bareme": st.column_config.NumberColumn(
                        "Poids", step=0.25, min_value=0.0, default=1.0,
                        help="Le poids relatif de cette compétence dans le calcul de la note finale — "
                             "une compétence à poids 2 compte deux fois plus qu'une à poids 1."),
                },
                key=f"editor_tp_{ds_id}",
            )

            def _qs_depuis_tableau(df):
                qs = []
                for _, r in df.iterrows():
                    if pd.isna(r["label"]) or not str(r["label"]).strip():
                        continue
                    if pd.isna(r["competence"]) or pd.isna(r["bareme"]):
                        continue
                    qs.append({
                        "id": int(r["id"]) if "id" in r and not pd.isna(r["id"]) else None,
                        "label": str(r["label"]).strip(),
                        "competence": str(r["competence"]).strip(),
                        "detail": str(r["detail"]).strip() if not pd.isna(r.get("detail")) else "",
                        "criteres": str(r["criteres"]).strip() if not pd.isna(r.get("criteres")) else "",
                        "bareme": float(r["bareme"]),
                    })
                return qs

            qs_live = _qs_depuis_tableau(edited)
            if qs_live:
                st.caption(f"Poids total actuel : **{sum(q['bareme'] for q in qs_live):g}**")

            if st.button("Enregistrer les compétences", type="primary"):
                labels_dupliques = {l for l in (q["label"] for q in qs_live)
                                     if [q["label"] for q in qs_live].count(l) > 1}
                if labels_dupliques:
                    st.error(f"Code(s) en double : {', '.join(labels_dupliques)}. Deux lignes avec le même "
                             f"code se confondraient et l'une écraserait les notes de l'autre — "
                             f"renomme l'une des deux avant d'enregistrer.")
                else:
                    _msg = (f"{len(qs_live)} compétences enregistrées. "
                            f"Poids total : {sum(q['bareme'] for q in qs_live):g}")
                    if _appliquer_ou_confirmer_questions(ds_id, qs_live, _msg):
                        st.success(_msg)

            with st.expander("🗂️ Enregistrer comme modèle réutilisable / gérer mes grilles TP personnalisées"):
                st.caption("Enregistre le tableau ci-dessus tel qu'il est actuellement rempli (y compris "
                           "tes modifications non encore enregistrées) comme modèle réutilisable pour "
                           "tes prochains TP — il apparaîtra alors dans « Grille préremplie » ci-dessus.")
                nc1, nc2 = st.columns([3, 1])
                nom_grille = nc1.text_input("Nom du modèle", placeholder="ex. Titrage complexométrique")
                if nc2.button("💾 Enregistrer comme modèle") and nom_grille.strip():
                    qs_a_sauver = _qs_depuis_tableau(edited)
                    if qs_a_sauver:
                        db.create_tp_grille(nom_grille, [{k: v for k, v in q.items() if k != "id"}
                                                         for q in qs_a_sauver])
                        st.success(f"Modèle « {nom_grille} » enregistré ({len(qs_a_sauver)} compétence(s)).")
                        st.rerun()
                    else:
                        st.warning("Le tableau est vide, rien à enregistrer.")

                if grilles_perso:
                    st.divider()
                    for g in grilles_perso:
                        gc1, gc2 = st.columns([4, 1])
                        gc1.write(f"**{g['nom']}** — " + ", ".join(q["label"] for q in g["questions"]))
                        if gc2.button("Supprimer", key=f"suppr_grille_{g['id']}"):
                            db.delete_tp_grille(g["id"])
                            st.rerun()

        else:
            st.subheader("Questions : n° / compétence / barème")
            competences_actives = db.resolve_competence_list(
                ds_courant.get("competence_list") or db.LISTE_COMPETENCES_DEFAUT)

            gc1, gc2 = st.columns([2, 1])
            nb_q = gc1.number_input("Nombre de questions à générer", min_value=1, max_value=60, width=250,
                                     value=16, step=1, key=f"nbq_{ds_id}")
            gc1.caption("Génère Q1 à Qn avec un barème de 1.0 par défaut — "
                        "remplace les lignes actuelles de ce devoir. "
                        "Tu pourras renommer une ligne en Q3A/Q3B etc. si besoin.")
            if gc2.button("Générer les lignes", key=f"gen_{ds_id}"):
                qs = [{"label": f"Q{i}", "competence": competences_actives[0], "bareme": 1.0}
                      for i in range(1, int(nb_q) + 1)]
                if _appliquer_ou_confirmer_questions(ds_id, qs, f"{len(qs)} lignes générées."):
                    st.rerun()

            st.caption("Modifie ensuite chaque ligne directement dans le tableau "
                       "(compétence via le menu déroulant, barème au clic).")
            existing = db.get_questions(ds_id)
            default_df = pd.DataFrame(
                [{"id": q["id"], "label": q["label"], "competence": q["competence"], "bareme": q["bareme"]}
                 for q in existing]
            ) if existing else pd.DataFrame(
                [{"id": None, "label": "Q1", "competence": competences_actives[0], "bareme": 1.0}])

            edited = st.data_editor(
                default_df, num_rows="dynamic", use_container_width=True,
                column_config={
                    "id": None,  # identifiant interne, caché : c'est lui qui fait suivre les notes si on renomme
                    "competence": st.column_config.SelectboxColumn(
                        "Compétence", options=competences_actives, required=True,
                        help="La compétence évaluée par cette question — plusieurs questions peuvent "
                             "partager la même compétence, leurs résultats seront combinés. Choix "
                             "réglable via « Paramètres de ce devoir » ci-dessous.",
                    ),
                    "bareme": st.column_config.NumberColumn(
                        "Barème (points)", step=0.25, min_value=0.0, default=1.0,
                        help="Le nombre de points que vaut cette question dans le total du devoir."),
                },
                key=f"editor_{ds_id}",
            )
            def _qs_devoir_depuis_tableau(df):
                qs = []
                for _, r in df.iterrows():
                    if pd.isna(r["label"]) or not str(r["label"]).strip():
                        continue
                    if pd.isna(r["competence"]) or pd.isna(r["bareme"]):
                        continue
                    qs.append({
                        "id": int(r["id"]) if "id" in r and not pd.isna(r["id"]) else None,
                        "label": str(r["label"]).strip(),
                        "competence": str(r["competence"]).strip(),
                        "bareme": float(r["bareme"]),
                    })
                return qs

            qs_live = _qs_devoir_depuis_tableau(edited)
            if qs_live:
                bareme_total = sum(q["bareme"] for q in qs_live)
                note_visee = ds_courant["note_sur"]
                if abs(bareme_total - note_visee) < 0.01:
                    st.caption(f"Barème total actuel : **{bareme_total:g} pts** "
                               f"— correspond bien à la note visée (/{note_visee:g}).")
                else:
                    st.caption(f"Barème total actuel : **{bareme_total:g} pts** "
                               f"(note visée : /{note_visee:g} — ajuste les barèmes si tu veux que ça corresponde "
                               f"exactement, ce n'est pas obligatoire).")

            if st.button("Enregistrer les questions", type="primary"):
                labels_dupliques = {l for l in (q["label"] for q in qs_live)
                                     if [q["label"] for q in qs_live].count(l) > 1}
                if labels_dupliques:
                    st.error(f"Code(s) en double : {', '.join(labels_dupliques)}. Deux lignes avec le même "
                             f"code se confondraient et l'une écraserait les notes de l'autre — "
                             f"renomme l'une des deux avant d'enregistrer.")
                else:
                    _msg = (f"{len(qs_live)} questions enregistrées. Barème total : "
                            f"{sum(q['bareme'] for q in qs_live):g} pts")
                    if _appliquer_ou_confirmer_questions(ds_id, qs_live, _msg):
                        st.success(_msg)

        _bloc_confirmation_questions(ds_id)

        # ---------- Réglages secondaires, repliés ----------
        with st.expander("⚙️ Paramètres de ce devoir (date, note, mode de notation...)"):
            date_actuelle = ds_courant.get("date_ds")
            try:
                date_val = datetime.strptime(date_actuelle, "%Y-%m-%d").date() if date_actuelle else date.today()
            except ValueError:
                date_val = date.today()
            date_edit = st.date_input("Date du devoir", value=date_val, key=f"date_{ds_id}", width=200)
            if date_edit.isoformat() != date_actuelle:
                db.set_ds_date(ds_id, date_edit.isoformat())
                st.rerun()

            nature_actuelle = ds_courant.get("nature") or "sommative"
            nature_edit = st.radio(
                "Nature de l'évaluation", ["sommative", "formative"],
                format_func=lambda n: "Sommative (compte pleinement dans les bilans)" if n == "sommative"
                else "Formative (entraînement — exclue des bilans par défaut)",
                index=["sommative", "formative"].index(nature_actuelle),
                horizontal=True, key=f"nature_{ds_id}",
            )
            if nature_edit != nature_actuelle:
                db.set_ds_nature(ds_id, nature_edit)
                st.rerun()

            if type_eval == "devoir":
                options_listes_edit = _options_listes_competences()
                liste_actuelle_valeur = ds_courant.get("competence_list") or db.LISTE_COMPETENCES_DEFAUT
                liste_label_edit = st.selectbox(
                    "Liste de compétences", list(options_listes_edit.keys()),
                    index=list(options_listes_edit.keys()).index(
                        _label_pour_valeur_liste(liste_actuelle_valeur, options_listes_edit)),
                    key=f"liste_comp_{ds_id}",
                    help="Change les choix proposés dans le tableau de questions ci-dessus. Les questions "
                         "déjà saisies avec une compétence d'une autre liste ne sont pas modifiées "
                         "automatiquement — pense à les corriger si besoin après un changement.",
                )
                if options_listes_edit[liste_label_edit] != liste_actuelle_valeur:
                    db.set_ds_competence_list(ds_id, options_listes_edit[liste_label_edit])
                    st.rerun()

            c1, c2 = st.columns(2)
            note_sur_actuel = ds_courant["note_sur"]
            note_sur_choix_e = c1.selectbox(
                "Note finale sur", [20, 10, "Autre"], key=f"note_sur_edit_{ds_id}", width=180,
                index=[20, 10, "Autre"].index(note_sur_actuel) if note_sur_actuel in (20, 10) else 2,
                help="Échelle finale affichée pour chaque élève (ex. /20), quel que soit le barème "
                     "total des questions ou compétences.",
            )
            note_sur_e = c1.number_input("Valeur", value=float(note_sur_actuel), step=0.5, width=180,
                                          key=f"note_sur_autre_edit_{ds_id}") \
                if note_sur_choix_e == "Autre" else float(note_sur_choix_e)
            arrondi_labels = {"Aucun (valeur exacte)": 0, "0,1": 0.1, "0,5": 0.5, "1": 1}
            arrondi_inv = {v: k for k, v in arrondi_labels.items()}
            arrondi_choix_e = c2.selectbox(
                "Arrondi de la note", list(arrondi_labels.keys()), key=f"arrondi_edit_{ds_id}", width=180,
                index=list(arrondi_labels.keys()).index(arrondi_inv.get(ds_courant["arrondi"], "0,5")),
                help="La note calculée est arrondie au multiple le plus proche de cette valeur "
                     "(ex. 0,5 -> 12.3 devient 12.5).",
            )
            arrondi_e = arrondi_labels[arrondi_choix_e]
            if (note_sur_e, arrondi_e) != (ds_courant["note_sur"], ds_courant["arrondi"]):
                db.update_ds_bareme(ds_id, note_sur_e, arrondi_e)
                st.rerun()

            if type_eval == "devoir":
                mode_edit = st.radio(
                    "Mode de notation de ce devoir", ["lettres", "points"],
                    format_func=lambda m: "Lettres A/B/C/D" if m == "lettres" else "Points directs (par pas de 0,25)",
                    index=["lettres", "points"].index(ds_courant.get("mode_notation") or "lettres"),
                    horizontal=True, key=f"mode_{ds_id}",
                )
                if mode_edit != (ds_courant.get("mode_notation") or "lettres"):
                    db.set_ds_mode(ds_id, mode_edit)
                    st.rerun()
                st.caption("⚠️ Changer le mode d'un devoir déjà corrigé ne convertit pas les notes déjà "
                           "saisies dans l'autre mode — à faire de préférence avant de commencer à corriger.")

                commentaires_q_actuel = bool(ds_courant.get("commentaires_question"))
                commentaires_q_edit = st.checkbox(
                    "Activer un commentaire par question", value=commentaires_q_actuel,
                    key=f"comq_{ds_id}",
                    help="Ajoute un champ de commentaire libre sous chaque question, en plus du "
                         "niveau/des points, pendant la correction. Ces commentaires peuvent ensuite "
                         "apparaître dans le rapport remis à l'élève.",
                )
                if commentaires_q_edit != commentaires_q_actuel:
                    db.set_ds_commentaires_question(ds_id, commentaires_q_edit)
                    st.rerun()

        # ---------- Dupliquer / supprimer, repliés (actions à risque à part) ----------
        with st.expander("🗑️ Dupliquer ou supprimer ce devoir"):
            dup_c1, dup_c2 = st.columns([3, 1])
            nouveau_titre = dup_c1.text_input("Nom du devoir dupliqué", value=f"{ds_courant['titre']} (copie)",
                                               key=f"dup_titre_{ds_id}", width=350)
            if dup_c2.button("Dupliquer ce devoir"):
                new_id = db.duplicate_ds(ds_id, nouveau_titre)
                st.session_state["ds_id_edit"] = new_id
                st.success("Devoir dupliqué (questions/compétences/barème repris, aucune note copiée).")
                st.rerun()

            st.divider()
            confirm_key_ds = f"confirm_del_ds_{ds_id}"
            if not st.session_state.get(confirm_key_ds):
                if st.button("🗑️ Supprimer ce devoir"):
                    st.session_state[confirm_key_ds] = True
                    st.rerun()
            else:
                st.warning(f"Supprimer « {ds_courant['titre']} » effacera aussi **toutes les notes, "
                           f"commentaires et remédiations** liés à ce devoir, de façon définitive.")
                dc1, dc2 = st.columns(2)
                if dc1.button("Oui, supprimer définitivement", key=f"ds_del_confirm_{ds_id}", type="primary"):
                    db.delete_ds(ds_id)
                    st.session_state.pop(confirm_key_ds, None)
                    st.session_state.pop("ds_id_edit", None)
                    st.rerun()
                if dc2.button("Annuler", key=f"ds_del_cancel_{ds_id}"):
                    st.session_state.pop(confirm_key_ds, None)
                    st.rerun()

# ---------------------------------------------------------------- CORRIGER
elif page == "Corriger":
    st.title("Corriger")

    classes = db.list_classes()
    if not classes:
        st.info("Crée d'abord une classe dans l'onglet « Liste des classes et élèves ».")
        st.stop()
    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id),
                               key="classe_corriger")
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    tous = db.list_ds(classe_id=classe_id)
    if not tous:
        st.info(f"Crée d'abord un devoir pour « {nom_choisi} » dans l'onglet « Paramétrisation d'une évaluation ».")
        st.stop()

    options = {f"{d['titre']}" + (" 🔁 (formatif)" if (d.get('nature') or 'sommative') == 'formative' else "") + f" (id {d['id']})": d["id"] for d in tous}
    label = st.selectbox("Devoir", list(options.keys()), width=280)
    ds_id = options[label]
    ds_courant = db.get_ds(ds_id)
    mode = ds_courant.get("mode_notation") or "lettres"
    questions = db.get_questions(ds_id)
    eleves = db.list_students(classe_id=classe_id)

    if not questions:
        st.warning("Ce devoir n'a pas encore de questions (onglet « Paramétrisation d'une évaluation »).")
        st.stop()
    if not eleves:
        st.warning(f"Aucun élève enregistré dans « {nom_choisi} » (onglet « Liste des classes et élèves »).")
        st.stop()

    besoins_classe = db.get_besoins_map(ds_courant.get("classe_id"))

    def _est_complet(g_eleve):
        if mode == "points":
            return all(g_eleve.get(q["id"], {}).get("points") is not None for q in questions)
        return all(g_eleve.get(q["id"], {}).get("niveau") for q in questions)

    all_grades = db.get_all_grades_for_ds(ds_id)
    ids_eleves = [db.get_student_id(nom_i) for nom_i in eleves]
    n_complet = sum(1 for sid_i in ids_eleves if _est_complet(all_grades.get(sid_i, {})))
    st.progress(n_complet / len(eleves))
    st.caption(f"{n_complet}/{len(eleves)} élèves entièrement corrigés sur ce devoir")

    def _maj_suggestions():
        st.session_state["_suggestions_actives"] = st.session_state["_cb_suggestions"]

    with st.expander("⚙️ Options d'affichage"):
        st.checkbox(
            "💡 Afficher les suggestions de commentaires",
            value=st.session_state.get("_suggestions_actives", False), key="_cb_suggestions",
            on_change=_maj_suggestions,
            help="Boutons de la banque de commentaires et commentaires déjà utilisés sur ce devoir, "
                 "affichés sous chaque champ de commentaire. Décoché : la vue reste allégée.",
        )

    mode_correction = st.radio(
        "Mode de correction", ["Élève par élève", "Question par question (classe entière)"],
        horizontal=True,
        help="« Élève par élève » : tu notes toutes les questions d'un même élève avant de passer "
             "au suivant. « Question par question » : tu notes tous les élèves sur UNE question "
             "avant de passer à la suivante — pratique pour rester cohérent sur un même critère "
             "en corrigeant, ou pour corriger copie par copie plutôt qu'élève par élève.",
    )

    if mode_correction == "Élève par élève":
        key_idx = f"idx_{ds_id}"
        key_select = f"select_eleve_{ds_id}"
        pending_key = f"_pending_{key_idx}"

        # Un menu déroulant garde sa propre valeur "collée" tant qu'on ne la resynchronise pas
        # explicitement : quand Précédent/Suivant/prochain-non-corrigé changent idx, on passe par
        # ici pour que le menu déroulant se mette bien à jour lui aussi (même mécanisme que pour
        # la navigation entre pages).
        if pending_key in st.session_state:
            nouvelle_valeur = st.session_state.pop(pending_key)
            st.session_state[key_idx] = nouvelle_valeur
            st.session_state[key_select] = nouvelle_valeur

        if key_idx not in st.session_state:
            st.session_state[key_idx] = 0
        idx = max(0, min(st.session_state[key_idx], len(eleves) - 1))
        st.session_state[key_idx] = idx
        # un clic sur Précédent / Suivant / « prochain non corrigé » juste après avoir tapé :
        # on enregistre d'abord la saisie de l'élève actuel
        _enregistrer_saisies_eleve(ds_id, db.get_student_id(eleves[idx]), questions)

        with st.container(key="barre_eleve"):
            c1, c2, c3 = st.columns([1, 3, 1])
            if c1.button("◀ Précédent") and idx > 0:
                st.session_state[pending_key] = idx - 1
                st.rerun()
            if c3.button("Suivant ▶") and idx < len(eleves) - 1:
                st.session_state[pending_key] = idx + 1
                st.rerun()

            # Le libellé des options change dès qu'un élève passe de ⬜ à ✅ : Streamlit considère alors
            # que c'est un NOUVEAU menu et le remet à sa valeur par défaut (donc au 1er élève !).
            # Pour que cela n'arrive jamais : l'élève courant est UNIQUEMENT dans key_idx (source de
            # vérité), on la recopie dans le menu avant chaque affichage, et le seul moment où le
            # menu a le droit de modifier key_idx est un vrai clic de l'utilisateur (on_change).
            def _choix_menu_eleve():
                # le choix dans le menu change d'élève : on enregistre d'abord la saisie de l'ancien
                try:
                    _enregistrer_saisies_eleve(
                        ds_id, db.get_student_id(eleves[st.session_state[key_idx]]), questions)
                except Exception:
                    pass
                st.session_state[key_idx] = st.session_state[key_select]

            st.session_state[key_select] = idx
            idx_choisi = c2.selectbox(
                "Élève à corriger", options=range(len(eleves)),
                format_func=lambda i: ("✅ " if _est_complet(all_grades.get(ids_eleves[i], {}))
                                       else "⬜ ") + eleves[i] + (" ⚠️" if eleves[i] in besoins_classe else ""),
                key=key_select, label_visibility="collapsed", on_change=_choix_menu_eleve,
            )
            if idx_choisi != idx:
                st.session_state[key_idx] = idx_choisi
                idx = idx_choisi

            if n_complet < len(eleves):
                if st.button("⏭️ Aller au prochain élève non corrigé"):
                    eleves_ids = [db.get_student_id(n) for n in eleves]
                    for offset in range(1, len(eleves) + 1):
                        candidat_idx = (idx + offset) % len(eleves)
                        if not _est_complet(all_grades.get(eleves_ids[candidat_idx], {})):
                            st.session_state[pending_key] = candidat_idx
                            st.rerun()

            nom = eleves[idx]
            sid = db.get_student_id(nom)
            grades = db.get_grades_for_student(ds_id, sid)
            if mode == "points":
                n_notees = sum(1 for q in questions if grades.get(q["id"], {}).get("points") is not None)
            else:
                n_notees = sum(1 for q in questions if grades.get(q["id"], {}).get("niveau"))
            icone = "✅" if n_notees == len(questions) else "🕓"
            c2.markdown(f"##### {nom}  ({idx + 1}/{len(eleves)}) — {icone} {n_notees}/{len(questions)} questions notées")

            if nom in besoins_classe:
                st.warning(f"⚠️ **Besoins particuliers — {besoins_classe[nom]}**")

        type_eval = ds_courant.get("type_eval") or "devoir"

        if type_eval == "tp":
            grade_comments = db.get_grade_comments(ds_id, sid)
            nouveaux_comments = {}
            with st.container(key="notation"):
                for q in questions:
                    cols = st.columns([3, 1, 1, 1, 1])
                    cols[0].markdown(f"**{q['label']} — {q['competence']}** (poids {q['bareme']:g})")
                    current = (grades.get(q["id"]) or {}).get("niveau")
                    for i, niv in enumerate(["A", "B", "C", "D"]):
                        btn_type = "primary" if current == niv else "secondary"
                        if cols[1 + i].button(niv, key=f"tp_{ds_id}_{sid}_{q['id']}_{niv}", type=btn_type):
                            db.set_grade(ds_id, sid, q["id"], niveau=niv)
                            st.rerun()
                    if q.get("detail"):
                        st.caption(q["detail"])
                    if (q.get("criteres") or "").strip():
                        with st.expander("🔎 Observables / critères de réussite"):
                            for ligne in q["criteres"].splitlines():
                                if ligne.strip(" -•"):
                                    st.markdown("- " + ligne.strip(" -•"))
                    nouveaux_comments[q["id"]] = _champ_commentaire_avec_banque(
                        "Commentaire personnel", key=f"gc_{ds_id}_{sid}_{q['id']}",
                        value=grade_comments.get(q["id"], ""), height=60, label_visibility="collapsed",
                        placeholder=f"Commentaire personnel pour {q['label']}...",
                    )

            with st.expander("💬 Commentaire global", expanded=True):
                commentaires_deja_utilises_tp = [
                    c for c in db.get_used_comments_for_ds(ds_id) if c != db.get_comment(ds_id, sid)
                ]
                commentaire_global = _champ_commentaire_avec_banque(
                    "Commentaire global", key=f"commentaire_global_{ds_id}_{sid}",
                    value=db.get_comment(ds_id, sid),
                    placeholder="Appréciation générale sur l'ensemble du TP (optionnel)...",
                    commentaires_recents=commentaires_deja_utilises_tp, inclure_banque_globale=False,
                )

            for qid, texte in nouveaux_comments.items():
                if texte != grade_comments.get(qid, ""):
                    db.set_grade_comment(ds_id, sid, qid, texte)
            if commentaire_global != db.get_comment(ds_id, sid):
                db.set_comment(ds_id, sid, commentaire_global)
            if st.button("Enregistrer les commentaires",
                         help="💾 Tout est déjà enregistré automatiquement dès que tu quittes le champ : "
                              "ce bouton n'est qu'une sécurité."):
                for qid, texte in nouveaux_comments.items():
                    db.set_grade_comment(ds_id, sid, qid, texte)
                db.set_comment(ds_id, sid, commentaire_global)
                st.success("Commentaires enregistrés.")

            res = db.compute_student_result(ds_id, sid)
            st.markdown(f"**Note basse (proposition) : {res['note_calculee']:g}/{res['note_sur']:g}**"
                        f"&nbsp;&nbsp;&nbsp; **Note haute (proposition) : {res['note_haute']:g}/{res['note_sur']:g}**")
            valeur_actuelle = res["note_manuelle"] if res["note_manuelle"] is not None else res["note_calculee"]
            note_saisie = st.number_input(
                "Note finale retenue", value=float(valeur_actuelle), step=0.25,
                min_value=0.0, max_value=float(res["note_sur"]), key=f"notefinale_{ds_id}_{sid}",
                help="Les deux notes ci-dessus sont des propositions indicatives — la note finale reste à ta main.",
            )
            # enregistrement automatique : plus rien ne se perd si on passe à l'élève suivant sans cliquer
            if abs(note_saisie - float(valeur_actuelle)) > 1e-9:
                db.set_note_manuelle(ds_id, sid, note_saisie)
            if st.button("Enregistrer la note finale", type="primary",
                         help="💾 Déjà enregistrée automatiquement dès que tu quittes la case : "
                              "ce bouton n'est qu'une sécurité."):
                db.set_note_manuelle(ds_id, sid, note_saisie)
                st.success("Note enregistrée.")

        else:
            commentaires_actif = bool(ds_courant.get("commentaires_question"))
            grade_comments_q = db.get_grade_comments(ds_id, sid) if commentaires_actif else {}
            nouveaux_comments_q = {}
            with st.container(key="notation"):
                if mode == "lettres":
                    for q in questions:
                        cols = st.columns([4, 1, 1, 1, 1])
                        cols[0].write(f"**{q['label']}** — {q['competence']} ({q['bareme']:g} pt)")
                        current = (grades.get(q["id"]) or {}).get("niveau")
                        for i, niv in enumerate(["A", "B", "C", "D"]):
                            btn_type = "primary" if current == niv else "secondary"
                            if cols[1 + i].button(niv, key=f"{ds_id}_{sid}_{q['id']}_{niv}", type=btn_type):
                                db.set_grade(ds_id, sid, q["id"], niveau=niv)
                                st.rerun()
                        if commentaires_actif:
                            nouveaux_comments_q[q["id"]] = _champ_commentaire_avec_banque(
                                f"Commentaire pour {q['label']}", key=f"qc_{ds_id}_{sid}_{q['id']}",
                                value=grade_comments_q.get(q["id"], ""), height=60,
                                label_visibility="collapsed",
                                placeholder=f"Commentaire pour {q['label']} (optionnel)...",
                            )
                else:
                    for q in questions:
                        st.write(f"**{q['label']}** — {q['competence']} (barème {q['bareme']:g} pt)")
                        current_pts = (grades.get(q["id"]) or {}).get("points")
                        paliers = _paliers_points(q["bareme"])
                        valeur_actuelle = "NC" if current_pts is None else current_pts
                        choix = _boutons_palier(paliers, valeur_actuelle, key_prefix=f"pts_{ds_id}_{sid}_{q['id']}")
                        if choix is not None and choix != valeur_actuelle:
                            db.set_grade(ds_id, sid, q["id"], points=None if choix == "NC" else choix)
                            st.rerun()
                        if commentaires_actif:
                            nouveaux_comments_q[q["id"]] = _champ_commentaire_avec_banque(
                                f"Commentaire pour {q['label']}", key=f"qc_{ds_id}_{sid}_{q['id']}",
                                value=grade_comments_q.get(q["id"], ""), height=60,
                                label_visibility="collapsed",
                                placeholder=f"Commentaire pour {q['label']} (optionnel)...",
                            )

            with st.expander("💬 Commentaire général et ajustement"):
                commentaires_deja_utilises = [
                    c for c in db.get_used_comments_for_ds(ds_id) if c != db.get_comment(ds_id, sid)
                ]
                commentaire = _champ_commentaire_avec_banque(
                    "Commentaire général", key=f"commentaire_general_{ds_id}_{sid}",
                    value=db.get_comment(ds_id, sid), commentaires_recents=commentaires_deja_utilises,
                    inclure_banque_globale=False,
                )
                ajustement = st.number_input(
                    "Ajustement (bonus/malus, pts)", value=db.get_ajustement(ds_id, sid),
                    step=0.25, key=f"ajust_{ds_id}_{sid}", width=280,
                    help="Points ajoutés/retirés à la note finale, appliqués avant l'arrondi.")
                # Enregistrement automatique : tout texte saisi est sauvegardé dès que le champ est
                # validé (clic ailleurs, clic sur une note, Ctrl+Entrée) — plus rien ne se perd si on
                # change d'élève sans cliquer sur « Enregistrer ».
                if commentaire != db.get_comment(ds_id, sid):
                    db.set_comment(ds_id, sid, commentaire)
                if abs(ajustement - db.get_ajustement(ds_id, sid)) > 1e-9:
                    db.set_ajustement(ds_id, sid, ajustement)
                if commentaires_actif:
                    for qid, texte in nouveaux_comments_q.items():
                        if texte != grade_comments_q.get(qid, ""):
                            db.set_grade_comment(ds_id, sid, qid, texte)
                if st.button("Enregistrer le commentaire et l'ajustement",
                             help="💾 Tout est déjà enregistré automatiquement dès que tu quittes le champ : "
                                  "ce bouton n'est qu'une sécurité."):
                    db.set_comment(ds_id, sid, commentaire)
                    db.set_ajustement(ds_id, sid, ajustement)
                    if commentaires_actif:
                        for qid, texte in nouveaux_comments_q.items():
                            db.set_grade_comment(ds_id, sid, qid, texte)
                    st.success("Enregistré.")
            _resume = []
            if db.get_comment(ds_id, sid):
                _resume.append("commentaire saisi")
            if abs(db.get_ajustement(ds_id, sid)) > 1e-9:
                _resume.append(f"ajustement {db.get_ajustement(ds_id, sid):+g}")
            if _resume:
                st.caption("💬 " + " · ".join(_resume) + " (volet ci-dessus)")

            res = db.compute_student_result(ds_id, sid)
            st.markdown(f"**Note actuelle : {res['note']:g} / {res['note_sur']:g}**"
                        + (f"  _(dont ajustement {res['ajustement']:+g})_" if res["ajustement"] else "")
                        + ("  _(plafonnée entre 0 et le maximum)_" if res.get("plafonnee") else ""))
            niv_str = ", ".join(f"{c}: {n[0]}" for c, n in res["niveaux_competence"].items())
            st.caption(niv_str)

    else:  # Question par question (classe entière)
        q_options = {f"{q['label']} — {q['competence']}": q for q in questions}
        with st.container(key="barre_question"):
            q_label_choisi = st.selectbox("Question / compétence à noter", list(q_options.keys()),
                                           key=f"qpq_select_{ds_id}")
            q_sel = q_options[q_label_choisi]

            def _est_note_qpq(g_eleve):
                if mode == "points":
                    return g_eleve.get(q_sel["id"], {}).get("points") is not None
                return bool(g_eleve.get(q_sel["id"], {}).get("niveau"))

            all_grades_qpq = db.get_all_grades_for_ds(ds_id)
            n_notes_q = sum(1 for nom_i in eleves
                            if _est_note_qpq(all_grades_qpq.get(db.get_student_id(nom_i), {})))
            st.progress(n_notes_q / len(eleves))
            st.caption(f"{n_notes_q}/{len(eleves)} élèves notés sur « {q_sel['label']} »")
        if besoins_classe:
            st.warning("⚠️ **Besoins particuliers dans cette classe** — "
                       + " · ".join(f"{n} : {b}" for n, b in besoins_classe.items()))
        st.divider()

        with st.container(key="notation"):
            for nom in eleves:
                sid = db.get_student_id(nom)
                g = all_grades_qpq.get(sid, {}).get(q_sel["id"], {})
                if nom in besoins_classe:
                    st.caption(f"⚠️ {nom} — {besoins_classe[nom]}")
                if mode == "points":
                    st.write(f"**{nom}**")
                    current_pts = g.get("points")
                    paliers = _paliers_points(q_sel["bareme"])
                    valeur_actuelle = "NC" if current_pts is None else current_pts
                    choix = _boutons_palier(paliers, valeur_actuelle,
                                            key_prefix=f"qpq_pts_{ds_id}_{sid}_{q_sel['id']}")
                    if choix is not None and choix != valeur_actuelle:
                        db.set_grade(ds_id, sid, q_sel["id"], points=None if choix == "NC" else choix)
                        st.rerun()
                    st.divider()
                else:
                    cols = st.columns([3, 1, 1, 1, 1])
                    cols[0].write(nom)
                    current = g.get("niveau")
                    for i, niv in enumerate(["A", "B", "C", "D"]):
                        btn_type = "primary" if current == niv else "secondary"
                        if cols[1 + i].button(niv, key=f"qpq_{ds_id}_{sid}_{q_sel['id']}_{niv}", type=btn_type):
                            db.set_grade(ds_id, sid, q_sel["id"], niveau=niv)
                            st.rerun()

# ---------------------------------------------------------------- RÉSULTATS
elif page == "Résultats":
    st.title("Résultats")

    classes = db.list_classes()
    if not classes:
        st.info("Crée d'abord une classe dans l'onglet « Liste des classes et élèves ».")
        st.stop()
    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id),
                               key="classe_resultats")
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    if not st.session_state.get("resultats_vue_confirmed"):
        st.subheader("Que veux-tu regarder ?")
        bc1, bc2, bc3 = st.columns(3)
        if bc1.button("📋 Par devoir (classe entière)", width="stretch", type="primary"):
            st.session_state["resultats_vue"] = "Par devoir (classe entière)"
            st.session_state["resultats_vue_confirmed"] = True
            st.rerun()
        if bc2.button("📈 Suivi dans le temps", width="stretch"):
            st.session_state["resultats_vue"] = "Suivi dans le temps"
            st.session_state["resultats_vue_confirmed"] = True
            st.rerun()
        if bc3.button("🎯 Bilan de compétence (période)", width="stretch"):
            st.session_state["resultats_vue"] = "Bilan de compétence (période)"
            st.session_state["resultats_vue_confirmed"] = True
            st.rerun()
        st.markdown("**Choisis une vue**", help="« Par devoir » : classement et dispersion des notes sur UN "
                    "devoir précis. « Suivi dans le temps » : évolution d'un élève ou de la classe sur "
                    "PLUSIEURS devoirs successifs. « Bilan de compétence » : niveau agrégé par compétence "
                    "sur une période (utile pour un conseil de classe ou un bulletin).")
        st.stop()

    vue = st.session_state["resultats_vue"]
    if st.button("⬅️ Changer de vue"):
        st.session_state.pop("resultats_vue_confirmed", None)
        st.rerun()
    st.divider()

    if vue == "Par devoir (classe entière)":
        tous = db.list_ds(classe_id=classe_id)
        if not tous:
            st.info(f"Crée d'abord un devoir pour « {nom_choisi} ».")
            st.stop()
        options = {f"{d['titre']}" + (" 🔁 (formatif)" if (d.get('nature') or 'sommative') == 'formative' else "") + f" (id {d['id']})": d["id"] for d in tous}
        label = st.selectbox("Devoir", list(options.keys()), width=280, key="resultats_ds")
        ds_id = options[label]
        ds_courant = db.get_ds(ds_id)
        mode_ds = ds_courant.get("mode_notation") or "lettres"
        questions = db.get_questions(ds_id)
        competences = db.trier_competences(sorted(set(db.normalize_competence(q["competence"]) for q in questions))) or db.COMPETENCES_DEFAUT
        eleves = db.list_students(classe_id=classe_id)
        if not eleves:
            st.warning(f"Aucun élève enregistré dans « {nom_choisi} ».")
            st.stop()

        rows = []
        taux_par_competence = {}
        for nom in eleves:
            sid = db.get_student_id(nom)
            grades = db.get_grades_for_student(ds_id, sid)
            if not _a_des_notes(grades):
                continue
            r = db.compute_student_result(ds_id, sid)
            niveaux_norm = {db.normalize_competence(k): v for k, v in r["niveaux_competence"].items()}
            row = {"Élève": nom, "Note": r["note"]}
            for c in competences:
                niv, taux = niveaux_norm.get(c, ("-", None))
                row[c] = niv
                if taux is not None:
                    taux_par_competence.setdefault(c, []).append(taux)
            rows.append(row)

        if not rows:
            st.info("Aucun élève encore corrigé pour ce devoir.")
        else:
            df = pd.DataFrame(rows).sort_values("Note", ascending=False)
            notes = df["Note"].tolist()
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Moyenne", f"{sum(notes) / len(notes):.2f}")
            c2.metric("Médiane", f"{sorted(notes)[len(notes) // 2]:.2f}")
            c3.metric("Min", f"{min(notes):.2f}")
            c4.metric("Max", f"{max(notes):.2f}")
            st.caption(f"{len(rows)}/{len(eleves)} élèves corrigés")

            ds_courant_note_max = ds_courant["note_sur"]
            pas = st.select_slider("Pas de l'histogramme (points)", options=[0.5, 1, 2, 2.5, 5], value=2)
            bornes = list(np.arange(0, ds_courant_note_max + pas, pas))
            if bornes[-1] < ds_courant_note_max:
                bornes.append(ds_courant_note_max)
            counts, edges = np.histogram(df["Note"], bins=bornes)
            hist_df = pd.DataFrame({
                "Tranche": [round(float(e), 2) for e in edges[:-1]],
                "Effectif": counts,
            })
            st.bar_chart(hist_df, x="Tranche", y="Effectif")
            st.caption(f"Nombre d'élèves par tranche de {pas:g} points (l'axe indique le début de chaque tranche) "
                       f"— {int(counts.sum())} élèves représentés")

            # ---------- Calculs utilisés par la synthèse et les détails ci-dessous ----------
            stats_par_question = []
            for q in questions:
                valeurs = []
                for nom in eleves:
                    sid = db.get_student_id(nom)
                    g = db.get_grades_for_student(ds_id, sid).get(q["id"], {})
                    if mode_ds == "points":
                        if g.get("points") is not None and q["bareme"]:
                            valeurs.append(g["points"] / q["bareme"])
                    else:
                        niveau = g.get("niveau")
                        if niveau in db.POIDS_NIVEAU:
                            valeurs.append(db.POIDS_NIVEAU[niveau])
                if valeurs:
                    stats_par_question.append({
                        "Question": q["label"], "Compétence": q["competence"],
                        "Taux de réussite moyen (%)": round(sum(valeurs) / len(valeurs) * 100, 1),
                        "Élèves notés": len(valeurs),
                    })
            moyennes_competences = {
                c: round(sum(v) / len(v) * 100, 1) for c, v in taux_par_competence.items() if v
            }

            st.divider()
            st.subheader("🎯 Points forts / points faibles du devoir")
            if not stats_par_question and not moyennes_competences:
                st.caption("Pas encore assez de données pour une synthèse.")
            else:
                pf1, pf2 = st.columns(2)
                with pf1:
                    st.markdown("**⚠️ À retravailler en priorité**")
                    pires_questions = sorted(stats_par_question,
                                              key=lambda x: x["Taux de réussite moyen (%)"])[:3]
                    for q in pires_questions:
                        st.write(f"{q['Question']} ({q['Compétence']}) — "
                                 f"{q['Taux de réussite moyen (%)']:.0f}% de réussite")
                    if moyennes_competences:
                        pire_comp = min(moyennes_competences, key=moyennes_competences.get)
                        st.caption(f"💡 Compétence la plus fragile sur ce devoir : **{pire_comp}** "
                                   f"({moyennes_competences[pire_comp]:.0f}% de réussite moyenne).")
                with pf2:
                    st.markdown("**✅ Points forts**")
                    meilleures_questions = sorted(stats_par_question,
                                                   key=lambda x: -x["Taux de réussite moyen (%)"])[:3]
                    for q in meilleures_questions:
                        st.write(f"{q['Question']} ({q['Compétence']}) — "
                                 f"{q['Taux de réussite moyen (%)']:.0f}% de réussite")
                    if moyennes_competences:
                        meilleure_comp = max(moyennes_competences, key=moyennes_competences.get)
                        st.caption(f"💡 Compétence la mieux maîtrisée : **{meilleure_comp}** "
                                   f"({moyennes_competences[meilleure_comp]:.0f}% de réussite moyenne).")

            with st.expander("📋 Tableau complet : niveau de chaque élève par compétence"):
                st.dataframe(df, use_container_width=True, hide_index=True)

            with st.expander("📊 Statistiques détaillées par question"):
                st.caption("Taux de réussite moyen de la classe sur chaque question — utile pour repérer "
                           "ce qui a posé le plus de difficulté, question par question.")
                if stats_par_question:
                    df_stats = pd.DataFrame(stats_par_question).sort_values("Taux de réussite moyen (%)")
                    st.bar_chart(df_stats, x="Question", y="Taux de réussite moyen (%)")
                    st.dataframe(df_stats, use_container_width=True, hide_index=True)

            st.divider()
            st.subheader("📤 Export du carnet de notes")
            tous_chrono_export = db.list_ds_chronological(classe_id=classe_id)
            rows_export = []
            for nom in eleves:
                sid = db.get_student_id(nom)
                ligne = {"Élève": nom}
                for d in tous_chrono_export:
                    g = db.get_grades_for_student(d["id"], sid)
                    if _a_des_notes(g):
                        r_exp = db.compute_student_result(d["id"], sid)
                        ligne[f"{d['titre']} ({d['date_ds']})"] = r_exp["note"]
                    else:
                        ligne[f"{d['titre']} ({d['date_ds']})"] = None
                rows_export.append(ligne)
            csv_export = pd.DataFrame(rows_export).to_csv(index=False, sep=";").encode("utf-8-sig")
            st.download_button(
                "📥 Télécharger le carnet de notes complet (CSV)", csv_export,
                file_name=f"carnet_notes_{_nom_fichier(nom_choisi)}.csv", mime="text/csv",
                help="Une ligne par élève, une colonne par devoir de cette classe (toutes évaluations "
                     "confondues) — pratique pour archiver ou réimporter ailleurs.",
            )

    elif vue == "Suivi dans le temps":
        sous_vue = st.radio("Suivre", ["Un élève", "Toute la classe"], horizontal=True)
        inclure_formatif = st.checkbox(
            "Inclure les évaluations formatives", value=False,
            help="Décoché par défaut : les évaluations marquées « formative » (entraînement) "
                 "sont exclues du suivi, pour ne pas fausser la tendance avec du travail non noté "
                 "à des fins de bilan.",
        )
        tous_chrono = db.list_ds_chronological(classe_id=classe_id)
        if not inclure_formatif:
            tous_chrono = [d for d in tous_chrono if (d.get("nature") or "sommative") == "sommative"]
        if not tous_chrono:
            st.info(f"Crée d'abord un devoir pour « {nom_choisi} ».")
            st.stop()
        eleves = db.list_students(classe_id=classe_id)
        if not eleves:
            st.warning(f"Aucun élève enregistré dans « {nom_choisi} ».")
            st.stop()
        st.caption("Les notes sont ramenées sur 20 pour permettre la comparaison entre devoirs "
                   "notés sur des barèmes différents.")

        if sous_vue == "Un élève":
            nom = st.selectbox("Élève", eleves, width=280)
            sid = db.get_student_id(nom)
            points_chart, detail_rows = [], []
            for d in tous_chrono:
                grades = db.get_grades_for_student(d["id"], sid)
                if not _a_des_notes(grades):
                    continue
                r = db.compute_student_result(d["id"], sid)
                points_chart.append({"Date": d["date_ds"] or d["titre"], "Note /20": round(_note_sur_20(r), 2)})
                row = {"Devoir": d["titre"], "Date": d["date_ds"], "Note": f"{r['note']:g}/{r['note_sur']:g}"}
                for c, (niv, _) in r["niveaux_competence"].items():
                    row[db.normalize_competence(c)] = niv
                detail_rows.append(row)

            if not points_chart:
                st.info("Aucun devoir corrigé pour cet élève pour l'instant.")
            else:
                chart_df = pd.DataFrame(points_chart)
                st.altair_chart(_graphique_ligne_points(chart_df, "Date", "Note /20"), use_container_width=True)
                st.dataframe(pd.DataFrame(detail_rows), use_container_width=True, hide_index=True)

        else:  # Toute la classe
            points_chart, detail_rows = [], []
            for d in tous_chrono:
                notes_20 = []
                for nom in eleves:
                    sid = db.get_student_id(nom)
                    grades = db.get_grades_for_student(d["id"], sid)
                    if not _a_des_notes(grades):
                        continue
                    r = db.compute_student_result(d["id"], sid)
                    notes_20.append(_note_sur_20(r))
                if notes_20:
                    moy = sum(notes_20) / len(notes_20)
                    points_chart.append({"Date": d["date_ds"] or d["titre"], "Moyenne /20": round(moy, 2)})
                    detail_rows.append({
                        "Devoir": d["titre"], "Date": d["date_ds"],
                        "Moyenne /20": round(moy, 2), "Élèves corrigés": f"{len(notes_20)}/{len(eleves)}",
                    })

            if not points_chart:
                st.info("Aucun devoir corrigé pour la classe pour l'instant.")
            else:
                chart_df = pd.DataFrame(points_chart)
                st.altair_chart(_graphique_ligne_points(chart_df, "Date", "Moyenne /20"), use_container_width=True)
                st.dataframe(pd.DataFrame(detail_rows), use_container_width=True, hide_index=True)

            st.divider()
            st.subheader("🔍 Élèves à surveiller ou à féliciter",
                         help="Calculé sur la pente de la note (/20) au fil des devoirs corrigés pour chaque "
                              "élève (au moins 2 devoirs nécessaires), en exigeant que la dernière évaluation "
                              "n'aille pas à l'inverse de la tendance globale — un gros pic suivi d'une chute "
                              "(ou l'inverse) n'apparaît donc dans aucune des deux listes, plutôt que d'être "
                              "mal classé.")
            seuil = st.slider("Sensibilité (points/20 de variation par devoir)", 0.5, 5.0, 1.5, step=0.5,
                   help="Plus la valeur est basse, plus l'appli signale d'élèves — abaisse-la sur "
                        "une petite classe, augmente-la sur une classe nombreuse pour ne garder que "
                        "les tendances les plus marquées.")

            tendances = []
            for nom in eleves:
                sid = db.get_student_id(nom)
                pts = []
                for d in tous_chrono:
                    grades = db.get_grades_for_student(d["id"], sid)
                    if not _a_des_notes(grades):
                        continue
                    r = db.compute_student_result(d["id"], sid)
                    pts.append(_note_sur_20(r))
                if len(pts) >= 2:
                    pente = np.polyfit(range(len(pts)), pts, 1)[0]
                    dernier_delta = pts[-1] - pts[-2]
                    tendances.append((nom, pente, pts, dernier_delta))

            baisse = sorted([t for t in tendances if t[1] <= -seuil and t[3] <= 0], key=lambda t: t[1])
            hausse = sorted([t for t in tendances if t[1] >= seuil and t[3] >= 0], key=lambda t: -t[1])

            tc1, tc2 = st.columns(2)
            with tc1:
                st.markdown("**⚠️ Tendance à la baisse**")
                if not baisse:
                    st.caption("Aucun élève au-delà du seuil actuel.")
                for nom, pente, pts, _ in baisse:
                    st.write(f"{nom} — {pente:+.1f} pts/devoir  "
                             f"({' → '.join(f'{p:.1f}' for p in pts)})")
            with tc2:
                st.markdown("**📈 Progrès notable**")
                if not hausse:
                    st.caption("Aucun élève au-delà du seuil actuel.")
                for nom, pente, pts, _ in hausse:
                    st.write(f"{nom} — {pente:+.1f} pts/devoir  "
                             f"({' → '.join(f'{p:.1f}' for p in pts)})")

    else:  # Bilan de compétence (période)
        inclure_formatif_bilan = st.checkbox(
            "Inclure les évaluations formatives", value=False,
            help="Décoché par défaut : un bilan de période (conseil de classe, bulletin) reflète "
                 "en général les évaluations sommatives uniquement.",
        )
        tous_chrono = db.list_ds_chronological(classe_id=classe_id)
        if not inclure_formatif_bilan:
            tous_chrono = [d for d in tous_chrono if (d.get("nature") or "sommative") == "sommative"]
        if not tous_chrono:
            st.info(f"Crée d'abord un devoir pour « {nom_choisi} ».")
            st.stop()
        eleves = db.list_students(classe_id=classe_id)
        if not eleves:
            st.warning(f"Aucun élève enregistré dans « {nom_choisi} ».")
            st.stop()

        dates_valides = [d["date_ds"] for d in tous_chrono if d.get("date_ds")]
        date_min = datetime.strptime(min(dates_valides), "%Y-%m-%d").date() if dates_valides else date.today()
        date_max = datetime.strptime(max(dates_valides), "%Y-%m-%d").date() if dates_valides else date.today()
        pc1, pc2 = st.columns(2)
        debut = pc1.date_input("Du", value=date_min, key="bilan_debut")
        fin = pc2.date_input("Au", value=date_max, key="bilan_fin",
                             help="Le bilan agrège toutes les questions/compétences des devoirs compris dans "
                                  "cette période, quel que soit leur type (devoir écrit ou évaluation par "
                                  "compétence) — les compétences portant le même nom (ex. S'APP / "
                                  "S'approprier) sont automatiquement regroupées.")

        ds_periode = [d for d in tous_chrono
                      if d.get("date_ds") and debut.isoformat() <= d["date_ds"] <= fin.isoformat()]
        if not ds_periode:
            st.info("Aucun devoir dans cette période.")
            st.stop()
        with st.expander(f"{len(ds_periode)} devoir(s) inclus dans le bilan — pondérations"):
            ds_periode = _interface_ponderations(ds_periode, "per")

        def _accumuler(sid):
            return db.accumuler_competences(ds_periode, sid)

        toutes_competences = set()
        accum_par_eleve = {}
        for nom in eleves:
            sid = db.get_student_id(nom)
            accum = _accumuler(sid)
            accum_par_eleve[nom] = accum
            toutes_competences.update(c for c, (_, poss) in accum.items() if poss > 0)
        competences_triees = sorted(toutes_competences)

        if not competences_triees:
            st.info("Aucune compétence évaluée sur cette période pour l'instant.")
            st.stop()

        rows = []
        for nom in eleves:
            row = {"Élève": nom}
            for comp in competences_triees:
                obtenus, possible = accum_par_eleve[nom].get(comp, (0.0, 0.0))
                if possible <= 0:
                    row[comp] = "—"
                    continue
                taux = obtenus / possible
                row[comp] = "A" if taux > 0.75 else "B" if taux > 0.5 else "C" if taux > 0.25 else "D"
            rows.append(row)
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

        pdf_bilan = _pdf_en_memoire(
            build_bilan_periode_pdf, nom_choisi, debut.strftime("%d/%m/%Y"), fin.strftime("%d/%m/%Y"),
            competences_triees, rows, [d["titre"] for d in ds_periode],
        )
        st.download_button(
            "📥 Télécharger ce bilan en PDF", pdf_bilan,
            file_name=f"bilan_competences_{_nom_fichier(nom_choisi)}.pdf", mime="application/pdf",
            help="Le tableau tel qu'affiché ci-dessus, mis en page pour impression ou diffusion "
                 "(conseil de classe, bulletin).",
        )

        st.subheader("Détail pour un élève")
        nom_detail = st.selectbox("Élève", eleves, width=280, key="bilan_detail_eleve")
        detail_rows = []
        for comp in competences_triees:
            obtenus, possible = accum_par_eleve[nom_detail].get(comp, (0.0, 0.0))
            if possible <= 0:
                detail_rows.append({"Compétence": comp, "Niveau": "—", "Détail": "non évaluée sur la période"})
                continue
            taux = obtenus / possible
            niv = "A" if taux > 0.75 else "B" if taux > 0.5 else "C" if taux > 0.25 else "D"
            detail_rows.append({"Compétence": comp, "Niveau": niv,
                                 "Détail": f"{obtenus:.2f} / {possible:.2f} pts ({taux * 100:.0f}%)"})
        st.dataframe(pd.DataFrame(detail_rows), use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- REMÉDIATION
elif page == "Remédiation":
    st.title("Grille de remédiation",
             help="Un texte par compétence × niveau, réutilisé dans tous les rapports de ce devoir.")

    classes = db.list_classes()
    if not classes:
        st.info("Crée d'abord une classe dans l'onglet « Liste des classes et élèves ».")
        st.stop()
    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id),
                               key="classe_remediation")
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    tous = db.list_ds(classe_id=classe_id)
    if not tous:
        st.info(f"Crée d'abord un devoir pour « {nom_choisi} ».")
        st.stop()
    options = {f"{d['titre']}" + (" 🔁 (formatif)" if (d.get('nature') or 'sommative') == 'formative' else "") + f" (id {d['id']})": d["id"] for d in tous}
    label = st.selectbox("Devoir", list(options.keys()), width=280)
    ds_id = options[label]

    questions = db.get_questions(ds_id)
    competences = db.trier_competences(sorted(set(q["competence"] for q in questions))) or db.COMPETENCES_DEFAUT
    grid = db.get_remediation_grid(ds_id, competences)

    st.markdown("**Parcours : ① préparer le prompt → ② le faire générer par l'IA → ③ importer le CSV → "
                "④ relire et corriger.**")
    st.markdown("#### ① Préparer le prompt",
                help="Le prompt est adapté aux compétences de ce devoir. Séparateur `;`, encodage UTF-8.")

    avec_liens = st.checkbox(
        "Ajouter des liens vers « Paillasse virtuelle » (exercices du site)",
        key=f"remed_avec_liens_{ds_id}",
        help="Le prompt demandera aussi à l'IA de choisir des ressources dans le catalogue du site "
             "(catalogue.csv à joindre à la conversation) : elles apparaîtront sur le PDF de l'élève "
             "avec leur code en gros caractères, le titre et le chemin d'accès, en deux blocs : chapitre du "
             "devoir (consolider) et chapitre suivant (préparer).")
    prompt_rempli = PROMPT_REMEDIATION_TEMPLATE.format(
        competences_list=", ".join(competences),
        n_lignes=f"{len(competences) * len(db.NIVEAUX)} ({len(competences)} compétences × 4 niveaux)",
    )
    st.info(f"Ce prompt portera sur les compétences du devoir sélectionné ci-dessus : "
            f"**{', '.join(competences)}** → {len(competences) * len(db.NIVEAUX)} lignes. "
            f"Si cette liste n'est pas celle de ton devoir, change le devoir sélectionné avant de "
            f"télécharger le prompt.")
    if avec_liens:
        lc1, lc2, lc3 = st.columns(3)
        niveau_classe = lc1.selectbox("Niveau de la classe", ["TSTL", "1G", "2GT", "BTS"],
                                       key=f"remed_niveau_{ds_id}")
        chapitre_ds = lc2.text_input("Chapitre du devoir", key=f"remed_chap_ds_{ds_id}",
                                      placeholder="ex. Distillation")
        chapitre_suivant = lc3.text_input(
            "Chapitre suivant", key=f"remed_chap_suiv_{ds_id}",
            placeholder="ex. Évaporation et cristallisation",
            help="Recopie les chapitres tels qu'ils figurent dans la colonne « chapitre » du catalogue. "
                 "Joins le fichier catalogue.csv à ta conversation avec l'IA "
                 "(https://paillasse-virtuelle.fr/catalogue.csv). L'élève retrouve chaque ressource en "
                 "tapant son code sur le site : la fiche imprimée n'a ni QR code ni adresse.")
        _cat = db.charger_catalogue()
        if _cat:
            import datetime as _dt
            st.success(f"Catalogue chargé : {len(_cat['par_code'])} ressources avec code "
                       f"(fichier du {_dt.datetime.fromtimestamp(_cat['date']).strftime('%d/%m/%Y')}).")
        else:
            st.warning("Aucun catalogue chargé : les codes ne pourront pas être vérifiés avant impression.")
        with st.expander("📚 Catalogue Paillasse virtuelle (mise à jour)"):
            st.caption("Le catalogue sert à vérifier chaque code avant impression et à relire le titre et le "
                       "chemin d'accès. La mise à jour télécharge simplement le fichier public du site : "
                       "aucune donnée de l'application n'est envoyée.")
            if st.button("🔄 Mettre à jour depuis paillasse-virtuelle.fr", key="maj_catalogue"):
                ok_c, msg_c = db.telecharger_catalogue()
                (st.success if ok_c else st.error)(msg_c)
            fichier_cat = st.file_uploader("…ou charger catalogue.csv à la main", type=["csv"],
                                           key="upload_catalogue")
            if fichier_cat is not None and st.button("Utiliser ce fichier", key="use_catalogue"):
                ok_c, msg_c = db.enregistrer_catalogue(fichier_cat.getvalue())
                (st.success if ok_c else st.error)(msg_c)
        bloc = PROMPT_LIENS_BLOC.format(
            niveau_classe=niveau_classe, chapitre_ds=chapitre_ds or "[À COMPLÉTER]",
            chapitre_suivant=chapitre_suivant or "[À COMPLÉTER]")
        prompt_rempli = (prompt_rempli
                         .replace("Exactement 3 colonnes, avec cet en-tête en première ligne :\n  competence;niveau;texte",
                                  "Exactement 6 colonnes, avec cet en-tête en première ligne :\n  competence;niveau;texte;liens_ds;liens_suivant;liens")
                         + bloc)
    c0a, c0b = st.columns(2)
    c0a.download_button("📋 Télécharger le prompt pour ce devoir (.txt)", prompt_rempli.encode("utf-8"),
                         file_name=f"prompt_remediation_{_nom_fichier(label)}.txt", mime="text/plain")
    modele_rows = [{"competence": c, "niveau": n, "texte": "", "liens_ds": "", "liens_suivant": "", "liens": ""}
                   for c in competences for n in db.NIVEAUX]
    modele_csv = pd.DataFrame(modele_rows).to_csv(index=False, sep=";").encode("utf-8-sig")
    c0b.download_button("Télécharger le modèle CSV vierge", modele_csv,
                        file_name=f"remediation_modele_{_nom_fichier(label)}.csv", mime="text/csv")

    # Les champs de saisie manuelle (plus bas) gardent leur valeur en mémoire côté navigateur. Après un
    # import ou une remise à zéro, on change donc le numéro de « version » de leurs clés : ce sont alors
    # de tout nouveaux champs, relus depuis la base, sans aucun reste de l'ancien contenu.
    def _nouvelle_version_champs(_ds):
        st.session_state[f"remed_ver_{_ds}"] = st.session_state.get(f"remed_ver_{_ds}", 0) + 1

    st.markdown("#### ② Faire générer le CSV",
                help="Colle le prompt dans l'IA de ton choix, avec ton énoncé et ton corrigé (et le catalogue "
                     "si tu as demandé des liens). Rien d'autre à faire ici : récupère le CSV qu'elle produit.")
    st.markdown("#### ③ Importer le CSV",
                help="L'import remplace les cases présentes dans le CSV (texte et ressources) ; les autres "
                     "cases restent telles quelles. Pour tout vider avant un nouvel import, utilise « Remettre "
                     "à zéro » plus bas.")
    n_up = st.session_state.get(f"remed_upload_n_{ds_id}", 0)
    # la clé change après chaque import : le fichier est « oublié » et n'est donc traité qu'une seule fois
    up = st.file_uploader("Importer un CSV rempli", type=["csv"], key=f"remed_upload_{ds_id}_{n_up}")
    msg_import = st.session_state.pop(f"remed_msg_{ds_id}", None)
    if msg_import:
        st.success(msg_import["ok"])
        for pb in msg_import["avertissements"]:
            st.warning(pb)
    if up is not None:
        try:
            df_import = pd.read_csv(up, sep=";", dtype=str, encoding="utf-8-sig").fillna("")
        except Exception as e:
            df_import = None
            st.error(f"Fichier illisible : {e}")
        if df_import is not None:
            cols_ok = {"competence", "niveau", "texte"}.issubset(set(df_import.columns.str.lower()))
            if not cols_ok:
                st.error("Colonnes attendues : competence ; niveau ; texte (et facultativement liens). "
                         "Vérifie le fichier.")
            else:
                df_import.columns = [c.lower() for c in df_import.columns]
                cols_liens = [c for c in db.COLONNES_LIENS if c in df_import.columns]
                a_liens = bool(cols_liens)
                n_ok, n_liens = 0, 0
                ignorees = []
                for _, r in df_import.iterrows():
                    comp, niv, texte = r["competence"].strip(), r["niveau"].strip().upper(), r["texte"]
                    if comp in competences and niv in db.NIVEAUX:
                        # une colonne absente du fichier = on efface d'anciens liens devenus sans
                        # rapport avec le texte importé
                        vals = {c: (r[c] if c in cols_liens else "") for c in db.COLONNES_LIENS}
                        db.set_remediation(ds_id, comp, niv, texte, **vals)
                        n_liens += sum(len([l for l in db.parse_liens(v) if l["code"]]) for v in vals.values())
                        n_ok += 1
                    else:
                        ignorees.append(f"{comp or '?'} {niv or '?'}")
                msg = (f"{n_ok} lignes importées" + (f", {n_liens} code(s) reconnu(s)" if a_liens else "") + ".")
                if ignorees:
                    comps_ign = sorted({i.rsplit(' ', 1)[0] for i in ignorees})
                    msg += (f" {len(ignorees)} ligne(s) ignorée(s) : compétence ou niveau absent de ce devoir "
                            f"({', '.join(comps_ign)}). Seules les compétences qui ont au moins une question "
                            f"dans ce devoir sont prises en compte ({', '.join(competences)}).")
                _nouvelle_version_champs(ds_id)
                st.session_state[f"remed_upload_n_{ds_id}"] = n_up + 1
                st.session_state[f"remed_msg_{ds_id}"] = {
                    "ok": msg,
                    "avertissements": db.verifier_codes(db.get_remediation_grid(ds_id, competences))}
                st.rerun()

    st.divider()
    st.markdown("#### ④ Relire et corriger",
                help="Une compétence par onglet : texte et ressources de chaque niveau, enregistrés dès que "
                     "tu quittes le champ.")

    # Sauvegarde uniquement quand TU modifies un champ (on_change) : un import ou une remise à zéro
    # ne peuvent donc plus être écrasés par d'anciennes valeurs restées dans les champs.
    def _cb_texte(_ds, _c, _n, _cle):
        db.set_remediation(_ds, _c, _n, st.session_state[_cle])

    def _cb_lien(_ds, _c, _n, _col, _cle):
        texte_actuel = db.get_remediation_grid(_ds, [_c])[_c][_n]
        db.set_remediation(_ds, _c, _n, texte_actuel, **{_col: st.session_state[_cle]})

    ver = st.session_state.get(f"remed_ver_{ds_id}", 0)
    onglets = st.tabs(competences)
    for comp, onglet in zip(competences, onglets):
      with onglet:
          for niv in db.NIVEAUX:
              cle_t = f"remed_{ds_id}_v{ver}_{comp}_{niv}"
              if cle_t not in st.session_state:
                  st.session_state[cle_t] = grid[comp][niv]
              st.text_area(f"{comp} — niveau {niv}", key=cle_t, height=90,
                           on_change=_cb_texte, args=(ds_id, comp, niv, cle_t))
              a_liens_case = any(grid[comp][f"{c}_{niv}"] for c in db.COLONNES_LIENS)
              if a_liens_case or st.session_state.get(f"remed_avec_liens_{ds_id}"):
                  n_l = sum(len(db.parse_liens(grid[comp][f"{c}_{niv}"])) for c in db.COLONNES_LIENS)
                  with st.expander(f"🔗 Ressources — {comp} niveau {niv}" + (f" ({n_l})" if n_l else "")):
                      st.caption("Format : CODE | titre | chemin — plusieurs ressources séparées par ## "
                                 "(le titre et le chemin sont relus dans le catalogue à l'impression).")
                      for col, etiquette in (("liens_ds", "Chapitre du devoir"),
                                             ("liens_suivant", "Chapitre suivant"),
                                             ("liens", "Sans chapitre (ex. Réaliser)")):
                          cle_l = f"remed_{col}_{ds_id}_v{ver}_{comp}_{niv}"
                          if cle_l not in st.session_state:
                              st.session_state[cle_l] = grid[comp][f"{col}_{niv}"]
                          st.text_area(etiquette, key=cle_l, height=70,
                                       on_change=_cb_lien, args=(ds_id, comp, niv, col, cle_l))

    st.divider()
    with st.expander("🗑️ Remettre à zéro la grille de ce devoir (vider tous les textes et toutes les ressources)"):
        st.caption("Vide les textes **et** les ressources de toutes les compétences, pour les niveaux A, B, C et D "
                   "de ce devoir uniquement (les autres devoirs ne sont pas touchés). Action définitive. "
                   "Utile avant d'importer une remédiation d'un autre type.")
        cle_conf = f"remed_confirm_vider_{ds_id}"
        confirme = st.checkbox("Oui, je veux tout vider pour ce devoir", key=cle_conf)
        if st.button("🗑️ Remettre à zéro", key=f"remed_btn_vider_{ds_id}", disabled=not confirme):
            n_eff = db.vider_remediation(ds_id)
            _nouvelle_version_champs(ds_id)
            st.session_state.pop(cle_conf, None)
            st.session_state[f"remed_msg_{ds_id}"] = {
                "ok": f"Grille remise à zéro ({n_eff} case(s) effacée(s)).", "avertissements": []}
            st.rerun()

# ---------------------------------------------------------------- RAPPORTS
elif page == "Rapports":
    st.title("Rapports PDF")

    classes = db.list_classes()
    if not classes:
        st.info("Crée d'abord une classe dans l'onglet « Liste des classes et élèves ».")
        st.stop()
    noms_classes = {c["nom"]: c["id"] for c in classes}
    classe_actuelle_id = st.session_state.get("classe_active")
    if classe_actuelle_id not in noms_classes.values():
        classe_actuelle_id = classes[0]["id"]
    nom_choisi = st.selectbox("Classe", list(noms_classes.keys()), width=280,
                               index=list(noms_classes.values()).index(classe_actuelle_id),
                               key="classe_rapports")
    classe_id = noms_classes[nom_choisi]
    st.session_state["classe_active"] = classe_id

    tous = db.list_ds(classe_id=classe_id)
    if not tous:
        st.info(f"Crée d'abord un devoir pour « {nom_choisi} ».")
        st.stop()

    type_rapport = st.radio(
        "Type de rapport", ["Rapport d'une évaluation", "Bilan sur plusieurs évaluations"],
        horizontal=True, key="type_rapport",
        help="« Rapport d'une évaluation » : le compte rendu remis à l'élève après un devoir précis. "
             "« Bilan » : un rapport par élève qui s'appuie sur plusieurs évaluations à la fois "
             "(fin de trimestre, mi-semestre...), à toi de choisir lesquelles.")

    if type_rapport == "Bilan sur plusieurs évaluations":
        def _date_fr(iso):
            try:
                return datetime.strptime(iso, "%Y-%m-%d").strftime("%d/%m/%Y") if iso else ""
            except ValueError:
                return iso or ""

        chrono = db.list_ds_chronological(classe_id=classe_id)

        def _libelle(d):
            return (f"{d['titre']} — {_date_fr(d.get('date_ds'))}"
                    + (" 🔁 (formatif)" if (d.get("nature") or "sommative") == "formative" else ""))

        options_bilan = {_libelle(d): d["id"] for d in chrono}
        defaut = [_libelle(d) for d in chrono if (d.get("nature") or "sommative") == "sommative"]
        choix = st.multiselect(
            "Évaluations à prendre en compte", list(options_bilan.keys()), default=defaut,
            help="Par défaut : toutes les évaluations sommatives de la classe. Retire celles que tu ne "
                 "veux pas voir dans le bilan, ou ajoute des évaluations formatives.")
        if not choix:
            st.info("Sélectionne au moins une évaluation pour construire le bilan.")
            st.stop()
        ds_ids = [options_bilan[l] for l in choix]
        dates = [d["date_ds"] for d in chrono if d["id"] in ds_ids and d.get("date_ds")]
        debut, fin = (_date_fr(min(dates)), _date_fr(max(dates))) if dates else ("", "")
        eleves_bilan = db.list_students(classe_id=classe_id)
        if not eleves_bilan:
            st.warning(f"Aucun élève enregistré dans « {nom_choisi} ».")
            st.stop()

        with st.expander("⚖️ Pondération des évaluations", expanded=False):
            _interface_ponderations([d for d in chrono if d["id"] in ds_ids], "bil")

        with st.expander("⚙️ Contenu du rapport", expanded=False):
            opt_notes = st.checkbox(
                "Ligne des notes par évaluation", value=True,
                help="Une dernière ligne du tableau donne la note obtenue à chaque évaluation. "
                     "Aucune moyenne n'est calculée : la pondération entre évaluations est ton choix.")
            opt_tendance = st.checkbox(
                "Flèche de tendance", value=True,
                help="▲ bleue = progrès, ▼ rouge = recul entre les deux dernières évaluations où la "
                     "compétence a été évaluée (parmi celles retenues).")
        options_bilan_pdf = {"notes": opt_notes, "tendance": opt_tendance}

        def _eleves_avec_donnees(noms):
            retenus, ignores = [], 0
            for n in noms:
                data = db.bilan_eleve(ds_ids, db.get_student_id(n))
                if any(d["corrige"] for d in data["devoirs"]):
                    retenus.append({"nom_prenom": n, "data": data})
                else:
                    ignores += 1
            return retenus, ignores

        format_bilan = st.radio("Format d'export pour toute la classe",
                                 ["PDF séparés (un zip)", "Un seul PDF (tous les élèves)"],
                                 horizontal=True, key="format_bilan")
        if format_bilan == "PDF séparés (un zip)":
            if st.button("Générer tous les bilans (zip)", type="primary"):
                retenus, ignores = _eleves_avec_donnees(eleves_bilan)
                buf = io.BytesIO()
                with zipfile.ZipFile(buf, "w") as zf:
                    for s in retenus:
                        zf.writestr(f"Bilan - {_nom_fichier(s['nom_prenom'])}.pdf",
                                    _pdf_en_memoire(build_bilan_pdf, nom_choisi, debut, fin, [s], options_bilan_pdf))
                st.download_button("Télécharger le zip", buf.getvalue(),
                                    file_name=f"bilans_{_nom_fichier(nom_choisi)}.zip")
                if ignores:
                    st.caption(f"{ignores} élève(s) sans aucune évaluation corrigée sur cette sélection "
                               f"n'ont pas de bilan.")
        else:
            if st.button("Générer le PDF unique (toute la classe)", type="primary", key="bilan_pdf_unique"):
                retenus, ignores = _eleves_avec_donnees(eleves_bilan)
                pdf_unique = _pdf_en_memoire(build_bilan_pdf, nom_choisi, debut, fin, retenus, options_bilan_pdf)
                st.download_button("Télécharger le PDF unique", pdf_unique,
                                    file_name=f"bilans_{_nom_fichier(nom_choisi)}.pdf")
                if ignores:
                    st.caption(f"{ignores} élève(s) sans aucune évaluation corrigée sur cette sélection "
                               f"n'ont pas de bilan.")

        st.subheader("Aperçu individuel")
        nom_b = st.selectbox("Élève", eleves_bilan, width=280, key="bilan_eleve_apercu")
        if nom_b and st.button("Générer le bilan de cet élève"):
            data_b = db.bilan_eleve(ds_ids, db.get_student_id(nom_b))
            pdf_b = _pdf_en_memoire(build_bilan_pdf, nom_choisi, debut, fin,
                                    [{"nom_prenom": nom_b, "data": data_b}], options_bilan_pdf)
            st.download_button("Télécharger le PDF", pdf_b, file_name=f"Bilan - {_nom_fichier(nom_b)}.pdf")
        st.stop()
    options = {f"{d['titre']}" + (" 🔁 (formatif)" if (d.get('nature') or 'sommative') == 'formative' else "") + f" (id {d['id']})": d["id"] for d in tous}
    label = st.selectbox("Devoir", list(options.keys()), width=280)
    ds_id = options[label]
    ds = db.get_ds(ds_id)
    type_eval = ds.get("type_eval") or "devoir"
    questions = db.get_questions(ds_id)
    competences = db.trier_competences(sorted(set(q["competence"] for q in questions))) or db.COMPETENCES_DEFAUT
    remediation_grid = db.get_remediation_grid(ds_id, competences)
    eleves = db.list_students(classe_id=classe_id)

    # Contrôle avant impression : un code cité sur les fiches doit exister dans le catalogue chargé.
    problemes_codes = db.verifier_codes(remediation_grid) if type_eval != "tp" else []
    if problemes_codes:
        st.error("🚫 Impression bloquée : les ressources de la remédiation contiennent des codes "
                 "invalides. Corrige-les dans l'onglet Remédiation (ou mets à jour le catalogue) :")
        for pb in problemes_codes:
            st.markdown(f"- {pb}")
        st.stop()

    if type_eval == "tp":
        with st.expander("🖨️ Fiche d'évaluation à imprimer (pour l'évaluateur)"):
            st.caption("Une fiche par élève : compétences, capacités associées, observables / critères "
                       "de réussite, cases A-B-C-D à cocher, remarques — avec les besoins particuliers "
                       "de l'élève en évidence. Les critères se saisissent dans « Paramétrisation d'une "
                       "évaluation ».")
            mode_fiche = st.radio("Contenu", ["Une fiche par élève de la classe", "Une fiche vierge"],
                                   horizontal=True, key="mode_fiche_tp")
            if st.button("Générer la fiche", key="btn_fiche_tp"):
                besoins_f = db.get_besoins_map(classe_id)
                liste = ([(n, besoins_f.get(n, "")) for n in eleves]
                         if mode_fiche.startswith("Une fiche par") else None)
                st.session_state["_fiche_tp_pdf"] = (
                    f"fiche_{_nom_fichier(ds['titre'])}.pdf",
                    build_fiche_tp_pdf(ds["titre"], nom_choisi, ds.get("date_ds"),
                                                  questions, liste))
            if st.session_state.get("_fiche_tp_pdf"):
                nom_f, data_f = st.session_state["_fiche_tp_pdf"]
                st.download_button("⬇️ Télécharger la fiche (PDF)", data_f, file_name=nom_f,
                                   mime="application/pdf")

    with st.expander("⚙️ Contenu du rapport", expanded=False):
        if type_eval == "tp":
            opt_capacite = st.checkbox("Inclure la colonne « Capacité associée »", value=True,
                                        help="Colonne où tu as noté soit les capacités du référentiel, "
                                             "soit des observables/critères de réussite (onglet Devoirs).")
            opt_commentaire_tp = st.checkbox("Inclure les commentaires personnels", value=True,
                                              help="Le commentaire saisi pour chaque compétence, "
                                                   "dans l'onglet Corriger.")
            opt_commentaire_global = st.checkbox("Inclure le commentaire global", value=False,
                                                  help="L'appréciation générale saisie sous le tableau "
                                                       "de correction, dans l'onglet Corriger.")
            options_pdf = {"capacite": opt_capacite, "commentaire_tp": opt_commentaire_tp,
                            "commentaire_global": opt_commentaire_global}
        else:
            opt_remediation = st.checkbox("Bloc remédiation par compétence", value=True,
                                           help="Le tableau compétence/niveau/texte de remédiation "
                                                "(onglet Remédiation).")
            opt_detail = st.checkbox("Détail question par question", value=True,
                                      help="Le tableau listant chaque question avec son niveau et ses points.")
            opt_commentaire = st.checkbox("Commentaire général", value=True,
                                           help="Le commentaire saisi dans l'onglet Corriger, sous les questions.")
            opt_ajustement = st.checkbox("Ajustement (bonus/malus)", value=True,
                                          help="N'apparaît de toute façon que si un ajustement non nul "
                                               "a été saisi pour cet élève.")
            options_pdf = {"remediation": opt_remediation, "detail_questions": opt_detail,
                            "commentaire": opt_commentaire, "ajustement": opt_ajustement}
            if ds.get("commentaires_question"):
                opt_commentaire_question = st.checkbox(
                    "Commentaires par question", value=True,
                    help="Les commentaires saisis question par question dans l'onglet Corriger, "
                         "ajoutés en colonne dans le tableau détaillé.")
                options_pdf["commentaire_question"] = opt_commentaire_question
        opt_evolution = st.checkbox(
            "Flèches d'évolution par compétence", value=True,
            help="▲ bleue = progrès, ▼ rouge = recul par rapport à l'évaluation précédente où la même "
                 "compétence a été évaluée (les évaluations formatives sont ignorées ; rien ne s'affiche "
                 "s'il n'y a pas d'évaluation antérieure). Pour un devoir écrit, les flèches apparaissent "
                 "dans le « Bloc remédiation par compétence ».")
        options_pdf["evolution"] = opt_evolution

        _tailles = {"Automatique (la plus grande taille qui tient sur une feuille recto-verso)": "auto",
                    "Normale (9 pt)": 9, "Petite (8 pt)": 8, "Très petite (7 pt)": 7}
        choix_taille = st.selectbox(
            "Taille du texte du rapport", list(_tailles.keys()), key="taille_rapport",
            help="« Automatique » réduit l'écriture juste ce qu'il faut pour que le rapport de chaque élève "
                 "tienne sur une feuille recto-verso (2 pages). Si le résultat est trop petit à l'impression, "
                 "choisis une taille fixe.")
        options_pdf["taille"] = _tailles[choix_taille]
        options_pdf["recto_verso"] = st.checkbox(
            "Un seul PDF : chaque élève sur sa propre feuille recto-verso", value=True, key="rv_pdf",
            help="Ajoute une page blanche au verso quand le rapport d'un élève tient sur une seule page, "
                 "pour que deux élèves ne se retrouvent jamais sur la même feuille une fois imprimé en "
                 "recto-verso. Sans effet sur les PDF séparés.")

    format_export = st.radio("Format d'export pour toute la classe",
                              ["PDF séparés (un zip)", "Un seul PDF (tous les élèves)"],
                              horizontal=True)

    if format_export == "PDF séparés (un zip)":
        if st.button("Générer tous les PDF (zip)", type="primary"):
            buf = io.BytesIO()
            sans_note = []
            with zipfile.ZipFile(buf, "w") as zf:
                for nom in eleves:
                    sid = db.get_student_id(nom)
                    res = db.compute_student_result(ds_id, sid)
                    if not _a_une_correction(res):
                        sans_note.append(nom)
                        continue
                    contenu_pdf = _pdf_en_memoire(
                        build_student_pdf, ds["titre"], nom, res["note"], res["note_sur"],
                        db.get_comment(ds_id, sid), res["niveaux_competence"],
                        remediation_grid, res["questions"], res["grades"],
                        mode_notation=res["mode_notation"], type_eval=type_eval,
                        note_basse=res.get("note_calculee"), note_haute=res.get("note_haute"),
                        grade_comments=db.get_grade_comments(ds_id, sid),
                        date_ds=ds.get("date_ds"), ajustement=res.get("ajustement", 0),
                        options=options_pdf,
                        evolution=db.evolution_competences(ds_id, sid) if options_pdf.get("evolution") else None,
                    )
                    zf.writestr(f"{_nom_fichier(nom)}.pdf", contenu_pdf)
            st.download_button("Télécharger le zip", buf.getvalue(),
                                file_name=f"rapports_{_nom_fichier(ds['titre'])}.zip")
            if sans_note:
                st.caption(f"{len(sans_note)} élève(s) sans aucune note sur ce devoir n'ont pas de rapport : "
                           + ", ".join(sans_note) + ".")
    else:
        if st.button("Générer le PDF unique (toute la classe)", type="primary"):
            students_data = []
            sans_note = []
            for nom in eleves:
                sid = db.get_student_id(nom)
                res = db.compute_student_result(ds_id, sid)
                if not _a_une_correction(res):
                    sans_note.append(nom)
                    continue
                students_data.append({
                    "nom_prenom": nom, "note": res["note"], "note_sur": res["note_sur"],
                    "commentaire": db.get_comment(ds_id, sid),
                    "niveaux_competence": res["niveaux_competence"],
                    "remediation_grid": remediation_grid,
                    "questions": res["questions"], "grades": res["grades"],
                    "mode_notation": res["mode_notation"], "ajustement": res.get("ajustement", 0),
                    "note_basse": res.get("note_calculee"), "note_haute": res.get("note_haute"),
                    "grade_comments": db.get_grade_comments(ds_id, sid),
                    "evolution": db.evolution_competences(ds_id, sid) if options_pdf.get("evolution") else None,
                })
            if not students_data:
                st.warning("Aucun élève n'a encore de note sur ce devoir : rien à imprimer.")
            else:
                pdf_unique = _pdf_en_memoire(build_combined_pdf, ds["titre"], students_data,
                                             type_eval=type_eval, date_ds=ds.get("date_ds"), options=options_pdf)
                st.download_button("Télécharger le PDF unique", pdf_unique,
                                    file_name=f"rapports_{_nom_fichier(ds['titre'])}.pdf")
                if sans_note:
                    st.caption(f"{len(sans_note)} élève(s) sans aucune note sur ce devoir n'ont pas de rapport : "
                               + ", ".join(sans_note) + ".")

    st.subheader("Aperçu individuel")
    nom = st.selectbox("Élève", eleves, width=280)
    if nom and st.button("Générer le PDF de cet élève"):
        sid = db.get_student_id(nom)
        res = db.compute_student_result(ds_id, sid)
        if not _a_une_correction(res):
            st.warning(f"{nom} n'a encore aucune note sur ce devoir : pas de rapport à générer.")
        else:
            contenu_pdf = _pdf_en_memoire(
                build_student_pdf, ds["titre"], nom, res["note"], res["note_sur"],
                db.get_comment(ds_id, sid), res["niveaux_competence"],
                remediation_grid, res["questions"], res["grades"],
                mode_notation=res["mode_notation"], type_eval=type_eval,
                note_basse=res.get("note_calculee"), note_haute=res.get("note_haute"),
                grade_comments=db.get_grade_comments(ds_id, sid),
                date_ds=ds.get("date_ds"), ajustement=res.get("ajustement", 0),
                options=options_pdf,
                evolution=db.evolution_competences(ds_id, sid) if options_pdf.get("evolution") else None,
            )
            st.download_button("Télécharger le PDF", contenu_pdf, file_name=f"{_nom_fichier(nom)}.pdf")

# ---------------------------------------------------------------- RÉGLAGES
elif page == "Réglages":
    st.title("⚙️ Réglages")

    st.subheader("💾 Tes données et leurs sauvegardes",
                 help="Toutes tes données (classes, élèves, devoirs, notes) sont dans un seul fichier, "
                      "rangé dans ton dossier Documents — pas dans le dossier de l'appli : tu peux donc "
                      "mettre l'appli à jour (ou en tester une autre version) sans rien perdre.")
    if os.path.exists(db.DB_PATH):
        taille_ko = os.path.getsize(db.DB_PATH) / 1024
        _, resume = _valider_sauvegarde(db.DB_PATH)
        st.markdown(f"**Où sont tes données :** `{db.DB_PATH}`")
        st.caption(f"Fichier actuel : {taille_ko:.0f} Ko — {resume}. Dernier enregistrement : "
                   f"{_date_lisible(db.dernier_enregistrement())}.")
        with open(db.DB_PATH, "rb") as f:
            st.download_button(
                "📥 Télécharger une copie (pour changer d'ordinateur, par exemple)",
                f.read(),
                file_name=f"sauvegarde_trajectoire_{date.today().isoformat()}.db",
                mime="application/octet-stream",
            )
        autos = db.lister_sauvegardes_auto()
        if autos:
            derniere = _date_lisible(datetime.fromtimestamp(os.path.getmtime(autos[-1])))
            st.caption(f"🛟 Copies automatiques : {len(autos)} dans « {_chemin_court(db.dossier_sauvegardes_auto())} » "
                       f"(la dernière date du {derniere}). Une copie est faite dès que tu as modifié quelque "
                       "chose et que la précédente date de plus d'une heure ; on garde les 14 plus récentes "
                       "et la dernière de chacun des 30 derniers jours.")
        else:
            st.caption("🛟 Une copie de sécurité automatique est faite dès que tu as des données "
                       f"(dossier « {_chemin_court(db.dossier_sauvegardes_auto())} »).")
    else:
        st.info("Aucune donnée à sauvegarder pour l'instant.")

    st.markdown("**🪞 Copie miroir (facultative)** — une copie de plus, dans un autre dossier de ton "
                "choix (clé USB, dossier synchronisé OneDrive/Drive…), mise à jour automatiquement. "
                "Utile si l'ordinateur tombe en panne.")
    dossier_miroir = st.text_input("Dossier de la copie miroir", value=db.lire_reglages().get("dossier_miroir", ""),
                                   placeholder="Exemple : D:\\Sauvegardes  ou  /Volumes/MaCle/Trajectoire",
                                   key="champ_dossier_miroir")
    _m1, _m2 = st.columns(2)
    if _m1.button("Enregistrer ce dossier", key="miroir_enregistrer"):
        d = dossier_miroir.strip().strip('"')
        if d and not os.path.isdir(d):
            st.error("Ce dossier n'existe pas (ou n'est pas accessible en ce moment).")
        else:
            db.ecrire_reglage("dossier_miroir", d)
            st.success("Dossier miroir enregistré." if d else "Copie miroir désactivée.")
    if db.fichier_miroir():
        if _m2.button("Copier maintenant", key="miroir_maintenant"):
            statut, detail = db.sauvegarde_miroir(forcer=True)
            if statut == "ok":
                st.success("Copie miroir faite.")
            elif statut == "vide":
                st.warning("La base est vide : rien n'a été copié (la copie miroir existante est conservée).")
            elif statut == "absent":
                st.error(f"Le dossier « {detail} » est introuvable (clé USB débranchée ?).")
            else:
                st.error(f"La copie a échoué : {detail}")
        fm = db.fichier_miroir()
        if os.path.exists(fm):
            st.caption(f"Dernière copie miroir : {_date_lisible(datetime.fromtimestamp(os.path.getmtime(fm)))} "
                       f"(« {_chemin_court(fm)} »).")
        elif not os.path.isdir(os.path.dirname(fm)):
            st.warning("Le dossier miroir est introuvable pour l'instant (clé USB débranchée ?).")
        else:
            st.caption("Pas encore de copie miroir : elle sera faite à la prochaine modification.")

    st.divider()
    st.subheader("♻️ Restauration")
    st.warning("Restaurer une sauvegarde **remplace** les données actuelles. Par précaution, l'état actuel "
               "est d'abord copié dans le dossier des sauvegardes (« avant_restauration_… »), "
               "tu peux donc revenir en arrière.")
    contenu = None
    _copies = {p: db.resume_base(p) for p in db.lister_toutes_sauvegardes()}
    _copies = {p: r for p, r in _copies.items() if r}
    if _copies:
        def _lib_copie(p):
            if p is None:
                return "— aucune —"
            r = _copies[p]
            genre = "avant restauration" if os.path.basename(p).startswith("avant_restauration") else "automatique"
            return (f"{_date_lisible(datetime.fromtimestamp(os.path.getmtime(p)))} — {genre} — "
                    f"{r[0]} classe(s), {r[1]} élève(s), {r[2]} devoir(s)")
        # l'option est le chemin du fichier (et non sa position) : la liste change après chaque
        # copie automatique, une position pourrait alors désigner une autre sauvegarde.
        _choix_copie = st.selectbox("Choisir une copie automatique", [None] + list(_copies),
                                    format_func=_lib_copie, key="restaurer_choix_copie")
        if _choix_copie is not None:
            with open(_choix_copie, "rb") as f:
                contenu = f.read()
            message = _valider_sauvegarde(_choix_copie)[1]
    fichier_restore = st.file_uploader("…ou un fichier de sauvegarde (.db) à toi", type=["db"])
    if fichier_restore is not None:
        contenu = fichier_restore.getvalue()
        _fd, chemin_temp = tempfile.mkstemp(suffix=".db")
        try:
            with os.fdopen(_fd, "wb") as f:
                f.write(contenu)
            valide, message = _valider_sauvegarde(chemin_temp)
        finally:
            try:
                os.remove(chemin_temp)
            except OSError:
                pass
        if not valide:
            st.error(f"Ce fichier ne semble pas être une sauvegarde valide : {message}")
            contenu = None
    if contenu is not None:
        st.success(f"Sauvegarde valide — {message}.")
        confirm_key = "confirm_restore"
        if not st.session_state.get(confirm_key):
            if st.button("Restaurer cette sauvegarde", type="primary"):
                st.session_state[confirm_key] = True
                st.rerun()
        else:
            st.error("Confirme : les données actuelles seront remplacées par cette sauvegarde.")
            cc1, cc2 = st.columns(2)
            if cc1.button("Oui, restaurer", type="primary", key="restore_confirm"):
                db.restaurer_depuis_octets(contenu)
                st.session_state.pop(confirm_key, None)
                st.session_state.pop("restaurer_choix_copie", None)
                st.session_state["_reprise_message"] = "Restauration effectuée."
                st.rerun()
            if cc2.button("Annuler", key="restore_cancel"):
                st.session_state.pop(confirm_key, None)
                st.rerun()
