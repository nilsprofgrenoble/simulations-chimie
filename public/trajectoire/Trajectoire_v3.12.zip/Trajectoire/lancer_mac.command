#!/bin/bash
cd "$(dirname "$0")"

if ! command -v python3 &> /dev/null; then
    echo "============================================================"
    echo "Python n'est pas installé."
    echo "Installe-le depuis https://www.python.org/downloads/"
    echo "puis relance ce script."
    echo "============================================================"
    read -p "Appuie sur Entrée pour fermer..."
    exit 1
fi

if [ ! -d "venv" ]; then
    echo "============================================================"
    echo "Première installation : création de l'environnement..."
    echo "============================================================"
    python3 -m venv venv
fi

source venv/bin/activate

if [ ! -f "venv/bin/streamlit" ]; then
    echo "============================================================"
    echo "Installation des dépendances (streamlit, pandas, reportlab...)"
    echo "Ça va prendre 1 à 3 minutes, patiente..."
    echo "============================================================"
    pip install --upgrade pip
    pip install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "============================================================"
        echo "ERREUR : l'installation des dépendances a échoué."
        echo "Fais défiler cette fenêtre vers le haut pour voir le détail."
        echo ""
        echo "Cause fréquente sur un réseau professionnel : un pare-feu ou"
        echo "un proxy d'entreprise qui bloque l'accès à internet pour Python."
        echo "Si c'est le cas, contacte ton service informatique en leur"
        echo "montrant ce message et l'erreur au-dessus."
        echo "============================================================"
        read -p "Appuie sur Entrée pour fermer..."
        exit 1
    fi
fi

echo "============================================================"
echo "Lancement de l'appli... un onglet de navigateur va s'ouvrir."
echo "Pour arrêter l'appli : ferme cette fenêtre ou fais Ctrl+C."
echo "============================================================"
streamlit run app.py
