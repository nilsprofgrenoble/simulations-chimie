@echo off
setlocal enabledelayedexpansion

cd /d "%~dp0"

rem Cherche d'abord une installation Anaconda/Miniconda (frequente en etablissement
rem scolaire, souvent plus recente que le Python "systeme"), puis le lanceur "py",
rem puis "python" simple en dernier recours.
set PYCMD=
if exist "%USERPROFILE%\Anaconda3\python.exe" set PYCMD=%USERPROFILE%\Anaconda3\python.exe
if "%PYCMD%"=="" if exist "%USERPROFILE%\Miniconda3\python.exe" set PYCMD=%USERPROFILE%\Miniconda3\python.exe
if "%PYCMD%"=="" if exist "C:\ProgramData\Anaconda3\python.exe" set PYCMD=C:\ProgramData\Anaconda3\python.exe
if "%PYCMD%"=="" if exist "C:\ProgramData\Miniconda3\python.exe" set PYCMD=C:\ProgramData\Miniconda3\python.exe
if "%PYCMD%"=="" if exist "C:\Anaconda3\python.exe" set PYCMD=C:\Anaconda3\python.exe

if "%PYCMD%"=="" (
    py -3 --version >nul 2>nul
    if not errorlevel 1 set PYCMD=py -3
)
if "%PYCMD%"=="" (
    where python >nul 2>nul
    if not errorlevel 1 set PYCMD=python
)

if "%PYCMD%"=="" (
    echo ============================================================
    echo Python n'est pas installe ou n'est pas accessible.
    echo Installe-le depuis https://www.python.org/downloads/
    echo IMPORTANT : coche bien la case "Add python.exe to PATH"
    echo pendant l'installation, puis relance ce fichier.
    echo ============================================================
    pause
    exit /b 1
)

echo ============================================================
echo Python utilise pour cette appli : %PYCMD%
%PYCMD% --version
echo ============================================================
pause

if not exist venv (
    echo ============================================================
    echo Premiere installation : creation de l'environnement...
    echo ============================================================
    %PYCMD% -m venv venv
)

call venv\Scripts\activate.bat

if not exist venv\Scripts\streamlit.exe (
    echo ============================================================
    echo Installation des dependances (streamlit, pandas, reportlab...)
    echo Ca va prendre 1 a 3 minutes, patiente...
    echo ============================================================
    python -m pip install --upgrade pip
    pip install -r requirements.txt
    if errorlevel 1 (
        echo ============================================================
        echo ERREUR : l'installation des dependances a echoue.
        echo Fais defiler cette fenetre vers le haut pour voir le detail.
        echo.
        echo Cause la plus probable : la version de Python affichee plus
        echo haut est trop ancienne ^(il faut 3.9 minimum, idealement 3.10+^).
        echo Cause possible egalement : un pare-feu/proxy d'entreprise qui
        echo bloque l'acces a internet pour Python. Si besoin, montre ce
        echo message et la version de Python ci-dessus a ton service
        echo informatique.
        echo ============================================================
        pause
        exit /b 1
    )
)

echo ============================================================
echo Lancement de l'appli... un onglet de navigateur va s'ouvrir.
echo Pour arreter l'appli : ferme cette fenetre ou fais Ctrl+C.
echo ============================================================
streamlit run app.py

pause
