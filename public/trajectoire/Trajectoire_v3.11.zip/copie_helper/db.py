"""
Couche d'accès à la base SQLite.
Reproduit la logique de calcul du gsheet "CORRECTION PAR ELEVE" / "NE PAS MODIFIER".
"""
import csv
import json
import os
import re
import sqlite3
from contextlib import contextmanager
from datetime import date

DB_PATH = "copie_helper.db"

NIVEAUX = ["A", "B", "C", "D"]
POIDS_NIVEAU = {"A": 1.0, "B": 2 / 3, "C": 1 / 3, "D": 0.0}
POIDS_NIVEAU_HAUT = {"A": 1.0, "B": 3 / 4, "C": 1 / 2, "D": 1 / 4}
COMPETENCES_DEFAUT = ["S'APP", "ANA", "REA", "VAL", "COM"]
COMPETENCES_DEFAUT_DEVOIR = ["S'APP", "ANA", "REA", "VAL", "COM", "Complexe"]
COMMENTAIRES_BANQUE_DEFAUT = [
    "À revoir",
    "Réponse peu compréhensible",
    "Attention aux unités",
    "Bien argumenté",
    "Manque de rigueur",
    "Bonne méthode",
]

# Grilles de compétences BTS Métiers de la Chimie, préremplissables pour un TP type CCF.
# E51 et E52 sont deux épreuves distinctes du référentiel, avec des capacités associées
# différentes (même si certains codes de compétence se recoupent).
# (label=code compétence, competence=libellé, detail=capacité associée, bareme=poids)
GRILLE_TP_BTS_E52 = [
    {"label": "C1", "competence": "RECHERCHER ET ANALYSER", "detail": "", "bareme": 1},
    {"label": "C2", "competence": "REALISER", "detail": "", "bareme": 1},
    {"label": "C3", "competence": "INTERPRETER ET VALIDER", "detail": "", "bareme": 1},
    {"label": "C4", "competence": "OPTIMISER ET ADAPTER", "detail": "", "bareme": 1},
    {"label": "C6", "competence": "ORGANISER", "detail": "", "bareme": 1},
    {"label": "C7", "competence": "ADOPTER DES COMPORTEMENTS PROFESSIONNELS", "detail": "", "bareme": 1},
]

# Poids égaux par défaut pour les deux grilles BTS (E51 et E52) — à ajuster librement selon le TP.
GRILLE_TP_BTS_E51 = [
    {"label": "C1", "competence": "RECHERCHER ET ANALYSER", "detail": "", "bareme": 1},
    {"label": "C2", "competence": "REALISER", "detail": "", "bareme": 1},
    {"label": "C3", "competence": "INTERPRETER ET VALIDER", "detail": "", "bareme": 1},
    {"label": "C4", "competence": "OPTIMISER ET ADAPTER", "detail": "", "bareme": 1},
    {"label": "C6", "competence": "ORGANISER", "detail": "", "bareme": 1},
    {"label": "C7", "competence": "ADOPTER DES COMPORTEMENTS PROFESSIONNELS", "detail": "", "bareme": 1},
]

# Rappel des capacités associées officielles du référentiel BTS MDC, pour consultation dans
# l'appli (onglet Devoirs) — volontairement PAS injecté dans la grille par défaut ci-dessus,
# puisque la colonne "capacité associée" du tableau sert plutôt à noter des observables et
# critères de réussite propres à chaque TP.
CAPACITES_REFERENCE_BTS_E52 = {
    "C1": "C.1.4. Sélectionner les méthodes, techniques et matériels en fonction de l'expérience à réaliser",
    "C2": "C.2.1. Préparer les produits, le matériel et les accessoires sur les équipements de "
          "laboratoire les plus courants",
    "C3": "C.3.2. Détecter les non-conformités dans les activités de contrôle qualité et de R&D au "
          "regard des exigences de la sécurité, de la protection de l'environnement et de la qualité "
          "et alerter",
    "C4": "C.4.1. Modifier, améliorer ou transférer le protocole",
    "C6": "C.6.1. Organiser le travail et planifier les expériences dans le respect des délais / "
          "C.6.3. Gérer le stock des produits en appliquant la réglementation / "
          "C.6.4. Assurer la traçabilité des activités",
    "C7": "C.7.3. Travailler en équipe dans un groupe multiculturel et/ou pluridisciplinaire",
}

CAPACITES_REFERENCE_BTS_E51 = {
    "C1": "C.1.4. Sélectionner les techniques et matériels en fonction de l'expérience à réaliser",
    "C2": "C.2.2. Réaliser une maintenance de premier niveau sur les appareils, à partir d'une notice / "
          "C.2.3. Mettre en œuvre le protocole expérimental / "
          "C.2.4. Appliquer les procédures (fiches de données sécurité, EPI)",
    "C3": "C.3.2. Détecter les non-conformités dans les activités de contrôle qualité et de R&D au "
          "regard des exigences de la sécurité, de la protection de l'environnement et de la qualité "
          "et alerter",
    "C4": "C.4.1. Modifier le protocole",
    "C6": "C.6.4. Assurer la traçabilité des activités",
    "C7": "C.7.1. Être autonome et faire preuve d'initiative, d'esprit critique et de curiosité",
}

# Grille de compétences ECE (Évaluation des Compétences Expérimentales), lycée STL/Générale.
# Poids égaux par défaut (1 chacun) — à ajuster au cas par cas selon le sujet, pas de barème
# officiel unique contrairement au référentiel BTS.
GRILLE_TP_ECE_LYCEE = [
    {"label": "S'APP", "competence": "S'approprier", "detail": "", "bareme": 1},
    {"label": "ANA", "competence": "Analyser", "detail": "", "bareme": 1},
    {"label": "REA", "competence": "Réaliser", "detail": "", "bareme": 1},
    {"label": "VAL", "competence": "Valider", "detail": "", "bareme": 1},
    {"label": "COM", "competence": "Communiquer", "detail": "", "bareme": 1},
]

# Registre des grilles préremplies proposées dans l'onglet Devoirs pour une évaluation
# "globale par compétence" (mode TP) — ajouter une entrée ici suffit pour la proposer dans l'appli.
GRILLES_TP_PRESETS = {
    "BTS MDC — E52": GRILLE_TP_BTS_E52,
    "BTS MDC — E51": GRILLE_TP_BTS_E51,
    "ECE Lycée (STL / Générale)": GRILLE_TP_ECE_LYCEE,
}

CAPACITES_REFERENCE_PAR_GRILLE = {
    "BTS MDC — E52": CAPACITES_REFERENCE_BTS_E52,
    "BTS MDC — E51": CAPACITES_REFERENCE_BTS_E51,
}

# Une même compétence peut être nommée différemment selon la grille (code court dans les
# devoirs écrits, intitulé complet dans les grilles TP) — cette table permet de les faire
# correspondre à l'affichage, notamment dans le suivi dans le temps qui mélange les devoirs.
COMPETENCE_ALIASES = {
    "s'approprier": "S'APP",
    "analyser": "ANA",
    "réaliser": "REA",
    "valider": "VAL",
    "communiquer": "COM",
}


def normalize_competence(nom):
    return COMPETENCE_ALIASES.get(nom.strip().lower(), nom) if nom else nom


ORDRE_COMPETENCES = ["S'APP", "ANA", "REA", "VAL", "COM"]


def cle_ordre_competence(nom):
    """Clé de tri : S'APP, ANA, REA, VAL, COM d'abord, puis les autres (Complexe, listes
    perso...) dans leur ordre d'origine (le tri de Python est stable)."""
    n = normalize_competence(nom) if nom else nom
    return ORDRE_COMPETENCES.index(n) if n in ORDRE_COMPETENCES else len(ORDRE_COMPETENCES)


def trier_competences(noms):
    return sorted(noms, key=cle_ordre_competence)


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def dossier_sauvegardes_auto():
    return os.path.join(os.path.dirname(os.path.abspath(DB_PATH)), "sauvegardes_auto")


def lister_sauvegardes_auto():
    """Sauvegardes automatiques existantes, de la plus ancienne à la plus récente."""
    import glob
    return sorted(glob.glob(os.path.join(dossier_sauvegardes_auto(), "auto_*.db")))


def sauvegarde_auto(delai_heures=6, garder=14):
    """Copie cohérente de la base dans le dossier « sauvegardes_auto » (à côté de la base), au plus
    une toutes les `delai_heures` heures, en gardant les `garder` plus récentes. Ne fait rien si la
    base est absente ou sans élève. Retourne le chemin créé, ou None."""
    import time
    from datetime import datetime
    if not os.path.exists(DB_PATH):
        return None
    existantes = lister_sauvegardes_auto()
    if existantes and time.time() - os.path.getmtime(existantes[-1]) < delai_heures * 3600:
        return None
    src = sqlite3.connect(DB_PATH)
    try:
        if src.execute("SELECT COUNT(*) FROM students").fetchone()[0] == 0:
            return None
        os.makedirs(dossier_sauvegardes_auto(), exist_ok=True)
        dest_path = os.path.join(dossier_sauvegardes_auto(),
                                 f"auto_{datetime.now().strftime('%Y-%m-%d_%H%M')}.db")
        dest = sqlite3.connect(dest_path)
        try:
            src.backup(dest)
        finally:
            dest.close()
    finally:
        src.close()
    for ancienne in lister_sauvegardes_auto()[:-garder]:
        try:
            os.remove(ancienne)
        except OSError:
            pass
    return dest_path


def init_db():
    with get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS classes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT UNIQUE NOT NULL
            );

            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom_prenom TEXT UNIQUE NOT NULL,
                classe_id INTEGER REFERENCES classes(id)
            );

            CREATE TABLE IF NOT EXISTS ds (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titre TEXT NOT NULL,
                note_sur REAL NOT NULL DEFAULT 20,
                arrondi REAL NOT NULL DEFAULT 0.5,
                mode_notation TEXT NOT NULL DEFAULT 'lettres',
                date_ds TEXT,
                classe_id INTEGER REFERENCES classes(id),
                type_eval TEXT NOT NULL DEFAULT 'devoir',
                nature TEXT NOT NULL DEFAULT 'sommative',
                competence_list TEXT NOT NULL DEFAULT '__default__',
                commentaires_question INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS competence_lists (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT UNIQUE NOT NULL,
                competences TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS comment_bank (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                texte TEXT UNIQUE NOT NULL
            );

            CREATE TABLE IF NOT EXISTS tp_grilles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nom TEXT UNIQUE NOT NULL,
                questions TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS ds_questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ds_id INTEGER NOT NULL REFERENCES ds(id) ON DELETE CASCADE,
                ordre INTEGER NOT NULL,
                label TEXT NOT NULL,
                competence TEXT NOT NULL,
                bareme REAL NOT NULL,
                detail TEXT
            );

            CREATE TABLE IF NOT EXISTS grades (
                ds_id INTEGER NOT NULL REFERENCES ds(id) ON DELETE CASCADE,
                student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                question_id INTEGER NOT NULL REFERENCES ds_questions(id) ON DELETE CASCADE,
                niveau TEXT,
                points REAL,
                PRIMARY KEY (ds_id, student_id, question_id)
            );

            CREATE TABLE IF NOT EXISTS grade_comments (
                ds_id INTEGER NOT NULL REFERENCES ds(id) ON DELETE CASCADE,
                student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                question_id INTEGER NOT NULL REFERENCES ds_questions(id) ON DELETE CASCADE,
                texte TEXT,
                PRIMARY KEY (ds_id, student_id, question_id)
            );

            CREATE TABLE IF NOT EXISTS ds_student_comments (
                ds_id INTEGER NOT NULL REFERENCES ds(id) ON DELETE CASCADE,
                student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
                commentaire TEXT,
                ajustement REAL DEFAULT 0,
                PRIMARY KEY (ds_id, student_id)
            );

            CREATE TABLE IF NOT EXISTS remediation (
                ds_id INTEGER NOT NULL REFERENCES ds(id) ON DELETE CASCADE,
                competence TEXT NOT NULL,
                niveau TEXT NOT NULL,
                texte TEXT,
                PRIMARY KEY (ds_id, competence, niveau)
            );
            """
        )
        # migration légère pour les bases créées avant l'ajout de ces colonnes
        cols_ds = {r["name"] for r in conn.execute("PRAGMA table_info(ds)")}
        if "mode_notation" not in cols_ds:
            conn.execute("ALTER TABLE ds ADD COLUMN mode_notation TEXT NOT NULL DEFAULT 'lettres'")
        cols_grades = {r["name"] for r in conn.execute("PRAGMA table_info(grades)")}
        if "points" not in cols_grades:
            conn.execute("ALTER TABLE grades ADD COLUMN points REAL")
        if "date_ds" not in cols_ds:
            conn.execute("ALTER TABLE ds ADD COLUMN date_ds TEXT")
            conn.execute("UPDATE ds SET date_ds = date('now') WHERE date_ds IS NULL")
        cols_comments = {r["name"] for r in conn.execute("PRAGMA table_info(ds_student_comments)")}
        if "ajustement" not in cols_comments:
            conn.execute("ALTER TABLE ds_student_comments ADD COLUMN ajustement REAL DEFAULT 0")

        cols_students = {r["name"] for r in conn.execute("PRAGMA table_info(students)")}
        cols_ds2 = {r["name"] for r in conn.execute("PRAGMA table_info(ds)")}
        besoin_defaut = "classe_id" not in cols_students or "classe_id" not in cols_ds2
        if besoin_defaut:
            n_students = conn.execute("SELECT COUNT(*) AS n FROM students").fetchone()["n"]
            n_ds = conn.execute("SELECT COUNT(*) AS n FROM ds").fetchone()["n"]
            defaut_id = None
            if n_students > 0 or n_ds > 0:
                cur = conn.execute(
                    "INSERT OR IGNORE INTO classes (nom) VALUES ('Classe par défaut')"
                )
                row = conn.execute("SELECT id FROM classes WHERE nom='Classe par défaut'").fetchone()
                defaut_id = row["id"]
        if "classe_id" not in cols_students:
            conn.execute("ALTER TABLE students ADD COLUMN classe_id INTEGER REFERENCES classes(id)")
            if defaut_id:
                conn.execute("UPDATE students SET classe_id=? WHERE classe_id IS NULL", (defaut_id,))
        if "classe_id" not in cols_ds2:
            conn.execute("ALTER TABLE ds ADD COLUMN classe_id INTEGER REFERENCES classes(id)")
            if defaut_id:
                conn.execute("UPDATE ds SET classe_id=? WHERE classe_id IS NULL", (defaut_id,))

        cols_ds3 = {r["name"] for r in conn.execute("PRAGMA table_info(ds)")}
        if "type_eval" not in cols_ds3:
            conn.execute("ALTER TABLE ds ADD COLUMN type_eval TEXT NOT NULL DEFAULT 'devoir'")
        if "nature" not in cols_ds3:
            conn.execute("ALTER TABLE ds ADD COLUMN nature TEXT NOT NULL DEFAULT 'sommative'")
        if "competence_list" not in cols_ds3:
            conn.execute("ALTER TABLE ds ADD COLUMN competence_list TEXT NOT NULL DEFAULT '__default__'")
        if "commentaires_question" not in cols_ds3:
            conn.execute("ALTER TABLE ds ADD COLUMN commentaires_question INTEGER NOT NULL DEFAULT 0")
        cols_rem = {r["name"] for r in conn.execute("PRAGMA table_info(remediation)")}
        for col in ("liens", "liens_ds", "liens_suivant"):
            if col not in cols_rem:
                conn.execute(f"ALTER TABLE remediation ADD COLUMN {col} TEXT")
        cols_questions = {r["name"] for r in conn.execute("PRAGMA table_info(ds_questions)")}
        if "detail" not in cols_questions:
            conn.execute("ALTER TABLE ds_questions ADD COLUMN detail TEXT")
        if "criteres" not in cols_questions:
            conn.execute("ALTER TABLE ds_questions ADD COLUMN criteres TEXT")
        cols_students = [r["name"] for r in conn.execute("PRAGMA table_info(students)")]
        if "besoins" not in cols_students:
            conn.execute("ALTER TABLE students ADD COLUMN besoins TEXT")
        cols_comments2 = {r["name"] for r in conn.execute("PRAGMA table_info(ds_student_comments)")}
        if "note_manuelle" not in cols_comments2:
            conn.execute("ALTER TABLE ds_student_comments ADD COLUMN note_manuelle REAL")

        # Quelques suggestions de départ dans la banque de commentaires, uniquement si elle est
        # encore vide (pour ne pas les réintroduire après une suppression volontaire).
        if conn.execute("SELECT COUNT(*) FROM comment_bank").fetchone()[0] == 0:
            conn.executemany(
                "INSERT OR IGNORE INTO comment_bank (texte) VALUES (?)",
                [(t,) for t in COMMENTAIRES_BANQUE_DEFAUT],
            )


# ---------- Classes ----------

def list_classes():
    with get_conn() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM classes ORDER BY nom")]


def create_classe(nom):
    with get_conn() as conn:
        conn.execute("INSERT OR IGNORE INTO classes (nom) VALUES (?)", (nom.strip(),))
        row = conn.execute("SELECT id FROM classes WHERE nom=?", (nom.strip(),)).fetchone()
        return row["id"] if row else None


def rename_classe(classe_id, nouveau_nom):
    with get_conn() as conn:
        conn.execute("UPDATE classes SET nom=? WHERE id=?", (nouveau_nom.strip(), classe_id))


def get_classe(classe_id):
    with get_conn() as conn:
        r = conn.execute("SELECT * FROM classes WHERE id=?", (classe_id,)).fetchone()
        return dict(r) if r else None


# ---------- Listes de compétences personnalisées (pour les devoirs écrits) ----------

# Sentinelles réservées, en plus des listes créées par l'utilisateur.
LISTE_COMPETENCES_DEFAUT = "__default__"
LISTE_COMPETENCES_AUCUNE = "__aucune__"
COMPETENCE_UNIQUE_SANS_LISTE = "Général"


def list_competence_lists():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM competence_lists ORDER BY nom")
        return [{"id": r["id"], "nom": r["nom"], "competences": json.loads(r["competences"])} for r in rows]


def create_competence_list(nom, competences):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO competence_lists (nom, competences) VALUES (?, ?)",
            (nom.strip(), json.dumps(competences)),
        )


def update_competence_list(list_id, competences):
    with get_conn() as conn:
        conn.execute("UPDATE competence_lists SET competences=? WHERE id=?",
                      (json.dumps(competences), list_id))


def delete_competence_list(list_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM competence_lists WHERE id=?", (list_id,))


def resolve_competence_list(valeur):
    """Retourne la liste de codes de compétence effective pour une valeur de ds.competence_list
    (sentinelle '__default__'/'__aucune__', ou nom d'une liste personnalisée créée par l'utilisateur)."""
    if valeur == LISTE_COMPETENCES_AUCUNE:
        return [COMPETENCE_UNIQUE_SANS_LISTE]
    if valeur == LISTE_COMPETENCES_DEFAUT or not valeur:
        return COMPETENCES_DEFAUT_DEVOIR
    for liste in list_competence_lists():
        if liste["nom"] == valeur:
            return liste["competences"]
    return COMPETENCES_DEFAUT_DEVOIR  # liste supprimée depuis : on retombe sur la liste par défaut


# ---------- Banque de commentaires réutilisables ----------

def list_comment_bank():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM comment_bank ORDER BY texte")
        return [dict(r) for r in rows]


def add_comment_bank(texte):
    with get_conn() as conn:
        conn.execute("INSERT OR IGNORE INTO comment_bank (texte) VALUES (?)", (texte.strip(),))


def delete_comment_bank(comment_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM comment_bank WHERE id=?", (comment_id,))


# ---------- Grilles TP personnalisées ----------

def list_tp_grilles():
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM tp_grilles ORDER BY nom")
        return [{"id": r["id"], "nom": r["nom"], "questions": json.loads(r["questions"])} for r in rows]


def create_tp_grille(nom, questions):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO tp_grilles (nom, questions) VALUES (?, ?)",
            (nom.strip(), json.dumps(questions)),
        )


def delete_tp_grille(grille_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM tp_grilles WHERE id=?", (grille_id,))


# ---------- Élèves ----------

def list_students(classe_id=None):
    with get_conn() as conn:
        if classe_id is None:
            rows = conn.execute("SELECT nom_prenom FROM students ORDER BY nom_prenom")
        else:
            rows = conn.execute(
                "SELECT nom_prenom FROM students WHERE classe_id=? ORDER BY nom_prenom", (classe_id,)
            )
        return [r["nom_prenom"] for r in rows]


def add_student(nom_prenom, classe_id=None):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO students (nom_prenom, classe_id) VALUES (?, ?)",
            (nom_prenom.strip(), classe_id),
        )


def get_besoins_map(classe_id=None):
    """{nom_prenom: texte} des élèves ayant des besoins particuliers (PAP, PAI, tiers-temps...)."""
    with get_conn() as conn:
        if classe_id is None:
            rows = conn.execute("SELECT nom_prenom, besoins FROM students")
        else:
            rows = conn.execute("SELECT nom_prenom, besoins FROM students WHERE classe_id=?",
                                (classe_id,))
        return {r["nom_prenom"]: r["besoins"].strip() for r in rows
                if r["besoins"] and r["besoins"].strip()}


def set_besoins(nom_prenom, texte):
    with get_conn() as conn:
        conn.execute("UPDATE students SET besoins=? WHERE nom_prenom=?",
                     ((texte or "").strip() or None, nom_prenom))


def remove_student(nom_prenom):
    with get_conn() as conn:
        conn.execute("DELETE FROM students WHERE nom_prenom = ?", (nom_prenom,))


def set_student_classe(nom_prenom, classe_id):
    with get_conn() as conn:
        conn.execute("UPDATE students SET classe_id=? WHERE nom_prenom=?", (classe_id, nom_prenom))


def import_students(noms, classe_id=None):
    with get_conn() as conn:
        conn.executemany(
            "INSERT OR IGNORE INTO students (nom_prenom, classe_id) VALUES (?, ?)",
            [(n.strip(), classe_id) for n in noms if n and n.strip()],
        )


# ---------- Devoirs (DS) ----------

def list_ds(classe_id=None):
    with get_conn() as conn:
        if classe_id is None:
            rows = conn.execute("SELECT * FROM ds ORDER BY id DESC")
        else:
            rows = conn.execute("SELECT * FROM ds WHERE classe_id=? ORDER BY id DESC", (classe_id,))
        return [dict(r) for r in rows]


def create_ds(titre, note_sur=20, arrondi=0.5, mode_notation="lettres", date_ds=None, classe_id=None,
              type_eval="devoir", nature="sommative", competence_list=LISTE_COMPETENCES_DEFAUT,
              commentaires_question=False):
    if date_ds is None:
        date_ds = date.today().isoformat()
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO ds (titre, note_sur, arrondi, mode_notation, date_ds, classe_id, type_eval, "
            "nature, competence_list, commentaires_question) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (titre, note_sur, arrondi, mode_notation, date_ds, classe_id, type_eval, nature,
             competence_list, int(commentaires_question)),
        )
        return cur.lastrowid


def set_ds_nature(ds_id, nature):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET nature=? WHERE id=?", (nature, ds_id))


def set_ds_competence_list(ds_id, competence_list):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET competence_list=? WHERE id=?", (competence_list, ds_id))


def set_ds_commentaires_question(ds_id, actif):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET commentaires_question=? WHERE id=?", (int(actif), ds_id))


def set_ds_date(ds_id, date_ds):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET date_ds=? WHERE id=?", (date_ds, ds_id))


def set_ds_classe(ds_id, classe_id):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET classe_id=? WHERE id=?", (classe_id, ds_id))


def list_ds_chronological(classe_id=None):
    with get_conn() as conn:
        if classe_id is None:
            rows = conn.execute(
                "SELECT * FROM ds ORDER BY COALESCE(date_ds, '0000-00-00') ASC, id ASC"
            )
        else:
            rows = conn.execute(
                "SELECT * FROM ds WHERE classe_id=? ORDER BY COALESCE(date_ds, '0000-00-00') ASC, id ASC",
                (classe_id,),
            )
        return [dict(r) for r in rows]


def set_ds_mode(ds_id, mode_notation):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET mode_notation=? WHERE id=?", (mode_notation, ds_id))


def update_ds_bareme(ds_id, note_sur, arrondi):
    with get_conn() as conn:
        conn.execute("UPDATE ds SET note_sur=?, arrondi=? WHERE id=?", (note_sur, arrondi, ds_id))


def duplicate_ds(ds_id, new_titre=None):
    """Duplique un devoir (mêmes questions/compétence/barème/mode/classe/type), sans les notes/commentaires."""
    ds = get_ds(ds_id)
    if not ds:
        return None
    titre = new_titre or f"{ds['titre']} (copie)"
    new_id = create_ds(titre, ds["note_sur"], ds["arrondi"], ds.get("mode_notation") or "lettres",
                        classe_id=ds.get("classe_id"), type_eval=ds.get("type_eval") or "devoir",
                        nature=ds.get("nature") or "sommative",
                        competence_list=ds.get("competence_list") or LISTE_COMPETENCES_DEFAUT,
                        commentaires_question=bool(ds.get("commentaires_question")))
    qs = get_questions(ds_id)
    set_questions(new_id, [
        {"label": q["label"], "competence": q["competence"], "bareme": q["bareme"],
         "detail": q.get("detail"), "criteres": q.get("criteres")}
        for q in qs
    ])
    return new_id


def delete_ds(ds_id):
    """Supprime un devoir et tout ce qui en dépend (questions, notes, commentaires, remédiation)."""
    with get_conn() as conn:
        conn.execute("DELETE FROM ds WHERE id=?", (ds_id,))


def get_ds(ds_id):
    with get_conn() as conn:
        r = conn.execute("SELECT * FROM ds WHERE id = ?", (ds_id,)).fetchone()
        return dict(r) if r else None


def set_questions(ds_id, questions):
    """questions: liste de dicts {label, competence, bareme, detail (optionnel)}.
    Met à jour sur place les questions dont le label existe déjà (leurs notes déjà saisies sont
    conservées), ajoute les nouvelles, et ne supprime (avec les notes associées, en cascade) que
    celles qui ont réellement disparu de la liste — un simple changement de barème ou d'intitulé
    ne doit jamais effacer une correction déjà commencée."""
    with get_conn() as conn:
        existantes = {r["label"]: r["id"] for r in conn.execute(
            "SELECT id, label FROM ds_questions WHERE ds_id = ?", (ds_id,))}
        labels_nouveaux = set()
        for i, q in enumerate(questions):
            labels_nouveaux.add(q["label"])
            if q["label"] in existantes:
                conn.execute(
                    "UPDATE ds_questions SET ordre=?, competence=?, bareme=?, detail=?, criteres=? WHERE id=?",
                    (i, q["competence"], q["bareme"], q.get("detail"), q.get("criteres"),
                     existantes[q["label"]]),
                )
            else:
                conn.execute(
                    "INSERT INTO ds_questions (ds_id, ordre, label, competence, bareme, detail, criteres) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (ds_id, i, q["label"], q["competence"], q["bareme"], q.get("detail"),
                     q.get("criteres")),
                )
        a_supprimer = [qid for label, qid in existantes.items() if label not in labels_nouveaux]
        if a_supprimer:
            conn.executemany("DELETE FROM ds_questions WHERE id=?", [(qid,) for qid in a_supprimer])


def get_questions(ds_id):
    with get_conn() as conn:
        return [dict(r) for r in conn.execute(
            "SELECT * FROM ds_questions WHERE ds_id = ? ORDER BY ordre", (ds_id,)
        )]


# ---------- Notes ----------

def set_grade(ds_id, student_id, question_id, niveau=None, points=None):
    """Un seul des deux (niveau OU points) est renseigné selon le mode du DS ;
    l'autre est explicitement remis à None pour éviter les valeurs fantômes
    si on change de mode en cours de route."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO grades (ds_id, student_id, question_id, niveau, points)
               VALUES (?,?,?,?,?)
               ON CONFLICT(ds_id, student_id, question_id) DO UPDATE SET
                 niveau=excluded.niveau, points=excluded.points""",
            (ds_id, student_id, question_id, niveau, points),
        )


def get_grades_for_student(ds_id, student_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT question_id, niveau, points FROM grades WHERE ds_id=? AND student_id=?",
            (ds_id, student_id),
        )
        return {r["question_id"]: {"niveau": r["niveau"], "points": r["points"]} for r in rows}


def get_all_grades_for_ds(ds_id):
    """{student_id: {question_id: {'niveau':.., 'points':..}}} pour tout le devoir en une requête."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT student_id, question_id, niveau, points FROM grades WHERE ds_id=?", (ds_id,)
        )
        result = {}
        for r in rows:
            result.setdefault(r["student_id"], {})[r["question_id"]] = {
                "niveau": r["niveau"], "points": r["points"]
            }
        return result


def set_comment(ds_id, student_id, texte):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO ds_student_comments (ds_id, student_id, commentaire) VALUES (?,?,?)
               ON CONFLICT(ds_id, student_id) DO UPDATE SET commentaire=excluded.commentaire""",
            (ds_id, student_id, texte),
        )


def get_comment(ds_id, student_id):
    with get_conn() as conn:
        r = conn.execute(
            "SELECT commentaire FROM ds_student_comments WHERE ds_id=? AND student_id=?",
            (ds_id, student_id),
        ).fetchone()
        return r["commentaire"] if r else ""


def get_used_comments_for_ds(ds_id):
    """Commentaires généraux déjà saisis pour ce devoir (tous élèves confondus, sans doublon),
    pour réutilisation rapide d'un élève à l'autre pendant la correction."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT DISTINCT commentaire FROM ds_student_comments "
            "WHERE ds_id=? AND commentaire IS NOT NULL AND TRIM(commentaire) != ''",
            (ds_id,),
        )
        return [r["commentaire"] for r in rows]


def set_note_manuelle(ds_id, student_id, note):
    """Note finale saisie à la main (mode TP) — remplace la note calculée pour ce devoir/élève.
    Passer None pour revenir à la note calculée automatiquement."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO ds_student_comments (ds_id, student_id, note_manuelle) VALUES (?,?,?)
               ON CONFLICT(ds_id, student_id) DO UPDATE SET note_manuelle=excluded.note_manuelle""",
            (ds_id, student_id, note),
        )


def get_note_manuelle(ds_id, student_id):
    with get_conn() as conn:
        r = conn.execute(
            "SELECT note_manuelle FROM ds_student_comments WHERE ds_id=? AND student_id=?",
            (ds_id, student_id),
        ).fetchone()
        return r["note_manuelle"] if r else None


def set_grade_comment(ds_id, student_id, question_id, texte):
    """Commentaire personnel par compétence (mode TP) — une ligne par élève × compétence."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO grade_comments (ds_id, student_id, question_id, texte) VALUES (?,?,?,?)
               ON CONFLICT(ds_id, student_id, question_id) DO UPDATE SET texte=excluded.texte""",
            (ds_id, student_id, question_id, texte),
        )


def get_grade_comments(ds_id, student_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT question_id, texte FROM grade_comments WHERE ds_id=? AND student_id=?",
            (ds_id, student_id),
        )
        return {r["question_id"]: r["texte"] for r in rows}


def set_ajustement(ds_id, student_id, valeur):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO ds_student_comments (ds_id, student_id, ajustement) VALUES (?,?,?)
               ON CONFLICT(ds_id, student_id) DO UPDATE SET ajustement=excluded.ajustement""",
            (ds_id, student_id, valeur),
        )


def get_ajustement(ds_id, student_id):
    with get_conn() as conn:
        r = conn.execute(
            "SELECT ajustement FROM ds_student_comments WHERE ds_id=? AND student_id=?",
            (ds_id, student_id),
        ).fetchone()
        return r["ajustement"] if r and r["ajustement"] is not None else 0.0


def get_student_id(nom_prenom):
    with get_conn() as conn:
        r = conn.execute("SELECT id FROM students WHERE nom_prenom=?", (nom_prenom,)).fetchone()
        return r["id"] if r else None


# ---------- Remédiation ----------

COLONNES_LIENS = ("liens_ds", "liens_suivant", "liens")  # chapitre du devoir / chapitre suivant / sans chapitre


def set_remediation(ds_id, competence, niveau, texte, liens=None, liens_ds=None, liens_suivant=None):
    """Chaque argument de liens : None = on ne touche pas à ce qui est déjà enregistré (simple
    modification du texte) ; "" = on efface ; sinon texte brut au format décrit dans parse_liens.
    liens_ds = ressources du chapitre du devoir, liens_suivant = du chapitre suivant, liens =
    ressources sans chapitre (ex. exercices transversaux de Réaliser)."""
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO remediation (ds_id, competence, niveau, texte) VALUES (?,?,?,?)
               ON CONFLICT(ds_id, competence, niveau) DO UPDATE SET texte=excluded.texte""",
            (ds_id, competence, niveau, texte),
        )
        for col, val in (("liens", liens), ("liens_ds", liens_ds), ("liens_suivant", liens_suivant)):
            if val is not None:
                conn.execute(
                    f"UPDATE remediation SET {col}=? WHERE ds_id=? AND competence=? AND niveau=?",
                    ((val or "").strip() or None, ds_id, competence, niveau),
                )


def vider_remediation(ds_id):
    """Remet à zéro la grille de remédiation d'un devoir : textes ET ressources, pour toutes les
    compétences et tous les niveaux (A, B, C, D). Ne touche pas aux autres devoirs.
    Retourne le nombre de cases effacées."""
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM remediation WHERE ds_id=?", (ds_id,))
        return cur.rowcount


# ---------- Liens vers « Paillasse virtuelle » (catalogue de codes) ----------

CATALOGUE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "catalogue.csv")
CATALOGUE_URLS = ["https://paillasse-virtuelle.fr/catalogue.csv",
                  "https://raw.githubusercontent.com/nilsprofgrenoble/simulations-chimie/master/public/catalogue.csv"]
PHRASE_CODES = ('Pour retrouver un exercice, tape son code dans le champ "J\'ai un code" sur '
                'paillasse-virtuelle.fr (ou dans l\'application installée sur ton téléphone).')
_RE_CODE = re.compile(r"^(SAPP|ANA|REA|VAL|SIM)\d+$")


def normaliser_code(texte):
    """« ana 23 », « S'APP 4 », « ana-23 » → ANA23, SAPP4 (même tolérance que le site)."""
    return re.sub(r"[\s\-_.'\u2019]", "", texte or "").upper()


def parse_liens(brut):
    """Colonne « liens » d'un CSV de remédiation : entrées séparées par « ## », chacune
    « CODE | titre | chemin » (titre et chemin facultatifs : l'appli les relit dans le catalogue).
    Retourne une liste de dicts {code, titre, chemin} ; code vaut None si le premier champ
    n'est pas un code valide (entrée inutilisable, signalée par l'appli)."""
    liens = []
    for entree in (brut or "").split("##"):
        morceaux = [m.strip() for m in entree.split("|")]
        if not any(morceaux):
            continue
        code = normaliser_code(morceaux[0])
        liens.append({"code": code if _RE_CODE.match(code) else None,
                      "titre": morceaux[1] if len(morceaux) > 1 else "",
                      "chemin": morceaux[2] if len(morceaux) > 2 else "",
                      "brut": entree.strip()})
    return liens


_cache_catalogue = {"mtime": None, "data": None}


def charger_catalogue():
    """Lit catalogue.csv (colonnes lues par leur NOM : type, id, niveau, chapitre, titre, code…).
    Retourne {"par_code": {code: ligne}, "par_id": {id: ligne}, "date": timestamp} ou None si le
    fichier est absent / sans colonne « code »."""
    try:
        mtime = os.path.getmtime(CATALOGUE_PATH)
    except OSError:
        return None
    if _cache_catalogue["mtime"] == mtime:
        return _cache_catalogue["data"]
    data = None
    try:
        with open(CATALOGUE_PATH, encoding="utf-8-sig", newline="") as f:
            lecteur = csv.DictReader(f, delimiter=";")
            if lecteur.fieldnames and {"code", "titre", "type", "id"}.issubset(lecteur.fieldnames):
                lignes = list(lecteur)
                data = {"par_code": {normaliser_code(l["code"]): l for l in lignes if l.get("code")},
                        "par_id": {l["id"]: l for l in lignes}, "date": mtime}
    except (OSError, csv.Error, UnicodeDecodeError):
        data = None
    _cache_catalogue.update({"mtime": mtime, "data": data})
    return data


def enregistrer_catalogue(octets):
    """Valide (colonnes, au moins un code) puis remplace catalogue.csv. Retourne (ok, message)."""
    tmp = CATALOGUE_PATH + ".tmp"
    try:
        with open(tmp, "wb") as f:
            f.write(octets)
        with open(tmp, encoding="utf-8-sig", newline="") as f:
            lecteur = csv.DictReader(f, delimiter=";")
            manquantes = {"code", "titre", "type", "id"} - set(lecteur.fieldnames or [])
            if manquantes:
                return False, f"Fichier refusé : colonne(s) manquante(s) {', '.join(sorted(manquantes))}."
            n = sum(1 for l in lecteur if l.get("code"))
        if n == 0:
            return False, "Fichier refusé : aucun code dans la colonne « code »."
        os.replace(tmp, CATALOGUE_PATH)
        return True, f"Catalogue mis à jour : {n} ressources avec code."
    except (OSError, csv.Error, UnicodeDecodeError) as e:
        return False, f"Fichier illisible : {e}"
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def telecharger_catalogue():
    """GET du catalogue public (aucune donnée de l'appli n'est envoyée). Retourne (ok, message)."""
    import urllib.request
    derniere = ""
    for url in CATALOGUE_URLS:
        try:
            with urllib.request.urlopen(url, timeout=15) as r:
                return enregistrer_catalogue(r.read())
        except Exception as e:  # réseau, SSL, proxy d'établissement…
            derniere = str(e)
    return False, f"Téléchargement impossible ({derniere}). Charge le fichier à la main ci-dessous."


def resoudre_lien(code, catalogue):
    """{code, titre, chemin} relus dans le catalogue (source de vérité pour l'impression), ou None
    si le code n'y figure pas. Chemin : « Simulations › niveau › chapitre » ; « Exercices ›
    <simulation par compétence dont l'exercice dépend> »."""
    ligne = (catalogue or {}).get("par_code", {}).get(code)
    if not ligne:
        return None
    if ligne["type"] == "simulation":
        chemin = " › ".join(x for x in ["Simulations", ligne.get("niveau", ""), ligne.get("chapitre", "")] if x)
    else:
        parent = catalogue["par_id"].get("sim" + ligne["id"].split(":")[0])
        chemin = "Exercices › " + parent["titre"] if parent else "Exercices"
    return {"code": code, "titre": ligne["titre"], "chemin": chemin,
            "chapitre": ligne.get("chapitre", ""), "niveau": ligne.get("niveau", "")}


def verifier_codes(grille):
    """Contrôle avant impression : renvoie la liste des problèmes (liste vide = tout est bon) pour
    toutes les cases de la grille de remédiation (get_remediation_grid) : codes valides et présents
    dans le catalogue, et chapitres cohérents (tous les codes d'un bloc « chapitre du devoir » dans
    le même chapitre, idem pour « chapitre suivant », et ces deux chapitres différents)."""
    problemes = []
    catalogue = charger_catalogue()
    a_des_liens = False
    chapitres = {"liens_ds": set(), "liens_suivant": set()}
    for comp, d in grille.items():
        for niv in NIVEAUX:
            for col in COLONNES_LIENS:
                chap_case = set()
                for l in parse_liens(d.get(f"{col}_{niv}", "")):
                    a_des_liens = True
                    if l["code"] is None:
                        problemes.append(f"{comp} niveau {niv} : « {l['brut'][:40]} » n'est pas un code "
                                         f"(attendu : ANA118, SAPP69, SIM41…).")
                    elif catalogue is not None:
                        r = resoudre_lien(l["code"], catalogue)
                        if r is None:
                            problemes.append(f"{comp} niveau {niv} : le code {l['code']} n'existe pas "
                                             f"dans le catalogue.")
                        elif col in chapitres and r["chapitre"]:
                            chap_case.add(r["chapitre"])
                if col in chapitres and len(chap_case) > 1:
                    problemes.append(f"{comp} niveau {niv} : plusieurs chapitres mélangés dans "
                                     f"« {col} » ({', '.join(sorted(chap_case))}).")
                if col in chapitres:
                    chapitres[col] |= chap_case
    if chapitres["liens_ds"] & chapitres["liens_suivant"]:
        problemes.append("Le chapitre du devoir et le chapitre suivant ne doivent pas être identiques "
                         f"({', '.join(sorted(chapitres['liens_ds'] & chapitres['liens_suivant']))}).")
    for col, ens in chapitres.items():
        if len(ens) > 1:
            problemes.append(f"« {col} » cite plusieurs chapitres selon les cases : {', '.join(sorted(ens))}.")
    if a_des_liens and catalogue is None:
        problemes.append("Aucun catalogue chargé : impossible de vérifier les codes (onglet Remédiation).")
    return problemes


def get_remediation_grid(ds_id, competences):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT competence, niveau, texte, liens, liens_ds, liens_suivant FROM remediation WHERE ds_id=?",
            (ds_id,)
        )
        grid, liens = {}, {}
        for r in rows:
            grid[(r["competence"], r["niveau"])] = r["texte"]
            for col in COLONNES_LIENS:
                liens[(col, r["competence"], r["niveau"])] = r[col] or ""
    resultat = {}
    for c in competences:
        resultat[c] = {n: grid.get((c, n), "") for n in NIVEAUX}
        # clés supplémentaires « liens_ds_A », « liens_suivant_A », « liens_A » (texte brut)
        for n in NIVEAUX:
            for col in COLONNES_LIENS:
                resultat[c][f"{col}_{n}"] = liens.get((col, c, n), "")
    return resultat


# ---------- Calcul (reproduit les formules du gsheet) ----------

def compute_student_result(ds_id, student_id):
    ds = get_ds(ds_id)
    questions = get_questions(ds_id)
    grades = get_grades_for_student(ds_id, student_id)
    mode = ds.get("mode_notation") or "lettres"

    total_bareme = sum(q["bareme"] for q in questions) or 1
    total_points = 0.0
    par_competence = {}  # competence -> [points_obtenus, points_possibles]

    for q in questions:
        g = grades.get(q["id"], {})
        comp = q["competence"]
        par_competence.setdefault(comp, [0.0, 0.0])

        pts = None
        if mode == "points":
            if g.get("points") is not None:
                pts = max(0.0, min(q["bareme"], g["points"]))
        else:
            niveau = g.get("niveau")
            if niveau in POIDS_NIVEAU:
                pts = q["bareme"] * POIDS_NIVEAU[niveau]

        if pts is not None:
            total_points += pts
            par_competence[comp][0] += pts
            par_competence[comp][1] += q["bareme"]
        # question non corrigée : ni comptée dans obtenus ni dans possibles
        # (comme le gsheet, qui ignore les questions vides pour le niveau de compétence)

    note_brute = total_points * ds["note_sur"] / total_bareme + get_ajustement(ds_id, student_id)
    arrondi = ds["arrondi"]
    if arrondi is None or arrondi <= 0:
        note_calculee = round(note_brute, 2)
    else:
        note_calculee = round(note_brute / arrondi) * arrondi

    # "Note haute" : même principe avec une pondération plus généreuse (mode TP) —
    # sert de 2e borne de référence, affichée à côté de la note calculée classique ("basse").
    total_points_haut = 0.0
    for q in questions:
        g = grades.get(q["id"], {})
        if mode == "points":
            if g.get("points") is not None:
                total_points_haut += max(0.0, min(q["bareme"], g["points"]))
        else:
            niveau = g.get("niveau")
            if niveau in POIDS_NIVEAU_HAUT:
                total_points_haut += q["bareme"] * POIDS_NIVEAU_HAUT[niveau]
    note_haute_brute = total_points_haut * ds["note_sur"] / total_bareme + get_ajustement(ds_id, student_id)
    if arrondi is None or arrondi <= 0:
        note_haute = round(note_haute_brute, 2)
    else:
        note_haute = round(note_haute_brute / arrondi) * arrondi

    note_manuelle = get_note_manuelle(ds_id, student_id)
    note = note_manuelle if note_manuelle is not None else note_calculee

    niveaux_competence = {}
    for comp, (obtenus, possibles) in sorted(par_competence.items(),
                                             key=lambda kv: cle_ordre_competence(kv[0])):
        if possibles <= 0:
            niveaux_competence[comp] = ("non mobilisée", None)
            continue
        taux = obtenus / possibles
        if taux > 0.75:
            niv = "A"
        elif taux > 0.5:
            niv = "B"
        elif taux > 0.25:
            niv = "C"
        else:
            niv = "D"
        niveaux_competence[comp] = (niv, taux)

    return {
        "note": note,
        "note_calculee": note_calculee,
        "note_haute": note_haute,
        "note_manuelle": note_manuelle,
        "note_sur": ds["note_sur"],
        "mode_notation": mode,
        "type_eval": ds.get("type_eval") or "devoir",
        "ajustement": get_ajustement(ds_id, student_id),
        "niveaux_competence": niveaux_competence,
        "questions": questions,
        "grades": grades,
    }


# ---------- Évolution et bilan multi-évaluations ----------

RANG_NIVEAU = {"A": 4, "B": 3, "C": 2, "D": 1}


def niveau_depuis_taux(taux):
    """Même seuils que partout ailleurs dans l'appli : >75% A, >50% B, >25% C, sinon D."""
    if taux > 0.75:
        return "A"
    if taux > 0.5:
        return "B"
    if taux > 0.25:
        return "C"
    return "D"


def _direction(niveau_actuel, niveau_precedent):
    diff = RANG_NIVEAU[niveau_actuel] - RANG_NIVEAU[niveau_precedent]
    return "up" if diff > 0 else "down" if diff < 0 else "same"


def _niveaux_normalises(ds_id, student_id):
    """{compétence normalisée: niveau A-D} pour les compétences réellement évaluées de ce devoir."""
    res = compute_student_result(ds_id, student_id)
    return {normalize_competence(comp): niv
            for comp, (niv, _) in res["niveaux_competence"].items() if niv in POIDS_NIVEAU}


def evolution_competences(ds_id, student_id, inclure_formatif=False):
    """Pour chaque compétence évaluée dans ce devoir : 'up' / 'down' / 'same' par rapport à la
    dernière évaluation antérieure de la même classe où cette compétence a aussi été évaluée pour
    cet élève. Les clés sont les noms de compétence tels que stockés dans CE devoir ; une
    compétence sans point de comparaison est simplement absente du résultat."""
    ds = get_ds(ds_id)
    if not ds or ds.get("classe_id") is None:
        return {}
    chrono = list_ds_chronological(ds["classe_id"])
    ids = [d["id"] for d in chrono]
    if ds_id not in ids:
        return {}
    precedents = [d for d in chrono[:ids.index(ds_id)]
                  if inclure_formatif or (d.get("nature") or "sommative") == "sommative"]
    if not precedents:
        return {}
    courant = {comp: niv for comp, (niv, _) in
               compute_student_result(ds_id, student_id)["niveaux_competence"].items()
               if niv in POIDS_NIVEAU}
    restant = {comp: normalize_competence(comp) for comp in courant}
    evolution = {}
    for d in reversed(precedents):  # du plus récent au plus ancien
        if not restant:
            break
        niveaux = _niveaux_normalises(d["id"], student_id)
        for comp, norm in list(restant.items()):
            if norm in niveaux:
                evolution[comp] = _direction(courant[comp], niveaux[norm])
                del restant[comp]
    return evolution


def bilan_eleve(ds_ids, student_id):
    """Données du rapport « bilan » d'un élève sur plusieurs évaluations (ds_ids = ids à
    inclure, dans n'importe quel ordre : ils sont remis en ordre chronologique).
    Retourne un dict :
      devoirs      : liste (chronologique) de {id, titre, date_ds, nature, note, note_sur,
                     corrige (bool), niveaux {compétence normalisée: niveau}}
      competences  : noms normalisés, dans l'ordre de première apparition
      bilan        : {compétence: niveau agrégé sur l'ensemble des évaluations retenues}
      tendance     : {compétence: 'up'/'down'/'same'} entre les deux dernières évaluations
                     où elle a été évaluée (absente s'il n'y en a qu'une)."""
    devoirs_tous = {d["id"]: d for d in list_ds()}
    ordonnes = sorted((devoirs_tous[i] for i in ds_ids if i in devoirs_tous),
                      key=lambda d: (d.get("date_ds") or "0000-00-00", d["id"]))
    devoirs, competences, cumul = [], [], {}
    for d in ordonnes:
        questions = get_questions(d["id"])
        grades = get_grades_for_student(d["id"], student_id)
        mode = d.get("mode_notation") or "lettres"
        corrige = any((g.get("niveau") or g.get("points") is not None) for g in grades.values())
        res = compute_student_result(d["id"], student_id)
        niveaux = {}
        for q in questions:
            comp = normalize_competence(q["competence"])
            if comp not in competences:
                competences.append(comp)
            g = grades.get(q["id"], {})
            pts = None
            if mode == "points":
                if g.get("points") is not None:
                    pts = max(0.0, min(q["bareme"], g["points"]))
            elif g.get("niveau") in POIDS_NIVEAU:
                pts = q["bareme"] * POIDS_NIVEAU[g["niveau"]]
            if pts is not None:
                cumul.setdefault(comp, [0.0, 0.0])
                cumul[comp][0] += pts
                cumul[comp][1] += q["bareme"]
        for comp, (niv, _) in res["niveaux_competence"].items():
            if niv in POIDS_NIVEAU:
                niveaux[normalize_competence(comp)] = niv
        devoirs.append({
            "id": d["id"], "titre": d["titre"], "date_ds": d.get("date_ds"),
            "nature": d.get("nature") or "sommative",
            "note": res["note"] if corrige else None, "note_sur": res["note_sur"],
            "corrige": corrige, "niveaux": niveaux,
        })
    bilan = {c: niveau_depuis_taux(o / p) for c, (o, p) in cumul.items() if p > 0}
    tendance = {}
    for comp in competences:
        evalues = [d["niveaux"][comp] for d in devoirs if comp in d["niveaux"]]
        if len(evalues) >= 2:
            tendance[comp] = _direction(evalues[-1], evalues[-2])
    return {"devoirs": devoirs, "competences": competences, "bilan": bilan, "tendance": tendance}
